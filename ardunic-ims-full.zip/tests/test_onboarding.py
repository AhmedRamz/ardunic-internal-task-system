"""Putting the team and the social-media rota in from the dashboard, in one press."""
from __future__ import annotations

import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import auth, onboarding  # noqa: E402
from ims.core import periods as P  # noqa: E402

PASSWORD = "test-only-not-a-real-password"


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "test.db")
        conn = db.connect(path)
        db.migrate(conn)
        self.loc = db.insert(conn, "locations", name="الجادرية")
        self.gm = db.insert(conn, "users", name="أحمد رمز", role="gm", location_id=self.loc,
                            telegram_username="ahmed")
        self.mgr = db.insert(conn, "users", name="حيدر", role="manager", location_id=self.loc,
                             manager_id=self.gm, telegram_id=2)
        auth.set_password(conn, self.gm, PASSWORD)
        conn.close()

        os.environ["DB_PATH"] = path
        os.environ["SESSION_SECRET"] = "test-secret"
        from ims.web import app as web_app
        self.web = importlib.reload(web_app)
        self.conn = self.web.conn
        from fastapi.testclient import TestClient
        self.client = TestClient(self.web.app)
        self.client.post("/login", data={"username": "ahmed", "password": PASSWORD})

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    def staff(self):
        return {r["name"]: r for r in db.all_rows(
            self.conn, "SELECT * FROM users WHERE role = 'employee'")}

    def holder_on(self, period_name, weekday):
        row = db.one(
            self.conn,
            """SELECT u.name FROM period_schedule s JOIN routine_periods p ON p.id = s.period_id
               JOIN users u ON u.id = s.user_id WHERE p.name = ? AND s.weekday = ?""",
            (period_name, weekday))
        return row["name"] if row else None


class TestApplying(Base):
    def test_the_six_arrive_with_link_codes(self):
        result = onboarding.apply(self.conn, self.loc)
        self.assertEqual(result["created"], 6)
        self.assertEqual(set(self.staff()), {"نرجس", "علي", "طيبة", "محمد أحمد",
                                             "محمود", "أحمد جعفر"})
        self.assertEqual(len(result["codes"]), 6)
        for _, _, code in result["codes"]:
            self.assertRegex(code, r"^\d{6}$")

    def test_the_board_matches_the_sheet(self):
        onboarding.apply(self.conn, self.loc)
        self.assertEqual(self.holder_on("صباحية", "sat"), "نرجس")
        self.assertEqual(self.holder_on("مسائية", "sun"), "محمود")
        self.assertEqual(self.holder_on("ليلية", "thu"), "محمد أحمد")

    def test_ahmed_jaffar_takes_wednesday_morning_and_monday_evening(self):
        onboarding.apply(self.conn, self.loc)
        self.assertEqual(self.holder_on("صباحية", "wed"), "أحمد جعفر")
        self.assertEqual(self.holder_on("مسائية", "mon"), "أحمد جعفر")

    def test_mahmood_covers_all_four_friday_periods(self):
        onboarding.apply(self.conn, self.loc)
        for name in ("الجمعة ف1", "الجمعة ف2", "الجمعة ف3", "الجمعة ف4"):
            self.assertEqual(self.holder_on(name, "fri"), "محمود")

    def test_the_one_blank_on_the_sheet_stays_a_gap(self):
        result = onboarding.apply(self.conn, self.loc)
        self.assertEqual(result["gaps"], 1)
        self.assertIsNone(self.holder_on("ليلية", "sun"))

    def test_applying_twice_changes_nothing(self):
        onboarding.apply(self.conn, self.loc)
        before = db.one(self.conn, "SELECT COUNT(*) c FROM users")["c"]
        again = onboarding.apply(self.conn, self.loc)
        self.assertEqual(again["created"], 0)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM users")["c"], before)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM period_schedule")["c"], 22)

    def test_somebody_already_there_is_reused_not_duplicated(self):
        db.insert(self.conn, "users", name="محمود", role="employee", location_id=self.loc,
                  telegram_id=99)
        result = onboarding.apply(self.conn, self.loc)
        self.assertEqual(result["created"], 5)
        self.assertEqual(len(db.all_rows(self.conn, "SELECT 1 FROM users WHERE name = 'محمود'")), 1)
        self.assertNotIn("محمود", [name for name, _, _ in result["codes"]])   # already linked

    def test_somebody_switched_off_comes_back(self):
        person = db.insert(self.conn, "users", name="طيبة", role="employee",
                           location_id=self.loc, active=0)
        onboarding.apply(self.conn, self.loc)
        self.assertEqual(db.one(self.conn, "SELECT active FROM users WHERE id = ?",
                                (person,))["active"], 1)

    def test_the_routine_and_its_periods_are_made_once(self):
        onboarding.apply(self.conn, self.loc)
        onboarding.apply(self.conn, self.loc)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM routines")["c"], 1)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM routine_periods")["c"], 7)


class TestThePage(Base):
    def test_it_shows_what_would_happen_before_anything_does(self):
        body = self.client.get("/employees/setup").text
        self.assertIn("سيُضاف", body)
        self.assertIn("أحمد جعفر", body)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM users WHERE role='employee'")["c"], 0)

    def test_pressing_the_button_applies_and_shows_the_codes(self):
        self.client.post("/employees/setup", follow_redirects=False)
        self.assertEqual(len(self.staff()), 6)
        body = self.client.get("/employees/setup").text
        self.assertIn("رموز الربط", body)
        self.assertIn("/start", body)
        self.assertIn("موجود", body)                 # the plan now reads as already there

    def test_the_rota_lands_on_the_periods_page(self):
        self.client.post("/employees/setup", follow_redirects=False)
        board = self.client.get("/periods").text
        for name in ("نرجس", "طيبة", "أحمد جعفر", "محمود"):
            self.assertIn(name, board)

    def test_the_employees_page_points_at_it(self):
        self.assertIn("/employees/setup", self.client.get("/employees").text)

    def test_every_page_works_for_a_branch_manager_too(self):
        """The branch filter has to name its table wherever a query joins."""
        auth.set_password(self.conn, self.mgr, PASSWORD)
        onboarding.apply(self.conn, self.loc)
        from fastapi.testclient import TestClient
        haider = TestClient(self.web.app)
        haider.post("/login", data={"username": "حيدر", "password": PASSWORD})
        for path in ("/", "/today", "/ledger", "/routines", "/periods", "/leaves",
                     "/employees", "/notifications"):
            self.assertEqual(haider.get(path).status_code, 200, path)

    def test_a_branch_manager_cannot_run_it(self):
        auth.set_password(self.conn, self.mgr, PASSWORD)
        from fastapi.testclient import TestClient
        other = TestClient(self.web.app)
        other.post("/login", data={"username": "حيدر", "password": PASSWORD})
        self.assertEqual(other.post("/employees/setup", follow_redirects=False).status_code, 403)
        self.assertEqual(len(self.staff()), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
