"""The bot's menu button: each role is offered only the commands it may use."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import texts  # noqa: E402
from ims.bot import menu  # noqa: E402


def names(role: str | None) -> set[str]:
    return {command.command for command in menu.menu_for(role)}


class TestMenu(unittest.TestCase):
    def test_employees_are_not_offered_new(self):
        self.assertNotIn("new", names("employee"))
        self.assertIn("suggest", names("employee"))        # their way to propose work
        self.assertIn("mytasks", names("employee"))

    def test_managers_are_offered_new(self):
        self.assertIn("new", names("manager"))
        self.assertIn("suggest", names("manager"))         # upward, to the GM

    def test_the_gm_creates_directly_and_suggests_to_nobody(self):
        self.assertIn("new", names("gm"))
        self.assertNotIn("suggest", names("gm"))

    def test_an_unlinked_account_is_only_told_how_to_link(self):
        self.assertEqual(names(None), {"start", "help"})
        self.assertEqual(names("ghost"), {"start", "help"})

    def test_every_command_is_valid_for_telegram(self):
        for role in ("gm", "manager", "employee", None):
            for command in menu.menu_for(role):
                self.assertRegex(command.command, r"^[a-z0-9_]{1,32}$")
                self.assertTrue(0 < len(command.description) <= 256)

    def test_help_text_matches_the_menu(self):
        for role in ("gm", "manager", "employee"):
            body = texts.help_for(role)
            for command in menu.menu_for(role):
                self.assertIn(f"/{command.command}", body)
        self.assertNotIn("/new", texts.help_for("employee"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
