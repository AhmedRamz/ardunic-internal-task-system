"""Starting clean: emptying the board, deleting the placeholders, editing a person."""
from __future__ import annotations

import importlib
import os
import sys
import tempfile
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.core import auth, cleanup  # noqa: E402
from ims.core import periods as P  # noqa: E402
from ims.core import tasks as T  # noqa: E402

WEEK = "sat,sun,mon,tue,wed,thu"
PASSWORD = "test-only-not-a-real-password"


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "test.db")
        conn = db.connect(path)
        db.migrate(conn)
        self.loc = db.insert(conn, "locations", name="الجادرية")
        self.gm = db.insert(conn, "users", name="أحمد", role="gm", location_id=self.loc,
                            telegram_id=1, telegram_username="ahmed")
        self.mgr = db.insert(conn, "users", name="حيدر", role="manager", location_id=self.loc,
                             manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(conn, "users", name="علي", role="employee", location_id=self.loc,
                             manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(conn, "users", name="نور", role="employee", location_id=self.loc,
                              manager_id=self.mgr, telegram_id=4)
        auth.set_password(conn, self.gm, PASSWORD)
        conn.close()

        os.environ["DB_PATH"] = path
        os.environ["SESSION_SECRET"] = "test-secret"
        from ims.web import app as web_app
        self.web = importlib.reload(web_app)
        self.conn = self.web.conn
        from fastapi.testclient import TestClient
        self.client = TestClient(self.web.app)
        self.client.post("/login", data={"username": "ahmed", "password": PASSWORD})

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    def count(self, table, where="1=1", params=()):
        return db.one(self.conn, f"SELECT COUNT(*) c FROM {table} WHERE {where}", params)["c"]

    def busy_board(self):
        first, _ = T.create_task(self.conn, self.gm, "مهمة ١", self.ali)
        T.accept(self.conn, self.ali, first)
        T.add_comment(self.conn, self.ali, first, "ملاحظة")
        T.request_handover(self.conn, self.ali, first, self.noor, "سبب")
        second, _ = T.create_task(self.conn, self.mgr, "مهمة ٢", self.noor)
        from ims.core import notify
        notify.queue(self.conn, T.add_comment(self.conn, self.noor, second, "تعليق"))
        return first, second


class TestClearingTheBoard(Base):
    def test_everything_hanging_off_a_task_goes_with_it(self):
        self.busy_board()
        self.assertTrue(self.count("tasks") and self.count("task_events")
                        and self.count("handovers") and self.count("outbox"))
        removed = cleanup.clear_tasks(self.conn)
        self.assertEqual(removed["tasks"], 2)
        for table in ("tasks", "task_events", "handovers", "task_reads", "outbox"):
            self.assertEqual(self.count(table), 0, table)

    def test_people_routines_and_settings_are_untouched(self):
        routine = db.insert(self.conn, "routines", code="R1", name="روتين",
                            location_id=self.loc, days=WEEK)
        db.insert(self.conn, "routine_owners", routine_id=routine, user_id=self.ali, role="owner")
        self.busy_board()
        cleanup.clear_tasks(self.conn)
        self.assertEqual(self.count("users"), 4)
        self.assertEqual(self.count("routines"), 1)
        self.assertEqual(self.count("routine_owners"), 1)

    def test_the_routine_history_clears_on_its_own(self):
        routine = db.insert(self.conn, "routines", code="R1", name="روتين",
                            location_id=self.loc, days=WEEK)
        P.log_routine(self.conn, self.ali, routine, date(2026, 10, 11), "done", count=5)
        db.insert(self.conn, "checkins", user_id=self.ali, date="2026-10-11", kind="update",
                  answer="working")
        cleanup.clear_routine_history(self.conn)
        self.assertEqual(self.count("routine_logs"), 0)
        self.assertEqual(self.count("checkins"), 0)
        self.assertEqual(self.count("users"), 4)

    def test_the_page_needs_the_word_typed(self):
        self.busy_board()
        self.client.post("/settings/clear", data={"what": "tasks", "confirm": "نعم"})
        self.assertEqual(self.count("tasks"), 2)                      # nothing happened
        self.client.post("/settings/clear", data={"what": "tasks", "confirm": "حذف"})
        self.assertEqual(self.count("tasks"), 0)

    def test_clearing_both_at_once(self):
        routine = db.insert(self.conn, "routines", code="R1", name="روتين",
                            location_id=self.loc, days=WEEK)
        P.log_routine(self.conn, self.ali, routine, date(2026, 10, 11), "done")
        self.busy_board()
        self.client.post("/settings/clear", data={"what": "everything", "confirm": "حذف"})
        self.assertEqual((self.count("tasks"), self.count("routine_logs")), (0, 0))


class TestDeletingAPlaceholder(Base):
    def test_a_person_with_board_history_is_refused(self):
        self.busy_board()
        with self.assertRaises(ValueError):
            cleanup.delete_person(self.conn, self.ali)
        self.assertEqual(self.count("users", "id = ?", (self.ali,)), 1)

    def test_once_the_board_is_clear_they_can_go(self):
        routine = db.insert(self.conn, "routines", code="R1", name="روتين",
                            location_id=self.loc, days=WEEK)
        period = db.insert(self.conn, "routine_periods", routine_id=routine, name="مسائية",
                           days=WEEK, start_time="17:00", end_time="20:00")
        db.insert(self.conn, "period_schedule", period_id=period, weekday="sun", user_id=self.ali)
        db.insert(self.conn, "routine_owners", routine_id=routine, user_id=self.ali, role="owner")
        P.set_fixed_day_off(self.conn, self.ali, "mon")
        P.set_day_off(self.conn, self.gm, self.ali, date(2026, 10, 13), True)
        self.busy_board()

        cleanup.clear_tasks(self.conn)
        cleanup.delete_person(self.conn, self.ali)
        self.assertEqual(self.count("users", "id = ?", (self.ali,)), 0)
        self.assertEqual(self.count("period_schedule", "user_id = ?", (self.ali,)), 0)
        self.assertEqual(self.count("routine_owners", "user_id = ?", (self.ali,)), 0)
        self.assertEqual(self.count("days_off", "user_id = ?", (self.ali,)), 0)
        self.assertEqual(self.count("routines"), 1)                   # the routine itself stays

    def test_the_page_needs_the_word_and_spares_the_gm(self):
        self.client.post(f"/employees/{self.ali}/delete", data={"confirm": "نعم"})
        self.assertEqual(self.count("users", "id = ?", (self.ali,)), 1)
        self.client.post(f"/employees/{self.gm}/delete", data={"confirm": "حذف"})
        self.assertEqual(self.count("users", "id = ?", (self.gm,)), 1)
        self.client.post(f"/employees/{self.ali}/delete", data={"confirm": "حذف"})
        self.assertEqual(self.count("users", "id = ?", (self.ali,)), 0)

    def test_whoever_they_managed_is_left_without_a_manager_not_broken(self):
        cleanup.delete_person(self.conn, self.mgr)
        self.assertIsNone(db.one(self.conn, "SELECT manager_id FROM users WHERE id = ?",
                                 (self.ali,))["manager_id"])


class TestEditingAPerson(Base):
    def person(self):
        return db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.ali,))

    def test_name_handle_and_role(self):
        self.client.post(f"/employees/{self.ali}/edit",
                         data={"name": "Ali Hassan", "telegram": "@ali_h", "role": "manager"})
        again = self.person()
        self.assertEqual((again["name"], again["telegram_username"], again["role"]),
                         ("Ali Hassan", "ali_h", "manager"))

    def test_an_empty_name_is_refused(self):
        self.client.post(f"/employees/{self.ali}/edit", data={"name": "   "})
        self.assertEqual(self.person()["name"], "علي")

    def test_unlinking_stops_the_bot_and_keeps_the_person(self):
        self.client.post(f"/employees/{self.ali}/unlink")
        self.assertIsNone(self.person()["telegram_id"])
        self.assertEqual(self.person()["name"], "علي")
        from ims.core import notify
        self.assertFalse(notify.queue_raw(self.conn, self.ali, "مرحباً"))

    def test_unlinking_can_hand_back_a_fresh_code(self):
        response = self.client.post(f"/employees/{self.ali}/unlink", data={"issue_code": "1"},
                                    follow_redirects=False)
        self.assertIn("code=", response.headers["location"])
        self.assertTrue(self.person()["link_code"])


class TestTodayShowsDuties(Base):
    def setUp(self) -> None:
        super().setUp()
        self.day = date(2026, 10, 11)                       # a Sunday
        self.routine = db.insert(self.conn, "routines", code="R2", name="تجهيز الطلبات",
                                 location_id=self.loc, days=WEEK, checkin_time="16:30",
                                 count_label="الطلبات")
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.ali]})
        r1 = db.insert(self.conn, "routines", code="R1", name="الرد على العملاء",
                       location_id=self.loc, days=WEEK)
        self.period = db.insert(self.conn, "routine_periods", routine_id=r1, name="مسائية",
                                days=WEEK, start_time="17:00", end_time="20:00")
        db.insert(self.conn, "period_schedule", period_id=self.period, weekday="sun",
                  user_id=self.ali)

    def at(self, hour, minute=0):
        return datetime(self.day.year, self.day.month, self.day.day, hour, minute, tzinfo=texts.TZ)

    def test_a_duty_not_yet_asked_is_waiting_not_missing(self):
        duties = P.duties_today(self.conn, self.ali, self.at(10, 0))
        self.assertEqual([d["state"] for d in duties], ["waiting", "waiting"])
        self.assertIn("R2", " ".join(d["label"] for d in duties))

    def test_once_its_time_has_passed_it_is_waiting_for_an_answer(self):
        duties = P.duties_today(self.conn, self.ali, self.at(16, 45))
        states = {d["label"].split(" ")[0]: d["state"] for d in duties}
        self.assertEqual(states["R2"], "late")
        self.assertEqual(states["R1"], "waiting")               # the period ends at 20:00

    def test_an_answer_shows_with_its_count(self):
        P.log_routine(self.conn, self.ali, self.routine, self.day, "done", count=14)
        duty = [d for d in P.duties_today(self.conn, self.ali, self.at(17, 0))
                if d["label"].startswith("R2")][0]
        self.assertEqual(duty["state"], "done")
        self.assertEqual(duty["answer"]["count"], 14)

    def test_they_are_listed_in_the_order_they_are_asked(self):
        duties = P.duties_today(self.conn, self.ali, self.at(9, 0))
        self.assertEqual([d["due"].strftime("%H:%M") for d in duties], ["16:30", "19:45"])

    def test_someone_with_nothing_on_today_has_no_duties(self):
        self.assertEqual(P.duties_today(self.conn, self.noor, self.at(16, 45)), [])

    def test_the_page_renders_the_duties(self):
        body = self.client.get("/today").text
        self.assertIn("روتين اليوم", body)
        self.assertIn("فترات اليوم", body)


if __name__ == "__main__":
    unittest.main(verbosity=2)
