"""Routines and periods: who holds one, the cover chain, leaves, and the clock.

The whole day is replayed against a fake clock, Friday's four periods included,
so the social-media rota can be checked without waiting for 11:45 at night.
"""
from __future__ import annotations

import sys
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.bot import keyboards  # noqa: E402
from ims.bot import scheduler  # noqa: E402
from ims.core import periods as P  # noqa: E402
from ims.core import schedule  # noqa: E402

SUNDAY = date(2026, 10, 11)
FRIDAY = date(2026, 10, 16)

WEEK = "sat,sun,mon,tue,wed,thu"
SHIFTS = [("صباحية", WEEK, "08:00", "17:00"),
          ("مسائية", WEEK, "17:00", "20:00"),
          ("ليلية", WEEK, "20:00", "23:59"),
          ("الجمعة ف1", "fri", "08:00", "12:00"),
          ("الجمعة ف2", "fri", "12:00", "16:00"),
          ("الجمعة ف3", "fri", "16:00", "20:00"),
          ("الجمعة ف4", "fri", "20:00", "23:59")]


def clock(day: date, hour: int, minute: int = 0) -> datetime:
    return datetime(day.year, day.month, day.day, hour, minute, tzinfo=texts.TZ)


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        self.loc = db.insert(self.conn, "locations", name="الجادرية")
        self.gm = db.insert(self.conn, "users", name="أحمد", role="gm",
                            location_id=self.loc, telegram_id=1)
        self.mgr = db.insert(self.conn, "users", name="حيدر", role="manager",
                             location_id=self.loc, manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(self.conn, "users", name="علي", role="employee",
                             location_id=self.loc, manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(self.conn, "users", name="نور", role="employee",
                              location_id=self.loc, manager_id=self.mgr, telegram_id=4)
        self.zain = db.insert(self.conn, "users", name="زينب", role="employee",
                              location_id=self.loc, manager_id=self.mgr, telegram_id=5)
        db.insert(self.conn, "settings", key="swap_deadline_hours", value="2")

        self.r1 = db.insert(self.conn, "routines", code="R1",
                            name="الرد على العملاء وتتبع الطلبات", location_id=self.loc,
                            days="sat,sun,mon,tue,wed,thu,fri", count_label="محادثات")
        self.period = {}
        for name, days, start, end in SHIFTS:
            self.period[name] = db.insert(self.conn, "routine_periods", routine_id=self.r1,
                                          name=name, days=days, start_time=start, end_time=end)
        # the weekly board: Ali mornings, Noor evenings, Zainab nights
        for weekday in WEEK.split(","):
            self.assign("صباحية", weekday, self.ali)
            self.assign("مسائية", weekday, self.noor)
            self.assign("ليلية", weekday, self.zain)

    def assign(self, period_name: str, weekday: str, user_id: int | None) -> None:
        db.insert(self.conn, "period_schedule", period_id=self.period[period_name],
                  weekday=weekday, user_id=user_id)

    def queued(self) -> list[tuple[int, str]]:
        return [(r["user_id"], r["body"]) for r in
                db.all_rows(self.conn, "SELECT user_id, body FROM outbox ORDER BY id")]

    def for_user(self, user_id: int) -> list[str]:
        return [body for who, body in self.queued() if who == user_id]


class TestWhoHoldsIt(Base):
    def test_the_board_decides_by_weekday(self):
        self.assertEqual(P.holder(self.conn, self.period["مسائية"], SUNDAY)["id"], self.noor)

    def test_a_period_that_does_not_run_today_is_not_listed(self):
        names = {p["name"] for p in P.periods_for(self.conn, SUNDAY)}
        self.assertEqual(names, {"صباحية", "مسائية", "ليلية"})

    def test_friday_has_four_equal_periods(self):
        friday = P.periods_for(self.conn, FRIDAY)
        self.assertEqual([p["name"] for p in friday],
                         ["الجمعة ف1", "الجمعة ف2", "الجمعة ف3", "الجمعة ف4"])
        for period in friday:
            span = P.end_at(period, FRIDAY) - P.start_at(period, FRIDAY)
            self.assertAlmostEqual(span.total_seconds() / 3600, 4, delta=0.02)

    def test_an_unassigned_period_is_a_gap(self):
        self.assertEqual([p["name"] for p in P.gaps(self.conn, FRIDAY, self.loc)],
                         ["الجمعة ف1", "الجمعة ف2", "الجمعة ف3", "الجمعة ف4"])

    def test_an_override_beats_the_board_for_that_date_only(self):
        P.set_holder(self.conn, self.period["مسائية"], SUNDAY, self.zain, actor_id=self.mgr)
        self.assertEqual(P.holder(self.conn, self.period["مسائية"], SUNDAY)["id"], self.zain)
        later = SUNDAY + timedelta(days=7)
        self.assertEqual(P.holder(self.conn, self.period["مسائية"], later)["id"], self.noor)

    def test_my_periods_lists_the_week_ahead(self):
        mine = P.my_periods(self.conn, self.noor, SUNDAY, days=7)
        self.assertTrue(all(entry["period"]["name"] == "مسائية" for entry in mine))
        self.assertEqual(len(mine), 6)                  # Sat–Thu, never Friday


class TestCoverChain(Base):
    def setUp(self) -> None:
        super().setUp()
        self.day = SUNDAY
        self.evening = self.period["مسائية"]

    def ask(self, now=None):
        return P.request_cover(self.conn, self.noor, self.evening, self.day, self.zain,
                               "عندي امتحان", now=now or clock(self.day, 9))

    def test_two_hour_deadline(self):
        with self.assertRaises(P.RuleError):
            self.ask(now=clock(self.day, 15, 30))        # the period starts at 17:00
        request_id, messages = self.ask(now=clock(self.day, 14, 59))
        self.assertEqual(messages[0].user_id, self.zain)
        self.assertEqual(messages[0].keyboard, f"cover:{request_id}")

    def test_both_yeses_move_it_and_only_for_that_date(self):
        request_id, _ = self.ask()
        self.assertEqual(P.holder(self.conn, self.evening, self.day)["id"], self.noor)

        P.colleague_accepts(self.conn, self.zain, request_id)
        self.assertEqual(P.holder(self.conn, self.evening, self.day)["id"], self.noor)  # not yet

        P.manager_approves(self.conn, self.mgr, request_id)
        self.assertEqual(P.holder(self.conn, self.evening, self.day)["id"], self.zain)
        next_week = self.day + timedelta(days=7)
        self.assertEqual(P.holder(self.conn, self.evening, next_week)["id"], self.noor)

    def test_the_manager_hears_only_after_the_colleague_agrees(self):
        request_id, _ = self.ask()
        messages = P.colleague_accepts(self.conn, self.zain, request_id)
        told = {m.user_id for m in messages}
        self.assertEqual(told, {self.mgr, self.gm, self.noor})

    def test_a_colleague_may_refuse(self):
        request_id, _ = self.ask()
        messages = P.colleague_declines(self.conn, self.zain, request_id, "عندي ارتباط")
        self.assertEqual(P.holder(self.conn, self.evening, self.day)["id"], self.noor)
        self.assertEqual(messages[0].user_id, self.noor)
        self.assertIn("عندي ارتباط", messages[0].body)

    def test_the_manager_may_refuse(self):
        request_id, _ = self.ask()
        P.colleague_accepts(self.conn, self.zain, request_id)
        P.manager_declines(self.conn, self.mgr, request_id, "الفترة مزدحمة")
        self.assertEqual(P.holder(self.conn, self.evening, self.day)["id"], self.noor)

    def test_only_the_holder_may_ask(self):
        with self.assertRaises(P.RuleError):            # Ali does not hold the evening
            P.request_cover(self.conn, self.ali, self.evening, self.day, self.zain, "",
                            now=clock(self.day, 9))

    def overlapping_period_for(self, user_id):
        """A second routine whose period sits inside the evening one."""
        other = db.insert(self.conn, "routines", code="R2", name="جرد الرفوف",
                          location_id=self.loc, days=WEEK)
        period = db.insert(self.conn, "routine_periods", routine_id=other, name="جرد",
                           days=WEEK, start_time="18:00", end_time="19:00")
        db.insert(self.conn, "period_schedule", period_id=period, weekday="sun", user_id=user_id)

    def test_a_colleague_busy_at_the_same_hour_cannot_be_asked(self):
        self.overlapping_period_for(self.zain)
        with self.assertRaises(P.RuleError):
            P.request_cover(self.conn, self.noor, self.evening, self.day, self.zain, "",
                            now=clock(self.day, 9))

    def test_candidates_exclude_the_busy_and_the_requester(self):
        self.overlapping_period_for(self.zain)
        noor = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.noor,))
        names = {p["name"] for p in P.cover_candidates(self.conn, noor, self.evening, self.day)}
        self.assertEqual(names, {"علي"})                # Zainab is busy 18:00–19:00, Noor is asking

    def test_one_open_request_per_period(self):
        self.ask()
        with self.assertRaises(P.RuleError):
            self.ask()

    def test_an_unanswered_request_expires_when_the_period_starts(self):
        self.ask()
        self.assertEqual(P.expire_requests(self.conn, clock(self.day, 16)), [])
        messages = P.expire_requests(self.conn, clock(self.day, 17, 1))
        self.assertEqual(messages[0].user_id, self.noor)
        self.assertEqual(P.holder(self.conn, self.evening, self.day)["id"], self.noor)


class TestLeaves(Base):
    def test_cover_is_recorded_and_everyone_is_told(self):
        start, end = SUNDAY, SUNDAY + timedelta(days=1)
        affected = P.periods_during_leave(self.conn, self.ali, start, end)
        self.assertEqual(len(affected), 2)              # the morning on both days
        cover = {(entry["period"]["id"], entry["date"].isoformat()): self.zain
                 for entry in affected}
        _, messages = P.record_leave(self.conn, self.mgr, self.ali, start, end, cover=cover)
        self.assertEqual(P.holder(self.conn, self.period["صباحية"], SUNDAY)["id"], self.zain)
        self.assertIn(self.zain, {m.user_id for m in messages})
        self.assertIn(self.ali, {m.user_id for m in messages})
        self.assertTrue(P.on_leave(self.conn, self.ali, SUNDAY))

    def test_a_period_left_uncovered_becomes_a_gap_and_warns_the_gm(self):
        _, messages = P.record_leave(self.conn, self.mgr, self.ali, SUNDAY, SUNDAY)
        self.assertIsNone(P.holder(self.conn, self.period["صباحية"], SUNDAY))
        warning = [m for m in messages if m.user_id == self.gm]
        self.assertTrue(warning and "بلا مسؤول" in warning[0].body)

    def test_the_board_is_untouched_after_the_leave_ends(self):
        P.record_leave(self.conn, self.mgr, self.ali, SUNDAY, SUNDAY)
        self.assertEqual(P.holder(self.conn, self.period["صباحية"],
                                  SUNDAY + timedelta(days=7))["id"], self.ali)

    def test_only_a_manager_records_one(self):
        with self.assertRaises(P.RuleError):
            P.record_leave(self.conn, self.ali, self.noor, SUNDAY, SUNDAY)


class TestTheClock(Base):
    def tick(self, now):
        return scheduler._dispatch_periods(self.conn, now)

    def test_the_checkin_lands_fifteen_minutes_before_the_end(self):
        self.assertEqual(self.tick(clock(SUNDAY, 16, 30)), 0)       # morning ends at 17:00
        self.assertEqual(self.tick(clock(SUNDAY, 16, 45)), 1)
        self.assertEqual(self.for_user(self.ali)[0].count("نهاية فترة"), 1)

    def test_it_is_asked_once_a_day(self):
        self.tick(clock(SUNDAY, 16, 45))
        self.assertEqual(self.tick(clock(SUNDAY, 16, 46)), 0)
        self.assertEqual(len(self.for_user(self.ali)), 1)

    def test_a_whole_sunday(self):
        for hour, minute in ((16, 45), (19, 45), (23, 44)):
            self.tick(clock(SUNDAY, hour, minute))
        self.assertEqual([len(self.for_user(u)) for u in (self.ali, self.noor, self.zain)],
                         [1, 1, 1])

    def test_friday_asks_four_people_and_flags_the_empty_ones(self):
        for name, who in (("الجمعة ف1", self.ali), ("الجمعة ف2", self.noor),
                          ("الجمعة ف3", self.zain)):
            db.insert(self.conn, "period_schedule", period_id=self.period[name],
                      weekday="fri", user_id=who)
        self.tick(clock(FRIDAY, 8, 1))                   # ف1 has started
        self.tick(clock(FRIDAY, 11, 45))
        self.tick(clock(FRIDAY, 15, 45))
        self.tick(clock(FRIDAY, 19, 45))
        self.tick(clock(FRIDAY, 20, 1))                  # ف4 starts with nobody on it
        self.assertEqual(len(self.for_user(self.ali)), 1)
        gap = [b for b in self.for_user(self.mgr) if "بلا مسؤول" in b]
        self.assertEqual(len(gap), 1)
        self.assertIn("الجمعة ف4", gap[0])

    def test_a_check_in_missed_by_hours_is_dropped_not_asked_late(self):
        self.assertEqual(self.tick(clock(SUNDAY, 23, 50)), 1)       # only the night one is in time
        self.assertEqual(self.for_user(self.ali), [])
        self.assertTrue(P.has_run(self.conn, self.period["صباحية"], SUNDAY, "checkin"))

    def test_the_person_covering_is_the_one_asked(self):
        P.set_holder(self.conn, self.period["مسائية"], SUNDAY, self.zain, reason="swap",
                     actor_id=self.mgr)
        self.tick(clock(SUNDAY, 19, 45))
        self.assertEqual(self.for_user(self.noor), [])
        self.assertIn("تغطية بدلاً عن نور", self.for_user(self.zain)[0])


class TestTheLog(Base):
    def test_an_answer_is_stored_and_replaces_an_earlier_one(self):
        P.log_period(self.conn, self.ali, self.period["صباحية"], SUNDAY, "partly", note="انقطع النت")
        P.log_period(self.conn, self.ali, self.period["صباحية"], SUNDAY, "done", count=37)
        rows = P.logs_for(self.conn, SUNDAY, self.loc)
        self.assertEqual(len(rows), 1)
        self.assertEqual((rows[0]["result"], rows[0]["count"]), ("done", 37))

    def test_a_cover_is_recorded_against_the_person_it_covers_for(self):
        P.set_holder(self.conn, self.period["مسائية"], SUNDAY, self.zain, reason="swap",
                     actor_id=self.mgr)
        P.log_period(self.conn, self.zain, self.period["مسائية"], SUNDAY, "done", count=12)
        row = P.logs_for(self.conn, SUNDAY, self.loc)[0]
        self.assertEqual(row["covering_name"], "نور")

    def test_an_unknown_result_is_refused(self):
        with self.assertRaises(P.RuleError):
            P.log_period(self.conn, self.ali, self.period["صباحية"], SUNDAY, "maybe")


class TestTheDailyMessages(Base):
    def test_the_morning_brief_lists_todays_periods(self):
        ali = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.ali,))
        brief = schedule.brief_for(self.conn, ali, clock(SUNDAY, 9))
        self.assertIn("فتراتك اليوم", brief)
        self.assertIn("صباحية 08:00–17:00", brief)

    def test_someone_with_no_tasks_still_gets_their_period(self):
        zain = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.zain,))
        self.assertIn("ليلية", schedule.brief_for(self.conn, zain, clock(SUNDAY, 9)))

    def test_the_day_report_shows_how_the_finished_periods_went(self):
        P.log_period(self.conn, self.ali, self.period["صباحية"], SUNDAY, "done", count=41)
        report = schedule.day_report(self.conn, self.loc, clock(SUNDAY, 17, 0))
        self.assertIn("الفترات المنتهية", report)
        self.assertIn("تمت · 41", report)
        self.assertNotIn("ليلية", report)              # it has not ended yet

    def test_a_period_that_ended_with_no_answer_is_flagged(self):
        report = schedule.day_report(self.conn, self.loc, clock(SUNDAY, 20, 30))
        self.assertIn("بلا رد", report)


class TestTheButtons(Base):
    """What the outbox attaches to a period message."""

    def labels(self, markup):
        return [] if markup is None else [b.text for row in markup.inline_keyboard for b in row]

    def test_a_check_in_carries_the_four_answers(self):
        kind = f"pck:{self.period['صباحية']}:{SUNDAY.isoformat()}"
        markup = keyboards.for_kind(kind, None, None, conn=self.conn)
        self.assertEqual(self.labels(markup), ["✅ تمت", "⚠️ جزئياً", "🚫 لا شيء اليوم", "❌ لم تتم"])
        self.assertTrue(all(SUNDAY.isoformat() in b.callback_data
                            for row in markup.inline_keyboard for b in row))

    def test_a_cover_request_shows_the_stage_it_is_at(self):
        request_id, _ = P.request_cover(self.conn, self.noor, self.period["مسائية"], SUNDAY,
                                        self.zain, "عندي امتحان", now=clock(SUNDAY, 9))
        kind = f"cover:{request_id}"
        self.assertEqual(self.labels(keyboards.for_kind(kind, None, None, conn=self.conn)),
                         ["✅ أغطيها", "❌ لا أستطيع"])
        P.colleague_accepts(self.conn, self.zain, request_id)
        self.assertEqual(self.labels(keyboards.for_kind(kind, None, None, conn=self.conn)),
                         ["✅ موافقة", "❌ رفض"])
        P.manager_approves(self.conn, self.mgr, request_id)
        self.assertIsNone(keyboards.for_kind(kind, None, None, conn=self.conn))   # settled: no buttons


if __name__ == "__main__":
    unittest.main(verbosity=2)
