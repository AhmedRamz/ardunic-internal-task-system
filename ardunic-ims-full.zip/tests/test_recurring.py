"""The four kinds of work: عادية، دورية، روتينية، مجدولة.

دورية keeps its periods and rota. The other two become ordinary tasks on
purpose — so the board, the ledger, the bot buttons and the reports carry them
without a second mechanism.
"""
from __future__ import annotations

import importlib
import os
import sys
import tempfile
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.bot import scheduler  # noqa: E402
from ims.core import auth  # noqa: E402
from ims.core import periods as P  # noqa: E402
from ims.core import recurring as R  # noqa: E402
from ims.core import tasks as T  # noqa: E402

WEEK = "sat,sun,mon,tue,wed,thu"
PASSWORD = "test-only-not-a-real-password"
SUNDAY = date(2026, 10, 11)


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "test.db")
        conn = db.connect(path)
        db.migrate(conn)
        self.loc = db.insert(conn, "locations", name="الجادرية")
        self.gm = db.insert(conn, "users", name="أحمد", role="gm", location_id=self.loc,
                            telegram_id=1, telegram_username="ahmed")
        self.mgr = db.insert(conn, "users", name="حيدر", role="manager", location_id=self.loc,
                             manager_id=self.gm, telegram_id=2)
        self.mahmood = db.insert(conn, "users", name="محمود", role="employee",
                                 location_id=self.loc, manager_id=self.mgr, telegram_id=3)
        self.teeba = db.insert(conn, "users", name="طيبة", role="employee",
                               location_id=self.loc, manager_id=self.mgr, telegram_id=4)
        auth.set_password(conn, self.gm, PASSWORD)
        conn.close()

        os.environ["DB_PATH"] = path
        os.environ["SESSION_SECRET"] = "test-secret"
        from ims.web import app as web_app
        self.web = importlib.reload(web_app)
        self.conn = self.web.conn
        from fastapi.testclient import TestClient
        self.client = TestClient(self.web.app)
        self.client.post("/login", data={"username": "ahmed", "password": PASSWORD})

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    def template(self, kind, **extra):
        fields = {"code": extra.pop("code", "R9"), "name": extra.pop("name", "عمل متكرر"),
                  "location_id": self.loc, "days": WEEK, "kind": kind}
        fields.update(extra)
        routine_id = db.insert(self.conn, "routines", **fields)
        return db.one(self.conn, "SELECT * FROM routines WHERE id = ?", (routine_id,))

    def task(self, task_id):
        return db.one(self.conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))


class TestRoutineKind(Base):
    """روتينية — starts when a shipment lands, then runs for days."""

    def setUp(self) -> None:
        super().setUp()
        self.routine = self.template(R.ROUTINE, code="R5", name="استلام شحنة وفرزها وإدخالها",
                                     expected_days=3, default_assignee=self.mahmood)

    def test_starting_one_makes_a_task_for_the_default_person(self):
        task_id, event = R.start_run(self.conn, self.gm, self.routine["id"],
                                     reference="شحنة 412", now=datetime(2026, 10, 11, 10,
                                                                        tzinfo=texts.TZ))
        row = self.task(task_id)
        self.assertEqual(row["title"], "استلام شحنة وفرزها وإدخالها — شحنة 412")
        self.assertEqual(row["assignee_id"], self.mahmood)
        self.assertEqual((row["kind"], row["template_id"], row["expected_days"]),
                         (R.ROUTINE, self.routine["id"], 3))
        self.assertEqual(row["due_at"], "2026-10-13 17:00")          # three days, last at 17:00
        self.assertIn(self.mahmood, event.recipients)                # told on the bot at once

    def test_it_behaves_like_any_other_task(self):
        task_id, _ = R.start_run(self.conn, self.gm, self.routine["id"], reference="شحنة 1")
        T.accept(self.conn, self.mahmood, task_id)
        T.add_comment(self.conn, self.mahmood, task_id, "فُتحت الصناديق")
        T.mark_done(self.conn, self.mahmood, task_id)
        self.assertEqual(self.task(task_id)["status"], T.DONE)
        self.assertIn("شحنة 1", self.client.get("/ledger").text)

    def test_the_day_counter_counts_from_the_start(self):
        task_id, _ = R.start_run(self.conn, self.gm, self.routine["id"],
                                 now=datetime(2026, 10, 11, 9, tzinfo=texts.TZ))
        db.update(self.conn, "tasks", task_id, created_at="2026-10-11 09:00:00")
        row = self.task(task_id)
        self.assertEqual(R.day_number(row, SUNDAY), (1, 3))
        self.assertEqual(R.day_number(row, SUNDAY + timedelta(days=2)), (3, 3))
        # a run that overruns says so rather than pretending it is on day 3
        self.assertEqual(R.day_number(row, SUNDAY + timedelta(days=5)), (6, 6))

    def test_a_different_person_and_length_can_be_chosen_when_starting(self):
        task_id, _ = R.start_run(self.conn, self.gm, self.routine["id"],
                                 assignee_id=self.teeba, days=5)
        row = self.task(task_id)
        self.assertEqual((row["assignee_id"], row["expected_days"]), (self.teeba, 5))

    def test_it_will_not_start_without_somebody(self):
        orphan = self.template(R.ROUTINE, code="R6", name="بلا مسؤول")
        with self.assertRaises(R.RuleError):
            R.start_run(self.conn, self.gm, orphan["id"])

    def test_a_periodic_template_cannot_be_started_by_hand(self):
        periodic = self.template(R.PERIODIC, code="R1", name="الرد على العملاء")
        with self.assertRaises(R.RuleError):
            R.start_run(self.conn, self.gm, periodic["id"], assignee_id=self.mahmood)

    def test_the_page_starts_one_and_lands_on_it(self):
        response = self.client.post(f"/routines/{self.routine['id']}",
                                    data={"action": "start", "reference": "شحنة 7",
                                          "assignee": self.teeba, "days": "2"},
                                    follow_redirects=False)
        self.assertEqual(response.status_code, 303)
        self.assertIn("/tasks/", response.headers["location"])
        row = db.one(self.conn, "SELECT * FROM tasks ORDER BY id DESC LIMIT 1")
        self.assertEqual((row["assignee_id"], row["expected_days"]), (self.teeba, 2))

    def test_open_runs_are_listed_against_the_template(self):
        first, _ = R.start_run(self.conn, self.gm, self.routine["id"], reference="١")
        second, _ = R.start_run(self.conn, self.gm, self.routine["id"], reference="٢")
        T.accept(self.conn, self.mahmood, second)
        T.mark_done(self.conn, self.mahmood, second)
        self.assertEqual([r["id"] for r in R.open_runs(self.conn, self.routine["id"])], [first])
        self.assertEqual(len(R.history(self.conn, self.routine["id"])), 2)


class TestScheduledKind(Base):
    """مجدولة — the system opens it on its cycle and the usual chasing takes over."""

    def at(self, day: date, hour: int = 9):
        return datetime(day.year, day.month, day.day, hour, tzinfo=texts.TZ)

    def test_a_monthly_one_opens_on_its_day_only(self):
        monthly = self.template(R.SCHEDULED, code="R7", name="الجرد الشهري",
                                cycle="monthly", cycle_day=1, default_assignee=self.teeba)
        self.assertFalse(R.falls_on(monthly, date(2026, 10, 11)))
        self.assertTrue(R.falls_on(monthly, date(2026, 11, 1)))
        self.assertEqual(R.next_due(monthly, date(2026, 10, 11)), date(2026, 11, 1))

    def test_a_weekly_one_opens_on_its_weekday(self):
        weekly = self.template(R.SCHEDULED, code="R8", name="دفعة المورد",
                               cycle="weekly", cycle_day=P.ALL_WEEKDAYS.index("tue"),
                               default_assignee=self.teeba)
        self.assertTrue(R.falls_on(weekly, date(2026, 10, 13)))       # a Tuesday
        self.assertFalse(R.falls_on(weekly, date(2026, 10, 14)))
        self.assertEqual(R.cycle_label(weekly), "كل الثلاثاء")

    def test_a_day_past_the_end_of_a_short_month_lands_on_its_last_day(self):
        monthly = self.template(R.SCHEDULED, code="R7", name="الجرد", cycle="monthly",
                                cycle_day=28, default_assignee=self.teeba)
        self.assertTrue(R.falls_on(monthly, date(2026, 2, 28)))

    def test_the_clock_opens_it_once_and_tells_the_person(self):
        self.template(R.SCHEDULED, code="R7", name="الجرد الشهري", cycle="monthly",
                      cycle_day=11, default_assignee=self.teeba, expected_days=2)
        made = scheduler._open_scheduled(self.conn, self.at(SUNDAY))
        self.assertEqual(made, 1)
        row = db.one(self.conn, "SELECT * FROM tasks ORDER BY id DESC LIMIT 1")
        self.assertEqual((row["kind"], row["assignee_id"]), (R.SCHEDULED, self.teeba))
        self.assertEqual(row["due_at"], "2026-10-12 17:00")
        self.assertEqual(scheduler._open_scheduled(self.conn, self.at(SUNDAY, 15)), 0)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM tasks")["c"], 1)

    def test_it_opens_again_next_cycle(self):
        self.template(R.SCHEDULED, code="R8", name="أسبوعية", cycle="weekly",
                      cycle_day=P.ALL_WEEKDAYS.index("sun"), default_assignee=self.teeba)
        scheduler._open_scheduled(self.conn, self.at(SUNDAY))
        scheduler._open_scheduled(self.conn, self.at(SUNDAY + timedelta(days=7)))
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM tasks")["c"], 2)

    def test_one_with_nobody_assigned_is_flagged_not_opened(self):
        self.template(R.SCHEDULED, code="R9", name="بلا مسؤول", cycle="monthly", cycle_day=11)
        self.assertEqual(scheduler._open_scheduled(self.conn, self.at(SUNDAY)), 0)
        self.assertEqual(db.one(self.conn, "SELECT COUNT(*) c FROM tasks")["c"], 0)


class TestTheKindsStayApart(Base):
    def test_only_periodic_templates_are_asked_about_daily(self):
        self.template(R.PERIODIC, code="R2", name="تجهيز الطلبات", checkin_time="16:30")
        self.template(R.ROUTINE, code="R5", name="استلام شحنة", default_assignee=self.mahmood)
        self.template(R.SCHEDULED, code="R7", name="الجرد", cycle="monthly", cycle_day=11,
                      default_assignee=self.teeba)
        asked = [item["routine"]["code"]
                 for item in P.due_routine_checkins(self.conn, datetime(2026, 10, 11, 17,
                                                                        tzinfo=texts.TZ))]
        self.assertEqual(asked, ["R2"])

    def test_each_kind_has_its_own_section_on_the_page(self):
        self.template(R.PERIODIC, code="R1", name="الرد على العملاء")
        self.template(R.ROUTINE, code="R5", name="استلام شحنة", default_assignee=self.mahmood)
        self.template(R.SCHEDULED, code="R7", name="الجرد الشهري", cycle="monthly",
                      cycle_day=1, default_assignee=self.teeba)
        body = self.client.get("/routines").text
        for heading in ("المهام الدورية", "المهام الروتينية", "المهام المجدولة"):
            self.assertIn(heading, body)
        for name in ("الرد على العملاء", "استلام شحنة", "الجرد الشهري"):
            self.assertIn(name, body)

    def test_creating_each_kind_from_the_page(self):
        self.client.post("/routines", data={
            "kind": "routine", "code": "R5", "name": "إرسال مواد لفرع الصناعة",
            "expected_days": "2", "default_assignee": self.mahmood})
        made = db.one(self.conn, "SELECT * FROM routines WHERE code = 'R5'")
        self.assertEqual((R.kind_of(made), R.expected_days(made), made["default_assignee"]),
                         (R.ROUTINE, 2, self.mahmood))

        self.client.post("/routines", data={
            "kind": "scheduled", "code": "R7", "name": "الجرد الشهري", "cycle": "monthly",
            "cycle_day": "3", "expected_days": "1", "default_assignee": self.teeba})
        made = db.one(self.conn, "SELECT * FROM routines WHERE code = 'R7'")
        self.assertEqual((R.kind_of(made), R.cycle_of(made), R.cycle_day(made)),
                         (R.SCHEDULED, "monthly", 3))

    def test_a_run_shows_its_kind_on_the_board_and_in_the_ledger(self):
        routine = self.template(R.ROUTINE, code="R5", name="استلام شحنة",
                                default_assignee=self.mahmood, expected_days=2)
        R.start_run(self.conn, self.gm, routine["id"], reference="412")
        board = self.client.get("/").text
        self.assertIn("روتينية", board)
        self.assertIn("اليوم 1 من 2", board)
        self.assertIn("روتينية", self.client.get("/ledger").text)

    def test_a_template_can_be_moved_to_another_kind(self):
        plain = self.template(R.PERIODIC, code="R5", name="فرز الشحنات")
        R.change_kind(self.conn, plain["id"], R.ROUTINE)
        self.assertEqual(R.kind_of(db.one(self.conn, "SELECT * FROM routines WHERE id = ?",
                                          (plain["id"],))), R.ROUTINE)

    def test_one_with_periods_or_a_rota_will_not_move_until_they_are_cleared(self):
        busy = self.template(R.PERIODIC, code="R1", name="الرد على العملاء")
        period = P.add_period(self.conn, busy["id"], name="مسائية", days=WEEK,
                              start="17:00", end="20:00")
        with self.assertRaises(R.RuleError):
            R.change_kind(self.conn, busy["id"], R.ROUTINE)

        P.remove_period(self.conn, period)
        P.set_routine_rota(self.conn, busy["id"], {"sun": [self.teeba]})
        with self.assertRaises(R.RuleError):
            R.change_kind(self.conn, busy["id"], R.ROUTINE)

        P.set_routine_rota(self.conn, busy["id"], {})
        R.change_kind(self.conn, busy["id"], R.ROUTINE)         # now it moves

    def test_an_ordinary_task_is_untouched_by_any_of_this(self):
        task_id, _ = T.create_task(self.conn, self.gm, "مهمة عادية", self.mahmood)
        row = self.task(task_id)
        self.assertEqual(row["kind"], "normal")
        self.assertIsNone(row["template_id"])
        self.assertIsNone(R.day_number(row))


if __name__ == "__main__":
    unittest.main(verbosity=2)
