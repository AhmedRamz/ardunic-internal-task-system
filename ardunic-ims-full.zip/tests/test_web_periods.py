"""The dashboard pages that change a period: approving a cover, recording a leave.

These two post hand-written form fields, so they are driven through a real
request rather than by calling the rules directly.
"""
from __future__ import annotations

import importlib
import os
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.core import auth  # noqa: E402
from ims.core import periods as P  # noqa: E402

WEEK = "sat,sun,mon,tue,wed,thu"
PASSWORD = "test-only-not-a-real-password"


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "test.db")
        conn = db.connect(path)
        db.migrate(conn)
        self.loc = db.insert(conn, "locations", name="الجادرية")
        self.gm = db.insert(conn, "users", name="أحمد", role="gm", location_id=self.loc,
                            telegram_id=1, telegram_username="ahmed")
        self.mgr = db.insert(conn, "users", name="حيدر", role="manager", location_id=self.loc,
                             manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(conn, "users", name="علي", role="employee", location_id=self.loc,
                             manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(conn, "users", name="نور", role="employee", location_id=self.loc,
                              manager_id=self.mgr, telegram_id=4)
        auth.set_password(conn, self.gm, PASSWORD)
        routine = db.insert(conn, "routines", code="R1", name="الرد على العملاء",
                            location_id=self.loc, count_label="محادثات")
        self.evening = db.insert(conn, "routine_periods", routine_id=routine, name="مسائية",
                                 days=WEEK, start_time="17:00", end_time="20:00")
        self.tomorrow = texts.now().date() + timedelta(days=1)
        while P.weekday_key(self.tomorrow) == "fri":          # the evening period skips Friday
            self.tomorrow += timedelta(days=1)
        db.insert(conn, "period_schedule", period_id=self.evening,
                  weekday=P.weekday_key(self.tomorrow), user_id=self.ali)
        conn.close()

        os.environ["DB_PATH"] = path
        os.environ["SESSION_SECRET"] = "test-secret"
        from ims.web import app as web_app
        self.web = importlib.reload(web_app)                  # a fresh app on this database
        self.conn = self.web.conn

        from fastapi.testclient import TestClient
        self.client = TestClient(self.web.app)
        response = self.client.post("/login", data={"username": "ahmed", "password": PASSWORD},
                                    follow_redirects=False)
        self.assertEqual(response.status_code, 303)

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    def queued_for(self, user_id):
        return [r["body"] for r in db.all_rows(
            self.conn, "SELECT body FROM outbox WHERE user_id = ? ORDER BY id", (user_id,))]


class TestCoverApproval(Base):
    def open_request(self):
        request_id, _ = P.request_cover(self.conn, self.ali, self.evening, self.tomorrow,
                                        self.noor, "عندي امتحان")
        P.colleague_accepts(self.conn, self.noor, request_id)
        return request_id

    def test_the_page_offers_the_decision(self):
        self.open_request()
        body = self.client.get("/periods").text
        self.assertIn("طلبات التغطية", body)
        self.assertIn("اعتماد", body)

    def test_approving_moves_the_period_and_tells_both(self):
        request_id = self.open_request()
        self.client.post(f"/periods/cover/{request_id}", data={"decision": "approve"})
        self.assertEqual(P.holder(self.conn, self.evening, self.tomorrow)["id"], self.noor)
        self.assertTrue(self.queued_for(self.ali))
        self.assertTrue(self.queued_for(self.noor))

    def test_declining_leaves_it_where_it_was(self):
        request_id = self.open_request()
        self.client.post(f"/periods/cover/{request_id}",
                         data={"decision": "decline", "note": "الفترة مزدحمة"})
        self.assertEqual(P.holder(self.conn, self.evening, self.tomorrow)["id"], self.ali)
        self.assertIn("الفترة مزدحمة", self.queued_for(self.ali)[0])


class TestLeavePage(Base):
    def test_the_form_lists_the_periods_the_leave_touches(self):
        day = self.tomorrow.isoformat()
        body = self.client.get(f"/leaves/{self.ali}?from_date={day}&to_date={day}").text
        self.assertIn("الفترات المتأثرة (1)", body)
        self.assertIn(f"cover[{self.evening}|{day}]", body)

    def test_saving_with_a_cover_moves_that_one_date(self):
        day = self.tomorrow.isoformat()
        self.client.post(f"/leaves/{self.ali}", data={
            "from_date": day, "to_date": day, "kind": "leave",
            f"cover[{self.evening}|{day}]": str(self.noor)})
        self.assertEqual(P.holder(self.conn, self.evening, self.tomorrow)["id"], self.noor)
        self.assertTrue(P.on_leave(self.conn, self.ali, self.tomorrow))
        next_week = self.tomorrow + timedelta(days=7)
        self.assertEqual(P.holder(self.conn, self.evening, next_week)["id"], self.ali)
        self.assertTrue(any("تغطية بدل إجازة" in body for body in self.queued_for(self.noor)))

    def test_saving_without_a_cover_leaves_a_gap_and_warns(self):
        day = self.tomorrow.isoformat()
        self.client.post(f"/leaves/{self.ali}", data={
            "from_date": day, "to_date": day, "kind": "leave",
            f"cover[{self.evening}|{day}]": "0"})
        self.assertIsNone(P.holder(self.conn, self.evening, self.tomorrow))
        self.assertTrue(any("بلا مسؤول" in body for body in self.queued_for(self.mgr)))

    def test_bad_dates_come_back_with_a_message(self):
        response = self.client.post(f"/leaves/{self.ali}",
                                    data={"from_date": "nonsense", "to_date": "nonsense"},
                                    follow_redirects=False)
        self.assertEqual(response.status_code, 303)
        self.assertIn("/leaves/", response.headers["location"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
