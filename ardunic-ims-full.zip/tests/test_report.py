"""The on-demand manager report: every person, their tasks, and what is waiting."""
from __future__ import annotations

import sys
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.bot import handlers  # noqa: E402
from ims.core import schedule  # noqa: E402
from ims.core import tasks as T  # noqa: E402

NOW = datetime(2026, 10, 11, 11, 0, tzinfo=texts.TZ)       # a Sunday, mid-morning


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        self.jadriya = db.insert(self.conn, "locations", name="الجادرية")
        self.sinaa = db.insert(self.conn, "locations", name="الصناعة")
        self.gm = db.insert(self.conn, "users", name="أحمد", role="gm",
                            location_id=self.jadriya, telegram_id=1)
        self.mgr = db.insert(self.conn, "users", name="حيدر", role="manager",
                             location_id=self.jadriya, manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(self.conn, "users", name="علي", role="employee",
                             location_id=self.jadriya, manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(self.conn, "users", name="نور", role="employee",
                              location_id=self.jadriya, manager_id=self.mgr, telegram_id=4)
        self.kareem = db.insert(self.conn, "users", name="كريم", role="employee",
                                location_id=self.sinaa, telegram_id=5)

    def report(self, location_id):
        return schedule.team_report(self.conn, location_id, NOW)


class TestTeamReport(Base):
    def test_each_person_appears_with_their_open_tasks(self):
        task, _ = T.create_task(self.conn, self.mgr, "تصوير المنتجات", self.ali)
        T.accept(self.conn, self.ali, task)
        body = self.report(self.jadriya)
        self.assertIn("علي", body)
        self.assertIn("#%d تصوير المنتجات" % task, body)
        self.assertIn(texts.STATUS[T.IN_PROGRESS], body)
        self.assertIn("نور</b> — لا مهام مفتوحة", body)      # quiet people are shown as quiet

    def test_overdue_and_unaccepted_are_counted_per_person(self):
        T.create_task(self.conn, self.mgr, "جرد الحساسات", self.ali, due_at="2020-01-01 17:00")
        body = self.report(self.jadriya)
        self.assertIn("1 متأخرة", body)
        self.assertIn("1 لم تُقبل", body)
        self.assertIn("⚠️", body)

    def test_the_branch_manager_does_not_see_the_other_branch(self):
        T.create_task(self.conn, self.gm, "مهمة الصناعة", self.kareem)
        self.assertNotIn("كريم", self.report(self.jadriya))
        self.assertIn("كريم", self.report(None))             # the GM sees both
        self.assertIn("الصناعة", self.report(None))

    def test_what_waits_on_the_manager_is_listed(self):
        suggestion, _ = T.suggest_task(self.conn, self.ali, "شراء رف جديد")
        review, _ = T.create_task(self.conn, self.mgr, "تدقيق الأسعار", self.noor, needs_review=True)
        T.accept(self.conn, self.noor, review)
        T.mark_done(self.conn, self.noor, review)
        handover, _ = T.create_task(self.conn, self.mgr, "ترتيب المخزن", self.ali)
        T.accept(self.conn, self.ali, handover)
        T.request_handover(self.conn, self.ali, handover, self.noor, "عندي دوام")

        body = self.report(self.jadriya)
        self.assertIn("اقتراحات بانتظار الموافقة", body)
        self.assertIn(f"#{suggestion}", body)
        self.assertIn("بانتظار المراجعة", body)
        self.assertIn("بانتظار التسليم", body)

    def test_an_unlinked_person_is_flagged(self):
        db.insert(self.conn, "users", name="زينب", role="employee", location_id=self.jadriya)
        self.assertIn("غير مرتبط بالبوت", self.report(self.jadriya))

    def test_a_long_list_is_trimmed_per_person(self):
        for index in range(schedule.MAX_LINES_PER_PERSON + 3):
            T.create_task(self.conn, self.mgr, f"مهمة {index}", self.ali)
        body = self.report(self.jadriya)
        self.assertIn("و3 مهام أخرى", body)

    def test_the_header_counts_the_whole_branch(self):
        T.create_task(self.conn, self.mgr, "واحدة", self.ali)
        T.create_task(self.conn, self.mgr, "اثنتان", self.noor)
        self.assertIn("مهمتان مفتوحتان", self.report(self.jadriya))


class TestChunking(unittest.IsolatedAsyncioTestCase):
    """A report longer than one Telegram message goes out in whole blocks."""

    class FakeMessage:
        def __init__(self):
            self.sent: list[tuple[str, object]] = []

        async def answer(self, text, reply_markup=None):
            self.sent.append((text, reply_markup))

    async def test_blocks_are_never_cut_in_half(self):
        blocks = [f"<b>شخص {i}</b>\n" + "• مهمة طويلة جداً" * 20 for i in range(40)]
        message = self.FakeMessage()
        await handlers.send_long(message, "\n\n".join(blocks), reply_markup="KB")
        self.assertGreater(len(message.sent), 1)
        for text, _ in message.sent:
            self.assertLessEqual(len(text), handlers.TELEGRAM_LIMIT + 200)
        self.assertEqual([m for _, m in message.sent],
                         [None] * (len(message.sent) - 1) + ["KB"])      # buttons once, at the end
        self.assertEqual("\n\n".join(text for text, _ in message.sent), "\n\n".join(blocks))

    async def test_a_short_report_is_one_message(self):
        message = self.FakeMessage()
        await handlers.send_long(message, "سطر واحد", reply_markup="KB")
        self.assertEqual(message.sent, [("سطر واحد", "KB")])


if __name__ == "__main__":
    unittest.main(verbosity=2)
