"""The dashboard's admin pages: removing a person, managing routines, the leaves tab."""
from __future__ import annotations

import importlib
import os
import sys
import tempfile
import unittest
from datetime import date, datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.bot import scheduler  # noqa: E402
from ims.core import auth  # noqa: E402
from ims.core import periods as P  # noqa: E402
from ims.core import tasks as T  # noqa: E402

WEEK = "sat,sun,mon,tue,wed,thu"
PASSWORD = "test-only-not-a-real-password"


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "test.db")
        conn = db.connect(path)
        db.migrate(conn)
        self.loc = db.insert(conn, "locations", name="الجادرية")
        self.gm = db.insert(conn, "users", name="أحمد", role="gm", location_id=self.loc,
                            telegram_id=1, telegram_username="ahmed")
        self.mgr = db.insert(conn, "users", name="حيدر", role="manager", location_id=self.loc,
                             manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(conn, "users", name="علي", role="employee", location_id=self.loc,
                             manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(conn, "users", name="نور", role="employee", location_id=self.loc,
                              manager_id=self.mgr, telegram_id=4)
        auth.set_password(conn, self.gm, PASSWORD)
        conn.close()

        os.environ["DB_PATH"] = path
        os.environ["SESSION_SECRET"] = "test-secret"
        from ims.web import app as web_app
        self.web = importlib.reload(web_app)
        self.conn = self.web.conn
        from fastapi.testclient import TestClient
        self.client = TestClient(self.web.app)
        self.client.post("/login", data={"username": "ahmed", "password": PASSWORD})

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    def person(self, user_id):
        return db.one(self.conn, "SELECT * FROM users WHERE id = ?", (user_id,))


class TestRemovingSomeone(Base):
    def setUp(self) -> None:
        super().setUp()
        self.routine = db.insert(self.conn, "routines", code="R1", name="روتين",
                                 location_id=self.loc, days=WEEK)
        self.period = db.insert(self.conn, "routine_periods", routine_id=self.routine,
                                name="مسائية", days=WEEK, start_time="17:00", end_time="20:00")
        db.insert(self.conn, "period_schedule", period_id=self.period, weekday="sun",
                  user_id=self.ali)
        db.insert(self.conn, "routine_owners", routine_id=self.routine, user_id=self.ali,
                  role="owner")
        self.task, _ = T.create_task(self.conn, self.gm, "مهمة مفتوحة", self.ali)

    def test_the_page_shows_what_he_is_holding(self):
        body = self.client.get(f"/employees/{self.ali}/remove").text
        self.assertIn("مهمة مفتوحة", body)
        self.assertIn("مسائية", body)

    def test_removing_hands_the_work_over_and_keeps_the_history(self):
        self.client.post(f"/employees/{self.ali}/remove",
                         data={"move_to": self.noor, "clear_slots": "1"})
        self.assertEqual(self.person(self.ali)["active"], 0)
        self.assertEqual(T.get_task(self.conn, self.task)["assignee_id"], self.noor)
        self.assertIsNone(db.one(self.conn, "SELECT user_id FROM period_schedule WHERE period_id = ?",
                                 (self.period,))["user_id"])
        self.assertEqual(db.all_rows(self.conn, "SELECT 1 FROM routine_owners WHERE user_id = ?",
                                     (self.ali,)), [])
        # the history is untouched
        self.assertTrue(T.history(self.conn, self.task))

    def test_a_removed_person_is_offered_nowhere_and_hears_nothing(self):
        self.client.post(f"/employees/{self.ali}/remove", data={"move_to": 0})
        self.assertNotIn("علي", [p["name"] for p in self.web.people(self.person(self.gm),
                                                                   ("employee", "manager"))])
        from ims.core import notify
        self.assertFalse(notify.queue_raw(self.conn, self.ali, "مرحباً"))

    def test_he_can_come_back(self):
        self.client.post(f"/employees/{self.ali}/remove", data={"move_to": 0})
        self.client.post(f"/employees/{self.ali}/restore")
        self.assertEqual(self.person(self.ali)["active"], 1)

    def test_you_cannot_remove_yourself(self):
        self.client.post(f"/employees/{self.gm}/remove", data={"move_to": 0})
        self.assertEqual(self.person(self.gm)["active"], 1)


class TestRoutineManagement(Base):
    def create(self, **extra):
        data = {"code": "R9", "name": "مراجعة المرتجعات", "days": ["sat", "sun", "mon"],
                "count_label": "القطع", "checkin": "15:30", "instructions": "افحص كل مرتجع"}
        data.update(extra)
        self.client.post("/routines", data=data)
        return db.one(self.conn, "SELECT * FROM routines WHERE code = 'R9'")

    def test_creating_one(self):
        routine = self.create()
        self.assertEqual(routine["days"], "sat,sun,mon")
        self.assertEqual(P.checkin_time(routine), "15:30")
        self.assertEqual(routine["count_label"], "القطع")

    def test_a_duplicate_code_is_refused(self):
        self.create()
        self.create(name="شيء آخر")
        self.assertEqual(len(db.all_rows(self.conn, "SELECT 1 FROM routines WHERE code = 'R9'")), 1)

    def test_owners_are_replaced_not_appended(self):
        routine = self.create()
        self.client.post(f"/routines/{routine['id']}",
                         data={"action": "owners", "owners": [self.ali], "backups": [self.noor]})
        self.client.post(f"/routines/{routine['id']}",
                         data={"action": "owners", "owners": [self.noor]})
        owners = P.owners_of(self.conn, routine["id"])
        self.assertEqual([(o["name"], o["owner_role"]) for o in owners], [("نور", "owner")])

    def test_editing_and_retiring(self):
        routine = self.create()
        self.client.post(f"/routines/{routine['id']}",
                         data={"action": "edit", "name": "اسم جديد", "days": ["thu"],
                               "count_label": "", "checkin": "17:00"})
        again = db.one(self.conn, "SELECT * FROM routines WHERE id = ?", (routine["id"],))
        self.assertEqual((again["name"], again["days"], again["count_label"]),
                         ("اسم جديد", "thu", None))
        self.client.post(f"/routines/{routine['id']}", data={"action": "retire"})
        self.assertEqual(db.one(self.conn, "SELECT active FROM routines WHERE id = ?",
                                (routine["id"],))["active"], 0)
        self.client.post(f"/routines/{routine['id']}", data={"action": "restore"})
        self.assertEqual(db.one(self.conn, "SELECT active FROM routines WHERE id = ?",
                                (routine["id"],))["active"], 1)

    def test_adding_and_removing_a_period(self):
        routine = self.create()
        self.client.post(f"/routines/{routine['id']}",
                         data={"action": "add_period", "period_name": "مسائية",
                               "period_days": ["sat", "sun"], "start": "17:00", "end": "20:00",
                               "minutes_before": "20"})
        period = db.one(self.conn, "SELECT * FROM routine_periods WHERE routine_id = ?",
                        (routine["id"],))
        self.assertEqual((period["start_time"], period["end_time"], period["days"]),
                         ("17:00", "20:00", "sat,sun"))
        self.assertEqual(period["checkin_minutes_before_end"], 20)
        self.client.post(f"/routines/{routine['id']}",
                         data={"action": "remove_period", "period_id": period["id"]})
        self.assertIsNone(db.one(self.conn, "SELECT 1 FROM routine_periods WHERE id = ?",
                                 (period["id"],)))

    def test_a_period_with_history_is_kept(self):
        routine = self.create()
        period = P.add_period(self.conn, routine["id"], name="مسائية", days=["sat"],
                              start="17:00", end="20:00")
        P.log_period(self.conn, self.ali, period, date(2026, 10, 10), "done")
        with self.assertRaises(P.RuleError):
            P.remove_period(self.conn, period)

    def test_backwards_times_are_refused(self):
        routine = self.create()
        with self.assertRaises(P.RuleError):
            P.add_period(self.conn, routine["id"], name="خطأ", days=["sat"],
                         start="20:00", end="17:00")


class TestDailyRoutineCheckin(Base):
    """A routine with no periods — R2 to R7 — is asked once a day."""

    def setUp(self) -> None:
        super().setUp()
        self.day = date(2026, 10, 11)                      # a Sunday
        self.routine = db.insert(self.conn, "routines", code="R2", name="تجهيز الطلبات",
                                 location_id=self.loc, days=WEEK, count_label="الطلبات",
                                 checkin_time="16:30")
        db.insert(self.conn, "routine_owners", routine_id=self.routine, user_id=self.ali,
                  role="owner")
        db.insert(self.conn, "routine_owners", routine_id=self.routine, user_id=self.noor,
                  role="backup")

    def at(self, hour, minute=0):
        return datetime(self.day.year, self.day.month, self.day.day, hour, minute, tzinfo=texts.TZ)

    def bodies(self, user_id):
        return [r["body"] for r in db.all_rows(
            self.conn, "SELECT body FROM outbox WHERE user_id = ? ORDER BY id", (user_id,))]

    def test_the_owner_is_asked_at_its_own_time_and_only_once(self):
        self.assertEqual(scheduler._dispatch_periods(self.conn, self.at(16, 0)), 0)
        self.assertEqual(scheduler._dispatch_periods(self.conn, self.at(16, 30)), 1)
        self.assertEqual(scheduler._dispatch_periods(self.conn, self.at(16, 31)), 0)
        self.assertIn("R2", self.bodies(self.ali)[0])
        self.assertEqual(self.bodies(self.noor), [])        # the backup is not asked

    def test_a_routine_that_does_not_run_today_is_quiet(self):
        db.update(self.conn, "routines", self.routine, days="fri")
        self.assertEqual(scheduler._dispatch_periods(self.conn, self.at(23, 0)), 0)

    def test_someone_on_leave_is_not_asked(self):
        P.set_day_off(self.conn, self.gm, self.ali, self.day, True)
        scheduler._dispatch_periods(self.conn, self.at(16, 30))
        self.assertEqual(self.bodies(self.ali), [])

    def test_a_routine_with_periods_is_asked_per_period_instead(self):
        P.add_period(self.conn, self.routine, name="مسائية", days=WEEK, start="17:00", end="20:00")
        db.insert(self.conn, "period_schedule",
                  period_id=db.one(self.conn, "SELECT id FROM routine_periods")["id"],
                  weekday="sun", user_id=self.ali)
        scheduler._dispatch_periods(self.conn, self.at(16, 30))
        self.assertEqual(self.bodies(self.ali), [])         # no daily question
        scheduler._dispatch_periods(self.conn, self.at(19, 45))
        self.assertIn("نهاية فترة", self.bodies(self.ali)[0])

    def test_the_answer_is_logged_against_the_routine(self):
        P.log_routine(self.conn, self.ali, self.routine, self.day, "done", count=12)
        row = P.logs_for(self.conn, self.day, self.loc)[0]
        self.assertEqual((row["result"], row["count"], row["period_name"]), ("done", 12, None))


class TestWeeklyRota(Base):
    """تجهيز الطلبات and فحص الطلبات move around the team, one or two people a day."""

    def setUp(self) -> None:
        super().setUp()
        self.zain = db.insert(self.conn, "users", name="زينب", role="employee",
                              location_id=self.loc, manager_id=self.mgr, telegram_id=5)
        self.routine = db.insert(self.conn, "routines", code="R2", name="تجهيز الطلبات",
                                 location_id=self.loc, days=WEEK, checkin_time="16:30")
        self.sunday = date(2026, 10, 11)
        self.monday = self.sunday + timedelta(days=1)

    def row(self):
        return db.one(self.conn, "SELECT * FROM routines WHERE id = ?", (self.routine,))

    def names_on(self, day):
        return [p["name"] for p in P.on_duty(self.conn, self.row(), day)]

    def test_a_different_person_each_day_and_two_on_one_day(self):
        self.client.post(f"/routines/{self.routine}", data={
            "action": "rota",
            "rota[sun]": [str(self.ali), "0"],
            "rota[mon]": [str(self.noor), str(self.zain)]})
        self.assertEqual(self.names_on(self.sunday), ["علي"])
        self.assertEqual(sorted(self.names_on(self.monday)), sorted(["نور", "زينب"]))

    def test_a_day_nobody_is_on_asks_nobody(self):
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.ali]})
        self.assertEqual(self.names_on(self.monday), [])

    def test_with_no_rota_it_falls_back_to_the_fixed_owners(self):
        db.insert(self.conn, "routine_owners", routine_id=self.routine, user_id=self.noor,
                  role="owner")
        self.assertEqual(self.names_on(self.sunday), ["نور"])
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.ali]})
        self.assertEqual(self.names_on(self.sunday), ["علي"])      # the rota wins

    def test_saving_the_rota_replaces_it(self):
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.ali, self.noor]})
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.zain]})
        self.assertEqual(self.names_on(self.sunday), ["زينب"])

    def test_both_people_on_duty_are_asked_and_each_answers(self):
        P.set_routine_rota(self.conn, self.routine, {"mon": [self.noor, self.zain]})
        moment = datetime(self.monday.year, self.monday.month, self.monday.day, 16, 30,
                          tzinfo=texts.TZ)
        self.assertEqual(scheduler._dispatch_periods(self.conn, moment), 2)
        P.log_routine(self.conn, self.noor, self.routine, self.monday, "done", count=9)
        P.log_routine(self.conn, self.zain, self.routine, self.monday, "partly", note="نقص تغليف")
        rows = P.logs_for(self.conn, self.monday, self.loc)
        self.assertEqual({(r["who"], r["result"]) for r in rows},
                         {("نور", "done"), ("زينب", "partly")})

    def test_the_morning_brief_tells_whoever_is_on_today(self):
        from ims.core import schedule as S
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.ali], "mon": [self.noor]})
        morning = datetime(self.sunday.year, self.sunday.month, self.sunday.day, 9, 0,
                           tzinfo=texts.TZ)
        ali = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.ali,))
        noor = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.noor,))
        self.assertIn("R2 تجهيز الطلبات", S.brief_for(self.conn, ali, morning))
        self.assertIsNone(S.brief_for(self.conn, noor, morning))      # not her day

    def test_a_rostered_person_sees_it_in_their_own_routines(self):
        P.set_routine_rota(self.conn, self.routine, {"sun": [self.zain]})
        codes = [r["code"] for r in P.routines_of(self.conn, self.zain)]
        self.assertEqual(codes, ["R2"])

    def test_someone_off_that_day_is_skipped(self):
        P.set_routine_rota(self.conn, self.routine, {"mon": [self.noor, self.zain]})
        P.set_fixed_day_off(self.conn, self.zain, "mon")
        moment = datetime(self.monday.year, self.monday.month, self.monday.day, 16, 30,
                          tzinfo=texts.TZ)
        self.assertEqual(scheduler._dispatch_periods(self.conn, moment), 1)


class TestFixedDayOff(Base):
    def setUp(self) -> None:
        super().setUp()
        self.sunday = date(2026, 10, 11)
        self.monday = self.sunday + timedelta(days=1)

    def test_it_repeats_every_week_without_ticking_anything(self):
        P.set_fixed_day_off(self.conn, self.ali, "mon")
        self.assertTrue(P.is_off(self.conn, self.ali, self.monday))
        self.assertTrue(P.is_off(self.conn, self.ali, self.monday + timedelta(days=7)))
        self.assertFalse(P.is_off(self.conn, self.ali, self.sunday))

    def test_the_grid_shows_it_as_fixed_and_will_not_clear_it(self):
        P.set_fixed_day_off(self.conn, self.ali, "mon")
        marks = P.week_marks(self.conn, [self.sunday, self.monday], self.loc)
        self.assertEqual(marks[(self.ali, self.monday.isoformat())]["kind"], "fixed")
        saturday = self.sunday - timedelta(days=1)
        self.client.post("/leaves/grid", data={"week": saturday.isoformat(),
                                               "person": [self.ali], "off": []})
        self.assertTrue(P.is_off(self.conn, self.ali, self.monday))

    def test_the_bot_says_nothing_to_someone_on_their_day_off(self):
        from ims.core import schedule as S
        P.set_fixed_day_off(self.conn, self.ali, "mon")
        self.assertTrue(S.on_leave(self.conn, self.ali, self.monday))
        self.assertFalse(S.on_leave(self.conn, self.ali, self.sunday))

    def test_the_gm_sets_it_and_can_clear_it(self):
        self.client.post("/leaves/dayoff", data={"user_id": self.ali, "weekday": "tue"})
        self.assertEqual(db.one(self.conn, "SELECT weekly_day_off FROM users WHERE id = ?",
                                (self.ali,))["weekly_day_off"], "tue")
        self.client.post("/leaves/dayoff", data={"user_id": self.ali, "weekday": ""})
        self.assertIsNone(db.one(self.conn, "SELECT weekly_day_off FROM users WHERE id = ?",
                                 (self.ali,))["weekly_day_off"])

    def test_a_nonsense_day_is_refused(self):
        with self.assertRaises(P.RuleError):
            P.set_fixed_day_off(self.conn, self.ali, "funday")


class TestLeavesTab(Base):
    def setUp(self) -> None:
        super().setUp()
        self.today = texts.now().date()
        self.saturday = self.today - timedelta(days=(self.today.weekday() + 2) % 7)

    def test_the_grid_saves_ticks_and_clears_them(self):
        day = (self.saturday + timedelta(days=2)).isoformat()
        self.client.post("/leaves/grid", data={
            "week": self.saturday.isoformat(), "person": [self.ali, self.noor],
            "off": [f"{self.ali}|{day}"]})
        self.assertTrue(P.on_leave(self.conn, self.ali, date.fromisoformat(day)))
        self.assertFalse(P.on_leave(self.conn, self.noor, date.fromisoformat(day)))

        self.client.post("/leaves/grid", data={
            "week": self.saturday.isoformat(), "person": [self.ali, self.noor], "off": []})
        self.assertFalse(P.on_leave(self.conn, self.ali, date.fromisoformat(day)))

    def test_a_recorded_leave_shows_in_the_grid_and_is_not_a_tick(self):
        day = self.saturday + timedelta(days=1)
        P.record_leave(self.conn, self.gm, self.ali, day, day)
        marks = P.week_marks(self.conn, [day])
        self.assertEqual(marks[(self.ali, day.isoformat())]["kind"], "leave")
        # the grid must not wipe it when the week is saved with that box unticked
        self.client.post("/leaves/grid", data={"week": self.saturday.isoformat(),
                                               "person": [self.ali], "off": []})
        self.assertTrue(P.on_leave(self.conn, self.ali, day))

    def test_a_two_hour_leave_keeps_the_person_at_work(self):
        day = self.saturday + timedelta(days=1)
        self.client.post("/leaves/add", data={
            "user_id": self.ali, "from_date": day.isoformat(), "to_date": day.isoformat(),
            "from_time": "10:00", "to_time": "12:00", "kind": "leave"})
        leave = db.one(self.conn, "SELECT * FROM leaves WHERE user_id = ?", (self.ali,))
        self.assertEqual((leave["from_time"], leave["to_time"]), ("10:00", "12:00"))
        self.assertIsNone(P.on_leave(self.conn, self.ali, day))        # still at work
        self.assertEqual(P.week_marks(self.conn, [day])[(self.ali, day.isoformat())]["kind"],
                         "hours")

    def test_a_two_hour_leave_must_be_one_day(self):
        with self.assertRaises(P.RuleError):
            P.record_leave(self.conn, self.gm, self.ali, self.saturday,
                           self.saturday + timedelta(days=1), hours=("10:00", "12:00"))

    def test_removing_a_leave_puts_the_period_back(self):
        routine = db.insert(self.conn, "routines", code="R1", name="روتين",
                            location_id=self.loc, days=WEEK)
        period = db.insert(self.conn, "routine_periods", routine_id=routine, name="مسائية",
                           days=WEEK, start_time="17:00", end_time="20:00")
        day = self.saturday + timedelta(days=1)            # Sunday
        db.insert(self.conn, "period_schedule", period_id=period,
                  weekday=P.weekday_key(day), user_id=self.ali)
        leave_id, _ = P.record_leave(self.conn, self.gm, self.ali, day, day,
                                     cover={(period, day.isoformat()): self.noor})
        self.assertEqual(P.holder(self.conn, period, day)["id"], self.noor)
        P.remove_leave(self.conn, leave_id)
        self.assertEqual(P.holder(self.conn, period, day)["id"], self.ali)
        self.assertIsNone(P.on_leave(self.conn, self.ali, day))

    def test_the_page_renders_for_any_week(self):
        for week in ("", self.saturday.isoformat(), (self.saturday + timedelta(days=7)).isoformat()):
            self.assertEqual(self.client.get(f"/leaves?week={week}").status_code, 200)


if __name__ == "__main__":
    unittest.main(verbosity=2)
