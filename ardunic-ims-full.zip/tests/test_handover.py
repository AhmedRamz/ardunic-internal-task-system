"""Handover end to end: pick a colleague, the manager approves, the colleague accepts.

The task only changes hands on the second yes — that is the whole point of the
بانتظار التسليم column, so it is tested as one chain, buttons included.
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.bot import keyboards as kb  # noqa: E402
from ims.core import notify  # noqa: E402
from ims.core import tasks as T  # noqa: E402


def labels(markup) -> list[str]:
    if markup is None:
        return []
    return [button.text for row in markup.inline_keyboard for button in row]


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        self.loc = db.insert(self.conn, "locations", name="Jadriya")
        self.gm = db.insert(self.conn, "users", name="Ahmed", role="gm",
                            location_id=self.loc, telegram_id=1)
        self.mgr = db.insert(self.conn, "users", name="Haider", role="manager",
                             location_id=self.loc, manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(self.conn, "users", name="Ali", role="employee",
                             location_id=self.loc, manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(self.conn, "users", name="Noor", role="employee",
                              location_id=self.loc, manager_id=self.mgr, telegram_id=4)
        self.task, _ = T.create_task(self.conn, self.mgr, "تصوير المنتجات الجديدة", self.ali)
        T.accept(self.conn, self.ali, self.task)

    def row(self, user_id):
        return db.one(self.conn, "SELECT * FROM users WHERE id = ?", (user_id,))

    def task_row(self):
        return T.get_task(self.conn, self.task)

    def pending(self):
        return db.one(self.conn, "SELECT * FROM handovers WHERE task_id = ? ORDER BY id DESC",
                      (self.task,))


class TestTheChain(Base):
    def test_the_button_appears_only_after_the_task_is_accepted(self):
        fresh, _ = T.create_task(self.conn, self.mgr, "ترتيب الرف", self.noor)
        self.assertNotIn("🔄 طلب تسليم", labels(kb.task_actions(T.get_task(self.conn, fresh),
                                                               self.row(self.noor))))
        T.accept(self.conn, self.noor, fresh)
        self.assertIn("🔄 طلب تسليم", labels(kb.task_actions(T.get_task(self.conn, fresh),
                                                            self.row(self.noor))))

    def test_both_yeses_are_needed_and_then_it_moves(self):
        _, event = T.request_handover(self.conn, self.ali, self.task, self.noor, "عندي دوام جامعة")
        self.assertEqual(self.task_row()["status"], T.HANDOVER)
        self.assertEqual(self.task_row()["assignee_id"], self.ali)       # still Ali's
        self.assertIn(self.mgr, event.recipients)                        # the manager is asked first
        self.assertIn(self.gm, event.recipients)

        # the colleague cannot take it before the manager has approved
        with self.assertRaises(T.RuleError):
            T.accept_handover(self.conn, self.noor, self.task)

        T.approve_handover(self.conn, self.mgr, self.task)
        self.assertEqual(self.pending()["status"], "awaiting_employee")
        self.assertEqual(self.task_row()["assignee_id"], self.ali)       # still not moved

        T.accept_handover(self.conn, self.noor, self.task)
        moved = self.task_row()
        self.assertEqual((moved["status"], moved["assignee_id"]), (T.IN_PROGRESS, self.noor))

    def test_the_right_buttons_at_each_step(self):
        T.request_handover(self.conn, self.ali, self.task, self.noor, "عندي دوام جامعة")
        task, handover = self.task_row(), self.pending()
        self.assertIn("✅ موافقة على التسليم", labels(kb.task_actions(task, self.row(self.mgr), handover)))
        self.assertEqual(labels(kb.task_actions(task, self.row(self.noor), handover)),
                         ["💬 تعليق"])                                    # nothing to do yet

        T.approve_handover(self.conn, self.mgr, self.task)
        handover = self.pending()
        self.assertIn("📥 قبول الاستلام", labels(kb.task_actions(task, self.row(self.noor), handover)))
        self.assertIn("📤 رفض الاستلام", labels(kb.task_actions(task, self.row(self.noor), handover)))

    def test_the_colleague_can_say_no_and_it_goes_back(self):
        T.request_handover(self.conn, self.ali, self.task, self.noor, "عندي دوام جامعة")
        T.approve_handover(self.conn, self.mgr, self.task)
        event = T.reject_handover(self.conn, self.noor, self.task, "عندي فترة السوشيال ميديا")
        back = self.task_row()
        self.assertEqual((back["status"], back["assignee_id"]), (T.IN_PROGRESS, self.ali))
        self.assertIn(self.ali, event.recipients)
        self.assertIn(self.mgr, event.recipients)

    def test_the_manager_can_refuse_the_request(self):
        T.request_handover(self.conn, self.ali, self.task, self.noor, "عندي دوام جامعة")
        T.decline_handover(self.conn, self.mgr, self.task, "اليوم مزدحم")
        back = self.task_row()
        self.assertEqual((back["status"], back["assignee_id"]), (T.IN_PROGRESS, self.ali))

    def test_every_step_reaches_telegram(self):
        _, event = T.request_handover(self.conn, self.ali, self.task, self.noor, "عندي دوام جامعة")
        self.assertEqual(notify.queue(self.conn, event), 2)               # manager + GM
        queued = notify.queue(self.conn, T.approve_handover(self.conn, self.mgr, self.task))
        self.assertEqual(queued, 2)                                       # Noor and Ali
        self.assertEqual(notify.queue(self.conn, T.accept_handover(self.conn, self.noor, self.task)), 3)

    def test_you_cannot_hand_a_task_to_yourself(self):
        with self.assertRaises(T.RuleError):
            T.request_handover(self.conn, self.ali, self.task, self.ali, "لا سبب")

    def test_a_reason_is_required(self):
        with self.assertRaises(T.RuleError):
            T.request_handover(self.conn, self.ali, self.task, self.noor, "   ")


if __name__ == "__main__":
    unittest.main(verbosity=2)
