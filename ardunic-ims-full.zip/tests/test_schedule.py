"""The daily rhythm, replayed against a fake clock — no waiting, no Telegram."""
from __future__ import annotations

import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.bot import scheduler  # noqa: E402
from ims.core import schedule  # noqa: E402
from ims.core import tasks as T  # noqa: E402

SUNDAY = datetime(2026, 10, 11, 9, 0)      # a working day
FRIDAY = datetime(2026, 10, 9, 9, 0)       # the day off

SLOTS = [("brief", "09:00"), ("update", "10:00"), ("update", "12:00"),
         ("update", "14:00"), ("closeout", "16:30"), ("report", "17:00")]


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        self.loc = db.insert(self.conn, "locations", name="Jadriya")
        self.gm = db.insert(self.conn, "users", name="Ahmed", role="gm", location_id=self.loc,
                            telegram_id=1)
        self.mgr = db.insert(self.conn, "users", name="Haider", role="manager", location_id=self.loc,
                             manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(self.conn, "users", name="Ali", role="employee", location_id=self.loc,
                             manager_id=self.mgr, telegram_id=3)
        self.zainab = db.insert(self.conn, "users", name="Zainab", role="employee",
                                location_id=self.loc, manager_id=self.mgr, telegram_id=4)
        db.insert(self.conn, "settings", key="workdays", value="sat,sun,mon,tue,wed,thu")
        for kind, time in SLOTS:
            db.insert(self.conn, "checkin_slots", location_id=self.loc, kind=kind, time=time)

    def task_at(self, who: int, title: str = "Sort the shipment", *, day=SUNDAY, **kw) -> int:
        """A task that already existed that morning, so the reminder logic stays
        out of tests that are about the daily slots."""
        task_id, _ = T.create_task(self.conn, self.gm, title, who, **kw)
        self.conn.execute("UPDATE tasks SET created_at = ? WHERE id = ?",
                          (day.replace(hour=8, minute=0).strftime("%Y-%m-%d %H:%M:%S"), task_id))
        return task_id

    def outbox(self, action: str | None = None) -> list[db.sqlite3.Row]:
        sql = "SELECT * FROM outbox" + (" WHERE action = ?" if action else "") + " ORDER BY id"
        return db.all_rows(self.conn, sql, (action,) if action else ())


class TestCalendar(Base):
    def test_friday_is_quiet(self):
        self.assertEqual(schedule.due_slots(self.conn, FRIDAY), [])
        self.assertEqual(scheduler.tick(self.conn, FRIDAY), 0)

    def test_only_slots_whose_time_has_passed(self):
        at_ten = SUNDAY.replace(hour=10, minute=5)
        kinds = [s["kind"] for s in schedule.due_slots(self.conn, at_ten)]
        self.assertEqual(kinds, ["brief", "update"])

    def test_a_slot_fires_once_a_day(self):
        self.task_at(self.ali, "Count sensors")
        first = scheduler.tick(self.conn, SUNDAY)
        second = scheduler.tick(self.conn, SUNDAY.replace(minute=30))
        self.assertGreater(first, 0)
        self.assertEqual(second, 0)              # nothing re-sent

    def test_a_missed_brief_still_fires_later_the_same_day(self):
        self.task_at(self.ali, "Count sensors")
        # the server was down all morning; the first tick is at 11:00
        scheduler.tick(self.conn, SUNDAY.replace(hour=11))
        actions = {row["action"] for row in self.outbox()}
        self.assertIn("brief", actions)          # worth having late
        self.assertIn("update_item", actions)    # the 10:00 update is still inside its grace

    def test_a_badly_late_update_is_skipped_not_sent(self):
        task = self.task_at(self.ali, "Count sensors")
        T.accept(self.conn, self.ali, task)
        scheduler.tick(self.conn, SUNDAY.replace(hour=12, minute=1))
        # the 10:00 update is two hours late: skipped, only the 12:00 one is sent
        self.assertEqual(len(self.outbox("update_item")), 1)
        skipped = db.one(self.conn, """SELECT r.sent FROM slot_runs r JOIN checkin_slots s
                                        ON s.id = r.slot_id WHERE s.time = '10:00'""")
        self.assertEqual(skipped["sent"], 0)


class TestBrief(Base):
    def test_brief_lists_tasks_overdue_and_waiting(self):
        today = self.task_at(self.ali, "Count sensors", due_at="2026-10-11 17:00")
        T.accept(self.conn, self.ali, today)                     # in progress, due today
        T.create_task(self.conn, self.gm, "Price tags", self.ali, due_at="2026-10-12 17:00")
        late, _ = T.create_task(self.conn, self.gm, "Old price tags", self.ali,
                                due_at="2026-10-10 17:00")       # overdue
        T.accept(self.conn, self.ali, late)
        body = schedule.brief_for(self.conn, db.one(self.conn, "SELECT * FROM users WHERE id = ?",
                                                    (self.ali,)), SUNDAY)
        self.assertIn("مهامك اليوم", body)
        self.assertIn("متأخرة", body)
        self.assertIn("بانتظار قبولك", body)

    def test_no_tasks_means_no_message(self):
        user = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.zainab,))
        self.assertIsNone(schedule.brief_for(self.conn, user, SUNDAY))

    def test_people_on_leave_are_skipped(self):
        self.task_at(self.ali, "Count sensors")
        db.insert(self.conn, "leaves", user_id=self.ali, from_date="2026-10-11",
                  to_date="2026-10-12", kind="leave", created_by=self.mgr)
        scheduler.tick(self.conn, SUNDAY)
        recipients = {row["user_id"] for row in self.outbox("brief")}
        self.assertNotIn(self.ali, recipients)

    def test_managers_get_an_overview(self):
        self.task_at(self.ali, "Count sensors")
        scheduler.tick(self.conn, SUNDAY)
        overview = [r for r in self.outbox("overview")]
        self.assertEqual({r["user_id"] for r in overview}, {self.gm, self.mgr})
        self.assertIn("لم تُقبل بعد", overview[0]["body"])


class TestUpdatesAndCloseout(Base):
    def setUp(self):
        super().setUp()
        self.task = self.task_at(self.ali)
        T.accept(self.conn, self.ali, self.task)

    def test_update_sends_one_message_per_open_task_with_buttons(self):
        scheduler.tick(self.conn, SUNDAY.replace(hour=12, minute=1))
        items = self.outbox("update_item")
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]["keyboard"], "update")
        self.assertEqual(items[0]["task_id"], self.task)

    def test_closeout_uses_its_own_buttons(self):
        scheduler.tick(self.conn, SUNDAY.replace(hour=16, minute=31))
        items = self.outbox("closeout_item")
        self.assertEqual(items[0]["keyboard"], "closeout")

    def test_employee_with_nothing_open_is_not_pestered(self):
        scheduler.tick(self.conn, SUNDAY.replace(hour=12, minute=1))
        self.assertNotIn(self.zainab, {r["user_id"] for r in self.outbox()})

    def test_answers_are_recorded_for_the_today_page(self):
        schedule.record_checkin(self.conn, self.ali, self.task, "update", "working", "half done",
                                now=SUNDAY)
        row = db.one(self.conn, "SELECT * FROM checkins")
        self.assertEqual((row["answer"], row["note"], row["date"]), ("working", "half done", "2026-10-11"))


class TestReport(Base):
    def test_report_covers_done_carried_rejected_and_silence(self):
        done, _ = T.create_task(self.conn, self.gm, "Clean the area", self.ali)
        T.accept(self.conn, self.ali, done)
        T.mark_done(self.conn, self.ali, done)

        carried, _ = T.create_task(self.conn, self.gm, "Shelf inventory", self.ali)
        T.accept(self.conn, self.ali, carried)
        T.carry_over(self.conn, self.ali, carried, "3 of 5 shelves done")

        rejected, _ = T.create_task(self.conn, self.gm, "Print labels", self.zainab)
        T.reject(self.conn, self.zainab, rejected, "busy with the wholesale order")

        body = schedule.day_report(self.conn, self.loc, texts.now().replace(hour=17, minute=0))
        self.assertIn("أُنجزت اليوم (1)", body)
        self.assertIn("3 of 5 shelves done", body)
        self.assertIn("مرفوضة (1)", body)
        self.assertIn("لم يرد على الإغلاق", body)          # Ali never answered the close-out

    def test_report_goes_to_both_managers(self):
        self.task_at(self.ali, "Count sensors")
        scheduler.tick(self.conn, SUNDAY.replace(hour=17, minute=1))
        self.assertEqual({r["user_id"] for r in self.outbox("report")}, {self.gm, self.mgr})


class TestReminders(Base):
    def _age_task(self, task_id: int, hours: int) -> None:
        """Pretend the task was created N hours ago on the same clock the system uses."""
        when = (texts.now() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute("UPDATE tasks SET created_at = ? WHERE id = ?", (when, task_id))

    def test_two_hours_nudges_the_employee_four_escalates(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        self._age_task(task, 3)
        scheduler._dispatch_reminders(self.conn, texts.now(), 2, 4)
        self.assertEqual({r["user_id"] for r in self.outbox("accept_reminder")}, {self.ali})

        self._age_task(task, 5)
        scheduler._dispatch_reminders(self.conn, texts.now(), 2, 4)
        self.assertEqual({r["user_id"] for r in self.outbox("accept_escalated")}, {self.gm, self.mgr})

    def test_each_reminder_is_sent_once(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        self._age_task(task, 3)
        scheduler._dispatch_reminders(self.conn, texts.now(), 2, 4)
        scheduler._dispatch_reminders(self.conn, texts.now(), 2, 4)
        self.assertEqual(len(self.outbox("accept_reminder")), 1)

    def test_accepted_tasks_are_not_chased(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        self._age_task(task, 6)
        T.accept(self.conn, self.ali, task)
        self.assertEqual(scheduler._dispatch_reminders(self.conn, texts.now(), 2, 4), 0)

    def test_overdue_is_flagged_once_to_employee_and_managers(self):
        task, _ = T.create_task(self.conn, self.gm, "Wholesale order", self.ali,
                                due_at="2026-10-11 14:00")
        T.accept(self.conn, self.ali, task)
        late = SUNDAY.replace(hour=15)
        scheduler._dispatch_reminders(self.conn, late, 2, 4)
        self.assertEqual({r["user_id"] for r in self.outbox("overdue")}, {self.ali, self.gm, self.mgr})
        scheduler._dispatch_reminders(self.conn, late, 2, 4)
        self.assertEqual(len(self.outbox("overdue")), 3)       # still three, not six


class TestFullDay(Base):
    def test_a_whole_day_in_order(self):
        task = self.task_at(self.ali)
        T.accept(self.conn, self.ali, task)
        for hour, minute in [(9, 0), (10, 0), (12, 0), (14, 0), (16, 30), (17, 0)]:
            scheduler.tick(self.conn, SUNDAY.replace(hour=hour, minute=minute))
        actions = [row["action"] for row in self.outbox()]
        for expected in ("brief", "overview", "update", "update_item", "closeout",
                         "closeout_item", "report"):
            self.assertIn(expected, actions)
        self.assertEqual(actions.count("report"), 2)           # the GM and the manager
        # the same day replayed changes nothing
        before = len(actions)
        scheduler.tick(self.conn, SUNDAY.replace(hour=18))
        self.assertEqual(len(self.outbox()), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestNoise(Base):
    """Switching the system on must not fire a message for every old task."""

    def test_a_task_appears_once_in_the_brief(self):
        task = self.task_at(self.ali, "Old price tags", due_at="2026-10-10 17:00")   # overdue
        body = schedule.brief_for(self.conn, db.one(self.conn, "SELECT * FROM users WHERE id = ?",
                                                    (self.ali,)), SUNDAY)
        self.assertEqual(body.count(f"#{task}"), 1)      # overdue only, not also "waiting"
        self.assertNotIn("مهامك اليوم (0)", body)

    def test_old_unaccepted_tasks_are_left_to_the_overview(self):
        task, _ = T.create_task(self.conn, self.gm, "From last week", self.ali)
        when = (texts.now() - timedelta(hours=72)).strftime("%Y-%m-%d %H:%M:%S")
        self.conn.execute("UPDATE tasks SET created_at = ? WHERE id = ?", (when, task))
        self.assertEqual(scheduler._dispatch_reminders(self.conn, texts.now(), 2, 4), 0)

    def test_long_overdue_tasks_are_not_announced(self):
        task, _ = T.create_task(self.conn, self.gm, "Ancient task", self.ali,
                                due_at=(texts.now() - timedelta(days=5)).strftime("%Y-%m-%d %H:%M"))
        T.accept(self.conn, self.ali, task)
        self.assertEqual(schedule.overdue_alerts(self.conn, texts.now()), [])

    def test_a_task_that_just_went_overdue_is_announced(self):
        task, _ = T.create_task(self.conn, self.gm, "Wholesale order", self.ali,
                                due_at=(texts.now() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M"))
        T.accept(self.conn, self.ali, task)
        self.assertEqual([r["id"] for r in schedule.overdue_alerts(self.conn, texts.now())], [task])
