"""Unread badges, the notifications feed, and the employee page data."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import feed  # noqa: E402
from ims.core import tasks as T  # noqa: E402


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        self.jadriya = db.insert(self.conn, "locations", name="Jadriya")
        self.sinaa = db.insert(self.conn, "locations", name="Sinaa")
        self.gm = db.insert(self.conn, "users", name="Ahmed", role="gm", location_id=self.jadriya)
        self.mgr = db.insert(self.conn, "users", name="Haider", role="manager",
                             location_id=self.jadriya, manager_id=self.gm)
        self.ali = db.insert(self.conn, "users", name="Ali", role="employee",
                             location_id=self.jadriya, manager_id=self.mgr)
        self.other = db.insert(self.conn, "users", name="Kareem", role="employee",
                               location_id=self.sinaa)
        self.manager_row = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.mgr,))
        self.gm_row = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.gm,))


class TestUnread(Base):
    def test_a_comment_by_the_employee_shows_on_the_card(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        T.accept(self.conn, self.ali, task)
        T.add_comment(self.conn, self.ali, task, "started with drawer C-4")
        unread = feed.unread_by_task(self.conn, self.mgr)
        self.assertEqual(unread[task]["comments"], 1)
        self.assertGreaterEqual(unread[task]["other"], 1)          # created + accepted

    def test_opening_the_task_clears_it(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        T.add_comment(self.conn, self.ali, task, "on it")
        feed.mark_read(self.conn, self.mgr, task)
        self.assertNotIn(task, feed.unread_by_task(self.conn, self.mgr))

    def test_a_later_comment_shows_again(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        feed.mark_read(self.conn, self.mgr, task)
        T.add_comment(self.conn, self.ali, task, "one more thing")
        self.assertEqual(feed.unread_by_task(self.conn, self.mgr)[task]["comments"], 1)

    def test_your_own_actions_are_never_unread_to_you(self):
        task, _ = T.create_task(self.conn, self.mgr, "Sort the shipment", self.ali)
        T.add_comment(self.conn, self.mgr, task, "please finish today")
        self.assertNotIn(task, feed.unread_by_task(self.conn, self.mgr))

    def test_total_respects_the_branch(self):
        T.create_task(self.conn, self.gm, "Jadriya task", self.ali)
        T.create_task(self.conn, self.gm, "Sinaa task", self.other)
        self.assertEqual(feed.unread_total(self.conn, self.manager_row), 1)   # own branch only
        self.assertEqual(feed.unread_total(self.conn, self.gm_row), 0)        # the GM did both

    def test_mark_all_read_empties_the_badge(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        T.add_comment(self.conn, self.ali, task, "done soon")
        self.assertEqual(feed.unread_total(self.conn, self.manager_row), 2)
        feed.mark_all_read(self.conn, self.manager_row)
        self.assertEqual(feed.unread_total(self.conn, self.manager_row), 0)


class TestFeed(Base):
    def test_newest_first_and_scoped(self):
        first, _ = T.create_task(self.conn, self.gm, "Jadriya task", self.ali)
        T.create_task(self.conn, self.gm, "Sinaa task", self.other)
        T.add_comment(self.conn, self.ali, first, "latest thing")
        rows = feed.feed(self.conn, self.manager_row)
        self.assertEqual(rows[0]["action"], "comment")                 # newest first
        self.assertTrue(all(r["task_id"] == first for r in rows))      # the other branch is hidden

    def test_the_gm_sees_both_branches(self):
        T.create_task(self.conn, self.gm, "Jadriya task", self.ali)
        T.create_task(self.conn, self.gm, "Sinaa task", self.other)
        self.assertEqual(len({r["task_id"] for r in feed.feed(self.conn, self.gm_row)}), 2)

    def test_filters(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        T.add_comment(self.conn, self.ali, task, "a note")
        T.reject(self.conn, self.ali, task, "busy today")
        comments = feed.feed(self.conn, self.manager_row, kind="comments")
        attention = feed.feed(self.conn, self.manager_row, kind="attention")
        self.assertEqual({r["action"] for r in comments}, {"comment"})
        self.assertEqual({r["action"] for r in attention}, {"rejected"})

    def test_rows_carry_what_the_page_shows(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        row = feed.feed(self.conn, self.manager_row)[0]
        self.assertEqual(row["title"], "Count sensors")
        self.assertEqual(row["actor_name"], "Ahmed")
        self.assertEqual(row["assignee_name"], "Ali")
        self.assertEqual(row["is_new"], 1)


class TestEmployeePage(Base):
    def test_summary_counts_and_lists(self):
        open_task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali,
                                     due_at="2020-01-01 17:00")          # long overdue
        T.accept(self.conn, self.ali, open_task)
        waiting, _ = T.create_task(self.conn, self.gm, "Price tags", self.ali)
        closed, _ = T.create_task(self.conn, self.gm, "Clean the area", self.ali)
        T.accept(self.conn, self.ali, closed)
        T.mark_done(self.conn, self.ali, closed)

        summary = feed.employee_summary(self.conn, self.ali)
        self.assertEqual(summary["person"]["name"], "Ali")
        self.assertEqual(summary["counts"]["open"], 2)
        self.assertEqual(summary["counts"]["overdue"], 1)
        self.assertEqual(summary["counts"]["unaccepted"], 1)
        self.assertEqual(summary["counts"]["done_30"], 1)
        self.assertEqual({t["id"] for t in summary["open_tasks"]}, {open_task, waiting})
        self.assertTrue(summary["recent"])

    def test_unknown_person_gives_nothing(self):
        self.assertEqual(feed.employee_summary(self.conn, 999), {})

    def test_routines_and_periods_are_listed(self):
        routine = db.insert(self.conn, "routines", code="R1", name="الرد على العملاء",
                            location_id=self.jadriya)
        db.insert(self.conn, "routine_owners", routine_id=routine, user_id=self.ali, role="owner")
        period = db.insert(self.conn, "routine_periods", routine_id=routine, name="صباحية",
                           start_time="08:00", end_time="17:00")
        db.insert(self.conn, "period_schedule", period_id=period, weekday="sun", user_id=self.ali)
        summary = feed.employee_summary(self.conn, self.ali)
        self.assertEqual(summary["routines"][0]["code"], "R1")
        self.assertEqual(summary["periods"][0]["weekday"], "sun")


if __name__ == "__main__":
    unittest.main(verbosity=2)
