"""سجل المهام: every task by its timestamps, filtered, totalled, exported."""
from __future__ import annotations

import csv
import importlib
import io
import os
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.core import auth, ledger  # noqa: E402
from ims.core import tasks as T  # noqa: E402

PASSWORD = "test-only-not-a-real-password"


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        path = os.path.join(self.tmp.name, "test.db")
        conn = db.connect(path)
        db.migrate(conn)
        self.jadriya = db.insert(conn, "locations", name="الجادرية")
        self.sinaa = db.insert(conn, "locations", name="الصناعة")
        self.gm = db.insert(conn, "users", name="أحمد", role="gm", location_id=self.jadriya,
                            telegram_id=1, telegram_username="ahmed")
        self.mgr = db.insert(conn, "users", name="حيدر", role="manager",
                             location_id=self.jadriya, manager_id=self.gm, telegram_id=2)
        self.ali = db.insert(conn, "users", name="علي", role="employee",
                             location_id=self.jadriya, manager_id=self.mgr, telegram_id=3)
        self.noor = db.insert(conn, "users", name="نور", role="employee",
                              location_id=self.jadriya, manager_id=self.mgr, telegram_id=4)
        self.kareem = db.insert(conn, "users", name="كريم", role="employee",
                                location_id=self.sinaa, telegram_id=5)
        auth.set_password(conn, self.gm, PASSWORD)
        conn.close()

        os.environ["DB_PATH"] = path
        os.environ["SESSION_SECRET"] = "test-secret"
        from ims.web import app as web_app
        self.web = importlib.reload(web_app)
        self.conn = self.web.conn
        from fastapi.testclient import TestClient
        self.client = TestClient(self.web.app)
        self.client.post("/login", data={"username": "ahmed", "password": PASSWORD})

        self.today = texts.now().date()
        self.manager_row = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.mgr,))
        self.gm_row = db.one(self.conn, "SELECT * FROM users WHERE id = ?", (self.gm,))

    def tearDown(self) -> None:
        self.conn.close()
        self.tmp.cleanup()

    def task_at(self, title, *, created, closed=None, assignee=None, due=None,
                status=None, location=None):
        """A task placed in time by hand, the way the ledger will read it."""
        task_id = db.insert(
            self.conn, "tasks", title=title, status=status or T.ASSIGNED,
            priority="normal", due_at=due, assignee_id=assignee or self.ali,
            created_by=self.gm, location_id=location or self.jadriya, source="dashboard",
            created_at=f"{created} 09:00:00",
            closed_at=f"{closed} 16:00:00" if closed else None)
        if closed and status is None:
            db.update(self.conn, "tasks", task_id, status=T.DONE)
        return task_id

    def run_query(self, viewer=None, **kwargs):
        options = {"start": self.today - timedelta(days=30), "end": self.today}
        options.update(kwargs)
        return ledger.query(self.conn, viewer or self.gm_row, **options)

    def titles(self, result):
        return [item["task"]["title"] for item in result["rows"]]


class TestTheRange(Base):
    def test_newest_first_by_the_chosen_timestamp(self):
        self.task_at("قديمة", created=(self.today - timedelta(days=5)).isoformat())
        self.task_at("حديثة", created=self.today.isoformat())
        self.assertEqual(self.titles(self.run_query()), ["حديثة", "قديمة"])

    def test_a_day_outside_the_range_is_left_out(self):
        self.task_at("خارج المدى", created=(self.today - timedelta(days=40)).isoformat())
        self.task_at("داخل المدى", created=self.today.isoformat())
        self.assertEqual(self.titles(self.run_query()), ["داخل المدى"])

    def test_created_and_closed_are_different_questions(self):
        old = (self.today - timedelta(days=20)).isoformat()
        self.task_at("بدأت الشهر الماضي وأُغلقت اليوم", created=old, closed=self.today.isoformat())
        today_only = {"start": self.today, "end": self.today}
        self.assertEqual(self.titles(self.run_query(anchor="created", **today_only)), [])
        self.assertEqual(len(self.titles(self.run_query(anchor="closed", **today_only))), 1)

    def test_the_quick_ranges_land_where_they_should(self):
        spans = ledger.ranges(date(2026, 10, 14))          # a Wednesday
        self.assertEqual(spans["today"], (date(2026, 10, 14), date(2026, 10, 14)))
        self.assertEqual(spans["week"][0], date(2026, 10, 10))        # the Saturday
        self.assertEqual(spans["month"], (date(2026, 10, 1), date(2026, 10, 14)))
        self.assertEqual(spans["prev_month"], (date(2026, 9, 1), date(2026, 9, 30)))


class TestFilters(Base):
    def setUp(self) -> None:
        super().setUp()
        self.task_at("تصوير المنتجات", created=self.today.isoformat(), assignee=self.ali)
        self.task_at("جرد الحساسات", created=self.today.isoformat(), assignee=self.noor,
                     closed=self.today.isoformat())
        self.task_at("مهمة ملغاة", created=self.today.isoformat(), status=T.CANCELLED)
        self.task_at("مهمة الصناعة", created=self.today.isoformat(), assignee=self.kareem,
                     location=self.sinaa)

    def test_by_person(self):
        self.assertEqual(self.titles(self.run_query(assignee=self.noor)), ["جرد الحساسات"])

    def test_by_state(self):
        self.assertEqual(self.titles(self.run_query(status="done")), ["جرد الحساسات"])
        self.assertEqual(self.titles(self.run_query(status="cancelled")), ["مهمة ملغاة"])
        self.assertNotIn("جرد الحساسات", self.titles(self.run_query(status="open")))

    def test_by_words_in_the_title(self):
        self.assertEqual(self.titles(self.run_query(text="تصوير")), ["تصوير المنتجات"])

    def test_a_branch_manager_sees_only_his_branch(self):
        self.assertNotIn("مهمة الصناعة", self.titles(self.run_query(viewer=self.manager_row)))
        self.assertIn("مهمة الصناعة", self.titles(self.run_query()))


class TestTheNumbers(Base):
    def test_duration_and_on_time(self):
        early = db.insert(self.conn, "tasks", title="في الموعد", status=T.DONE, priority="normal",
                          assignee_id=self.ali, created_by=self.gm, location_id=self.jadriya,
                          due_at=f"{self.today} 17:00", created_at=f"{self.today} 09:00:00",
                          closed_at=f"{self.today} 12:30:00")
        db.insert(self.conn, "tasks", title="متأخرة", status=T.DONE, priority="normal",
                  assignee_id=self.ali, created_by=self.gm, location_id=self.jadriya,
                  due_at=f"{self.today} 12:00", created_at=f"{self.today} 09:00:00",
                  closed_at=f"{self.today} 18:00:00")
        result = self.run_query()
        by_id = {item["task"]["id"]: item for item in result["rows"]}
        self.assertEqual(by_id[early]["duration"], "3:30 ساعة")
        self.assertTrue(by_id[early]["on_time"])
        self.assertEqual(result["totals"]["on_time_pct"], 50)
        self.assertEqual(result["totals"]["done"], 2)

    def test_an_open_task_has_no_duration_and_no_verdict(self):
        self.task_at("مفتوحة", created=self.today.isoformat())
        item = self.run_query()["rows"][0]
        self.assertEqual(item["duration"], "—")
        self.assertIsNone(item["on_time"])

    def test_totals_count_the_whole_range_not_the_page(self):
        for index in range(ledger.PAGE_SIZE + 5):
            self.task_at(f"مهمة {index}", created=self.today.isoformat())
        first = self.run_query(limit=ledger.PAGE_SIZE, offset=0)
        self.assertEqual(len(first["rows"]), ledger.PAGE_SIZE)
        self.assertEqual(first["totals"]["all_rows"], ledger.PAGE_SIZE + 5)
        self.assertTrue(first["has_more"])
        second = self.run_query(limit=ledger.PAGE_SIZE, offset=ledger.PAGE_SIZE)
        self.assertEqual(len(second["rows"]), 5)
        self.assertFalse(second["has_more"])

    def test_durations_read_in_arabic(self):
        self.assertEqual(ledger.duration_ar(None), "—")
        self.assertEqual(ledger.duration_ar(45), "45 دقيقة")
        self.assertEqual(ledger.duration_ar(90), "1:30 ساعة")
        self.assertEqual(ledger.duration_ar(60 * 26), "1 يوم 2 ساعة")
        self.assertEqual(ledger.duration_ar(60 * 48), "2 يوم")


class TestThePage(Base):
    def test_it_renders_and_filters_from_the_query_string(self):
        self.task_at("تصوير المنتجات", created=self.today.isoformat())
        body = self.client.get("/ledger").text
        self.assertIn("سجل المهام", body)
        self.assertIn("تصوير المنتجات", body)
        self.assertNotIn("تصوير المنتجات",
                         self.client.get("/ledger?text=شيء آخر").text)

    def test_the_csv_opens_in_excel_with_the_arabic_intact(self):
        self.task_at("تصوير المنتجات", created=self.today.isoformat(),
                     closed=self.today.isoformat())
        response = self.client.get("/ledger.csv")
        self.assertEqual(response.status_code, 200)
        self.assertIn("attachment", response.headers["content-disposition"])
        body = response.content.decode("utf-8")
        self.assertTrue(body.startswith("﻿"))                 # Excel reads the BOM
        rows = list(csv.reader(io.StringIO(body.lstrip("﻿"))))
        self.assertEqual(rows[0][1], "العنوان")
        self.assertEqual(rows[1][1], "تصوير المنتجات")
        self.assertEqual(rows[1][2], "منجزة")

    def test_a_bad_date_falls_back_instead_of_breaking(self):
        self.assertEqual(self.client.get("/ledger?start=nonsense&end=").status_code, 200)

    def test_a_backwards_range_is_swapped(self):
        self.task_at("مهمة", created=self.today.isoformat())
        body = self.client.get(f"/ledger?start={self.today}&end={self.today - timedelta(days=3)}").text
        self.assertIn("مهمة", body)


class TestTheBoard(Base):
    def test_finished_and_cancelled_tasks_leave_the_board(self):
        open_task, _ = T.create_task(self.conn, self.gm, "مهمة مفتوحة", self.ali)
        done, _ = T.create_task(self.conn, self.gm, "مهمة منجزة", self.ali)
        T.accept(self.conn, self.ali, done)
        T.mark_done(self.conn, self.ali, done)
        killed, _ = T.create_task(self.conn, self.gm, "مهمة ملغاة", self.ali)
        T.cancel(self.conn, self.gm, killed, "لم تعد مطلوبة")

        board = self.client.get("/").text
        self.assertIn("مهمة مفتوحة", board)
        self.assertNotIn("مهمة منجزة", board)
        self.assertNotIn("مهمة ملغاة", board)
        self.assertNotIn("منجزة</span>", board)          # the column itself is gone

        record = self.client.get("/ledger").text           # but the ledger has all three
        for title in ("مهمة مفتوحة", "مهمة منجزة", "مهمة ملغاة"):
            self.assertIn(title, record)

    def test_the_board_links_to_todays_ledger_with_the_count(self):
        done, _ = T.create_task(self.conn, self.gm, "مهمة منجزة", self.ali)
        T.accept(self.conn, self.ali, done)
        T.mark_done(self.conn, self.ali, done)
        board = self.client.get("/").text
        self.assertIn("/ledger?range=today", board)
        self.assertIn("1 منجزة", board)


if __name__ == "__main__":
    unittest.main(verbosity=2)
