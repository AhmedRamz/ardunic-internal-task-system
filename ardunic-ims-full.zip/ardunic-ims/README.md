# Ardunic Internal Management System

Telegram bot + web dashboard for Ardunic's internal tasks, daily routines and their
time periods. Pilot: the Jadriya branch. Interface language: Arabic (RTL).

Spec: *Ardunic Internal Management System — V1 Spec*. UI: *Ardunic Internal Management System — UI/UX Mockups*.

## What is in this repository now (phase 1 + 2)

| Path | What it holds |
| --- | --- |
| `schema.sql` | The whole V1 database: tasks, history, routines, periods, swaps, leave, check-in times |
| `src/ims/core/tasks.py` | **The task rules.** Every status change in the system goes through this module |
| `src/ims/bot/` | The Telegram bot: linking, `/new`, `/suggest`, `/mytasks`, and the action buttons |
| `src/ims/texts.py` | Every Arabic string the bot sends |
| `tests/test_tasks.py` | 29 tests over the rules: permissions, rejection reasons, delegation, handover |
| `scripts/seed.py` | Creates the database, the pilot team, the 7 routines, R1's periods, the check-in times |
| `deploy/` | `install.sh`, the systemd unit, the backup script |

Still to come: the scheduled check-ins (phase 3), routines and periods in the bot and
the weekly board (phase 4), the web dashboard (phase 5), group `/task` (phase 6).

## Running it on your machine

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # put the BotFather token in BOT_TOKEN
python scripts/seed.py --db ims.db
PYTHONPATH=src python -m ims.bot.app
```

Then open the bot in Telegram and send the link code the seed script printed:
`/start 123456`.

Tests need nothing installed:

```bash
python3 -m unittest discover -s tests -v
```

## Putting it on the server

```bash
# on the server, as root
git clone <your private repo> /root/ardunic-ims && cd /root/ardunic-ims
bash deploy/install.sh          # installs, seeds, creates the service
nano /opt/ardunic-ims/.env      # paste BOT_TOKEN
systemctl start ims-bot
journalctl -u ims-bot -f        # watch it come up
```

Updating later: `git pull`, then `bash deploy/install.sh` again (it keeps `.env` and the database).

## Decisions worth remembering

- **Everything goes through `core/tasks.py`.** The bot, the dashboard and the scheduler
  call the same functions, so the lifecycle cannot drift apart between them.
- **Nothing is deleted.** Tasks are cancelled or closed; every change is a row in `task_events`.
- **A rejection needs a reason**, a handover needs the manager's approval *and* the
  receiving employee's acceptance, and delegation works only when the task allows it.
- **Periods have no backup.** A period with nobody on it is a gap the manager fills
  from the weekly board; an employee who cannot work theirs swaps it at least 2 hours ahead.
- **Dashboard logins are for the GM and the branch manager only.** Employees use the bot.
- SQLite now, PostgreSQL when the second branch joins; the DDL ports with small type changes.

## Security notes

- `.env` holds the bot token: it is in `.gitignore`, keep it out of the repository.
- The bot ignores every Telegram account that is not linked to a person in `users`.
- In groups the bot answers commands only; it does not read or store other messages.
