"""Rules tests. No network, no Telegram — just the lifecycle and the permissions."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import tasks as T  # noqa: E402


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        self.jadriya = db.insert(self.conn, "locations", name="Jadriya")
        self.sinaa = db.insert(self.conn, "locations", name="Sinaa")
        self.gm = db.insert(self.conn, "users", name="Ahmed", role="gm", location_id=self.jadriya)
        self.mgr = db.insert(self.conn, "users", name="Haider", role="manager",
                             location_id=self.jadriya, manager_id=self.gm)
        self.ali = db.insert(self.conn, "users", name="Ali", role="employee",
                             location_id=self.jadriya, manager_id=self.mgr)
        self.zainab = db.insert(self.conn, "users", name="Zainab", role="employee",
                                location_id=self.jadriya, manager_id=self.mgr)
        self.other = db.insert(self.conn, "users", name="Kareem", role="employee", location_id=self.sinaa)

    def status(self, task_id: int) -> str:
        return T.get_task(self.conn, task_id)["status"]


class TestCreate(Base):
    def test_gm_assigns_to_manager_and_employee(self):
        t1, ev = T.create_task(self.conn, self.gm, "Check wholesale orders", self.mgr)
        self.assertEqual(self.status(t1), T.ASSIGNED)
        self.assertEqual(ev.recipients, (self.mgr,))
        t2, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        self.assertEqual(self.status(t2), T.ASSIGNED)

    def test_manager_cannot_assign_outside_branch_or_to_manager(self):
        with self.assertRaises(T.RuleError):
            T.create_task(self.conn, self.mgr, "x", self.other)
        with self.assertRaises(T.RuleError):
            T.create_task(self.conn, self.mgr, "x", self.mgr)

    def test_employee_cannot_create(self):
        with self.assertRaises(T.RuleError):
            T.create_task(self.conn, self.ali, "x", self.zainab)

    def test_title_is_required(self):
        with self.assertRaises(T.RuleError):
            T.create_task(self.conn, self.gm, "   ", self.ali)


class TestSuggestions(Base):
    def test_employee_suggestion_goes_to_branch_manager(self):
        task_id, ev = T.suggest_task(self.conn, self.ali, "Buy more shelves")
        self.assertEqual(self.status(task_id), T.SUGGESTED)
        self.assertEqual(ev.recipients, (self.mgr,))

    def test_manager_suggestion_goes_to_gm(self):
        _, ev = T.suggest_task(self.conn, self.mgr, "Hire a packer")
        self.assertEqual(ev.recipients, (self.gm,))

    def test_approval_can_change_assignee_and_priority(self):
        task_id, _ = T.suggest_task(self.conn, self.ali, "Buy more shelves")
        T.approve_suggestion(self.conn, self.mgr, task_id, assignee_id=self.zainab, priority="high")
        row = T.get_task(self.conn, task_id)
        self.assertEqual((row["status"], row["assignee_id"], row["priority"]),
                         (T.ASSIGNED, self.zainab, "high"))

    def test_decline_needs_a_reason(self):
        task_id, _ = T.suggest_task(self.conn, self.ali, "Buy more shelves")
        with self.assertRaises(T.RuleError):
            T.decline_suggestion(self.conn, self.mgr, task_id, "  ")
        T.decline_suggestion(self.conn, self.mgr, task_id, "too expensive this month")
        self.assertEqual(self.status(task_id), T.CANCELLED)


class TestAcceptReject(Base):
    def setUp(self):
        super().setUp()
        self.task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)

    def test_accept(self):
        T.accept(self.conn, self.ali, self.task)
        self.assertEqual(self.status(self.task), T.IN_PROGRESS)

    def test_only_the_assignee_accepts(self):
        with self.assertRaises(T.RuleError):
            T.accept(self.conn, self.zainab, self.task)

    def test_reject_requires_a_reason(self):
        with self.assertRaises(T.RuleError):
            T.reject(self.conn, self.ali, self.task, "")
        ev = T.reject(self.conn, self.ali, self.task, "busy with the wholesale order")
        self.assertEqual(self.status(self.task), T.REJECTED)
        self.assertIn(self.gm, ev.recipients)

    def test_rejected_task_can_be_reassigned(self):
        T.reject(self.conn, self.ali, self.task, "busy")
        T.reassign(self.conn, self.mgr, self.task, self.zainab)
        row = T.get_task(self.conn, self.task)
        self.assertEqual((row["status"], row["assignee_id"]), (T.ASSIGNED, self.zainab))


class TestDelegation(Base):
    def test_manager_delegates_when_allowed(self):
        task, _ = T.create_task(self.conn, self.gm, "Follow the orders", self.mgr, allow_delegation=True)
        ev = T.delegate(self.conn, self.mgr, task, self.ali, "start with 4521")
        row = T.get_task(self.conn, task)
        self.assertEqual((row["status"], row["assignee_id"], row["delegated_from"]),
                         (T.ASSIGNED, self.ali, self.mgr))
        self.assertIn(self.gm, ev.recipients)      # the creator is told
        T.accept(self.conn, self.ali, task)
        self.assertEqual(self.status(task), T.IN_PROGRESS)

    def test_delegation_refused_when_not_allowed(self):
        task, _ = T.create_task(self.conn, self.gm, "Follow the orders", self.mgr, allow_delegation=False)
        with self.assertRaises(T.RuleError):
            T.delegate(self.conn, self.mgr, task, self.ali)

    def test_flag_is_dropped_for_employee_tasks(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali, allow_delegation=True)
        self.assertEqual(T.get_task(self.conn, task)["allow_delegation"], 0)

    def test_employee_cannot_delegate(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali, allow_delegation=True)
        with self.assertRaises(T.RuleError):
            T.delegate(self.conn, self.ali, task, self.zainab)


class TestHandover(Base):
    def setUp(self):
        super().setUp()
        self.task, _ = T.create_task(self.conn, self.gm, "Check returned UPS units", self.ali)
        T.accept(self.conn, self.ali, self.task)

    def test_needs_both_yeses(self):
        T.request_handover(self.conn, self.ali, self.task, self.zainab, "Zainab knows UPS better")
        self.assertEqual(self.status(self.task), T.HANDOVER)
        # the receiving employee cannot accept before the manager approves
        with self.assertRaises(T.RuleError):
            T.accept_handover(self.conn, self.zainab, self.task)
        T.approve_handover(self.conn, self.mgr, self.task)
        self.assertEqual(T.get_task(self.conn, self.task)["assignee_id"], self.ali)  # still Ali
        T.accept_handover(self.conn, self.zainab, self.task)
        row = T.get_task(self.conn, self.task)
        self.assertEqual((row["status"], row["assignee_id"]), (T.IN_PROGRESS, self.zainab))

    def test_reason_required_and_manager_can_decline(self):
        with self.assertRaises(T.RuleError):
            T.request_handover(self.conn, self.ali, self.task, self.zainab, " ")
        T.request_handover(self.conn, self.ali, self.task, self.zainab, "swamped today")
        T.decline_handover(self.conn, self.mgr, self.task, "finish it yourself")
        row = T.get_task(self.conn, self.task)
        self.assertEqual((row["status"], row["assignee_id"]), (T.IN_PROGRESS, self.ali))

    def test_employee_rejection_returns_the_task(self):
        T.request_handover(self.conn, self.ali, self.task, self.zainab, "swamped today")
        T.approve_handover(self.conn, self.mgr, self.task)
        ev = T.reject_handover(self.conn, self.zainab, self.task, "I am on the counter all day")
        row = T.get_task(self.conn, self.task)
        self.assertEqual((row["status"], row["assignee_id"]), (T.IN_PROGRESS, self.ali))
        self.assertIn(self.ali, ev.recipients)


class TestReview(Base):
    def test_review_on_goes_to_the_manager(self):
        task, _ = T.create_task(self.conn, self.gm, "Shoot product photos", self.ali, needs_review=True)
        T.accept(self.conn, self.ali, task)
        ev = T.mark_done(self.conn, self.ali, task)
        self.assertEqual(self.status(task), T.REVIEW)
        self.assertIn(self.mgr, ev.recipients)
        T.review_return(self.conn, self.mgr, task, "two photos are blurry")
        self.assertEqual(self.status(task), T.IN_PROGRESS)
        T.mark_done(self.conn, self.ali, task)
        T.review_approve(self.conn, self.gm, task)
        self.assertEqual(self.status(task), T.DONE)

    def test_review_off_closes_at_once(self):
        task, _ = T.create_task(self.conn, self.gm, "Clean the receiving area", self.ali)
        T.accept(self.conn, self.ali, task)
        T.mark_done(self.conn, self.ali, task)
        self.assertEqual(self.status(task), T.DONE)
        self.assertIsNotNone(T.get_task(self.conn, task)["closed_at"])

    def test_employee_cannot_review(self):
        task, _ = T.create_task(self.conn, self.gm, "Shoot photos", self.ali, needs_review=True)
        T.accept(self.conn, self.ali, task)
        T.mark_done(self.conn, self.ali, task)
        with self.assertRaises(T.RuleError):
            T.review_approve(self.conn, self.ali, task)


class TestUpdatesAndAdmin(Base):
    def setUp(self):
        super().setUp()
        self.task, _ = T.create_task(self.conn, self.gm, "Sort the shipment", self.ali)
        T.accept(self.conn, self.ali, self.task)

    def test_blocked_update_needs_a_note_and_tells_the_manager(self):
        with self.assertRaises(T.RuleError):
            T.post_update(self.conn, self.ali, self.task, "blocked", "")
        ev = T.post_update(self.conn, self.ali, self.task, "blocked", "waiting for the supplier invoice")
        self.assertIn(self.mgr, ev.recipients)
        self.assertEqual(self.status(self.task), T.IN_PROGRESS)

    def test_working_update_is_quiet(self):
        ev = T.post_update(self.conn, self.ali, self.task, "working", "14 of 20 done")
        self.assertEqual(ev.recipients, ())

    def test_carry_over_needs_a_note(self):
        with self.assertRaises(T.RuleError):
            T.carry_over(self.conn, self.ali, self.task, " ")
        T.carry_over(self.conn, self.ali, self.task, "3 of 5 shelves done")
        self.assertEqual(self.status(self.task), T.IN_PROGRESS)

    def test_cancel_keeps_history(self):
        T.cancel(self.conn, self.gm, self.task, "customer postponed")
        self.assertEqual(self.status(self.task), T.CANCELLED)
        actions = [e["action"] for e in T.history(self.conn, self.task)]
        self.assertEqual(actions, ["created", "accepted", "cancelled"])

    def test_comment_notifies_the_others_and_the_manager(self):
        ev = T.add_comment(self.conn, self.ali, self.task, "started with drawer C-4")
        self.assertIn(self.gm, ev.recipients)       # the creator
        self.assertIn(self.mgr, ev.recipients)      # and the branch manager
        self.assertNotIn(self.ali, ev.recipients)   # never the person who wrote it


class TestVisibility(Base):
    def test_scope_per_role(self):
        t_jad, _ = T.create_task(self.conn, self.gm, "Jadriya task", self.ali)
        t_sin, _ = T.create_task(self.conn, self.gm, "Sinaa task", self.other)
        self.assertEqual(len(T.visible_tasks(self.conn, self.gm)), 2)
        self.assertEqual([r["id"] for r in T.visible_tasks(self.conn, self.mgr)], [t_jad])
        self.assertEqual([r["id"] for r in T.visible_tasks(self.conn, self.ali)], [t_jad])
        self.assertEqual([r["id"] for r in T.visible_tasks(self.conn, self.other)], [t_sin])

    def test_open_tasks_sorted_by_priority(self):
        T.create_task(self.conn, self.gm, "normal", self.ali, priority="normal")
        urgent, _ = T.create_task(self.conn, self.gm, "urgent", self.ali, priority="urgent")
        self.assertEqual(T.open_tasks_for(self.conn, self.ali)[0]["id"], urgent)


if __name__ == "__main__":
    unittest.main(verbosity=2)
