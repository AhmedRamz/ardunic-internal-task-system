"""Notifications: who hears about what, and that dashboard actions queue messages."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import notify  # noqa: E402
from ims.core import tasks as T  # noqa: E402


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.conn = db.connect(":memory:")
        db.migrate(self.conn)
        loc = db.insert(self.conn, "locations", name="Jadriya")
        self.gm = db.insert(self.conn, "users", name="Ahmed", role="gm", location_id=loc,
                            telegram_id=1001)
        self.mgr = db.insert(self.conn, "users", name="Haider", role="manager", location_id=loc,
                             manager_id=self.gm, telegram_id=1002)
        self.ali = db.insert(self.conn, "users", name="Ali", role="employee", location_id=loc,
                             manager_id=self.mgr, telegram_id=1003)
        self.unlinked = db.insert(self.conn, "users", name="Noor", role="employee", location_id=loc,
                                  manager_id=self.mgr)

    def queued_for(self) -> list[int]:
        return [r["user_id"] for r in db.all_rows(self.conn, "SELECT user_id FROM outbox ORDER BY id")]


class TestRecipients(Base):
    def test_employee_comment_reaches_the_manager(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        event = T.add_comment(self.conn, self.ali, task, "started with drawer C-4")
        self.assertIn(self.mgr, event.recipients)   # the manager, even though the GM created it
        self.assertIn(self.gm, event.recipients)
        self.assertNotIn(self.ali, event.recipients)

    def test_manager_comment_does_not_notify_himself(self):
        task, _ = T.create_task(self.conn, self.mgr, "Sort the shipment", self.ali)
        event = T.add_comment(self.conn, self.mgr, task, "please finish today")
        self.assertEqual(event.recipients, (self.ali,))

    def test_done_tells_the_manager_as_well_as_the_creator(self):
        task, _ = T.create_task(self.conn, self.gm, "Clean the area", self.ali)
        T.accept(self.conn, self.ali, task)
        event = T.mark_done(self.conn, self.ali, task)
        self.assertIn(self.gm, event.recipients)
        self.assertIn(self.mgr, event.recipients)


class TestOutbox(Base):
    def test_new_task_from_the_dashboard_is_queued(self):
        _, event = T.create_task(self.conn, self.gm, "Shoot photos", self.ali, source="dashboard")
        self.assertEqual(notify.queue(self.conn, event), 1)
        self.assertEqual(self.queued_for(), [self.ali])
        row = db.one(self.conn, "SELECT * FROM outbox WHERE id = 1")
        self.assertIn("Shoot photos", row["body"])
        self.assertIsNone(row["sent_at"])

    def test_unlinked_people_are_skipped(self):
        _, event = T.create_task(self.conn, self.gm, "Answer messages", self.unlinked)
        self.assertEqual(notify.queue(self.conn, event), 0)

    def test_actor_is_never_notified(self):
        task, _ = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        event = T.add_comment(self.conn, self.gm, task, "any update?")
        notify.queue(self.conn, event)
        self.assertNotIn(self.gm, self.queued_for())

    def test_pending_then_marked_sent(self):
        _, event = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        notify.queue(self.conn, event)
        pending = notify.pending(self.conn)
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["telegram_id"], 1003)
        notify.mark_sent(self.conn, pending[0]["id"])
        self.assertEqual(notify.pending(self.conn), [])

    def test_failures_retry_then_give_up(self):
        _, event = T.create_task(self.conn, self.gm, "Count sensors", self.ali)
        notify.queue(self.conn, event)
        row_id = notify.pending(self.conn)[0]["id"]
        for _ in range(5):
            notify.mark_failed(self.conn, row_id, "chat not found")
        self.assertEqual(notify.pending(self.conn), [])      # stops after 5 attempts
        row = db.one(self.conn, "SELECT * FROM outbox WHERE id = ?", (row_id,))
        self.assertEqual(row["last_error"], "chat not found")


if __name__ == "__main__":
    unittest.main(verbosity=2)
