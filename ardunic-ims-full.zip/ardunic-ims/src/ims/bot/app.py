"""Bot entry point: python -m ims.bot.app"""
from __future__ import annotations

import asyncio
import logging
import sqlite3
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware, Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import TelegramObject

from .. import db, texts
from ..config import Config
from . import handlers, notify, scheduler


class UserMiddleware(BaseMiddleware):
    """Puts the connection and the linked user in every handler's arguments.

    An unlinked Telegram account only reaches /start — everything else is ignored,
    which is the rule from the spec.
    """

    OPEN_COMMANDS = ("/start", "/help")

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        data["conn"] = self.conn
        tg_user = data.get("event_from_user")
        user = handlers.user_of(self.conn, tg_user.id) if tg_user else None
        data["user"] = user
        if user is None:
            text = getattr(event, "text", "") or ""
            if text.split(" ")[0] in self.OPEN_COMMANDS:
                return await handler(event, data)
            message = getattr(event, "message", None) or (event if hasattr(event, "answer") else None)
            if message is not None and getattr(event, "text", None):
                await message.answer(texts.NOT_LINKED)
            return None
        return await handler(event, data)


async def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    config = Config.load()
    if not config.bot_token:
        raise SystemExit("BOT_TOKEN is missing — copy .env.example to .env and fill it in")

    conn = db.connect(config.db_path)
    db.migrate(conn)

    bot = Bot(config.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.message.middleware(UserMiddleware(conn))
    dp.callback_query.middleware(UserMiddleware(conn))
    dp.include_router(handlers.router)

    me = await bot.get_me()
    logging.info("Ardunic IMS bot running as @%s", me.username)

    # delivers what the dashboard queues, as well as anything a handler left behind
    workers = [
        asyncio.create_task(notify.outbox_worker(bot, conn)),
        asyncio.create_task(scheduler.scheduler_worker(
            conn, config.accept_reminder_hours, config.accept_escalate_hours)),
    ]
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        for worker in workers:
            worker.cancel()


if __name__ == "__main__":
    asyncio.run(main())
