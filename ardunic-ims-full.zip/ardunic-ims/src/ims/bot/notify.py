"""Turning a core Event into Telegram messages.

The core never talks to Telegram; it returns an Event with the people to tell.
This module is the only place that knows how those messages look.
"""
from __future__ import annotations

import logging
import sqlite3

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError

from .. import db, texts
from ..core import tasks as T
from . import keyboards

log = logging.getLogger(__name__)


async def send_event(bot: Bot, conn: sqlite3.Connection, event: T.Event) -> None:
    template = texts.EVENT_TEXT.get(event.action)
    if not template or not event.recipients:
        return
    task = T.get_task(conn, event.task_id)
    actor = db.one(conn, "SELECT name FROM users WHERE id = ?", (event.actor_id,))
    body = template.format(
        id=task["id"],
        title=task["title"],
        actor=actor["name"] if actor else "",
        due=texts.due_label(task["due_at"]),
        priority=f"{texts.PRIORITY_DOT[task['priority']]} {texts.PRIORITY[task['priority']]}",
        note=event.note or "",
    )
    handover = db.one(
        conn,
        "SELECT * FROM handovers WHERE task_id = ? ORDER BY id DESC LIMIT 1",
        (task["id"],),
    )
    for user_id in dict.fromkeys(event.recipients):          # de-duplicated, order kept
        if not user_id or user_id == event.actor_id:
            continue
        user = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))
        if user is None or not user["telegram_id"]:
            continue
        await send_to(bot, user, body, keyboards.task_actions(task, user, handover))


async def send_to(bot: Bot, user: sqlite3.Row, text: str, keyboard=None) -> None:
    try:
        await bot.send_message(user["telegram_id"], text, reply_markup=keyboard)
    except TelegramAPIError as exc:                           # blocked the bot, left the chat, ...
        log.warning("could not message %s (%s): %s", user["name"], user["telegram_id"], exc)
