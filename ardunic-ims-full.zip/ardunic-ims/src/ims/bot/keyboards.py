"""Inline keyboards. Which buttons a message carries depends on the status and on who is looking."""
from __future__ import annotations

import sqlite3

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from .. import db
from ..core import tasks as T


def _kb(rows: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


def task_actions(task: sqlite3.Row, viewer: sqlite3.Row,
                 handover: sqlite3.Row | None = None) -> InlineKeyboardMarkup | None:
    """The buttons under a task message."""
    tid = task["id"]
    rows: list[list[InlineKeyboardButton]] = []
    is_assignee = task["assignee_id"] == viewer["id"]
    supervises = viewer["role"] == "gm" or (
        viewer["role"] == "manager" and viewer["location_id"] == task["location_id"]
    )

    if task["status"] == T.ASSIGNED and is_assignee:
        row = [InlineKeyboardButton(text="✅ قبول", callback_data=f"t:accept:{tid}"),
               InlineKeyboardButton(text="❌ رفض", callback_data=f"t:reject:{tid}")]
        rows.append(row)
        if task["allow_delegation"] and viewer["role"] == "manager":
            rows.append([InlineKeyboardButton(text="🔀 تفويض", callback_data=f"t:delegate:{tid}")])

    elif task["status"] == T.IN_PROGRESS and is_assignee:
        rows.append([InlineKeyboardButton(text="✔️ تم الإنجاز", callback_data=f"t:done:{tid}"),
                     InlineKeyboardButton(text="🔄 طلب تسليم", callback_data=f"t:handover:{tid}")])
        if task["allow_delegation"] and viewer["role"] == "manager":
            rows.append([InlineKeyboardButton(text="🔀 تفويض", callback_data=f"t:delegate:{tid}")])

    elif task["status"] == T.SUGGESTED and supervises:
        rows.append([InlineKeyboardButton(text="✅ موافقة وإسناد", callback_data=f"t:sug_ok:{tid}"),
                     InlineKeyboardButton(text="❌ رفض", callback_data=f"t:sug_no:{tid}")])

    elif task["status"] == T.REVIEW and supervises:
        rows.append([InlineKeyboardButton(text="✅ اعتماد وإغلاق", callback_data=f"t:rev_ok:{tid}"),
                     InlineKeyboardButton(text="↩️ إعادة مع ملاحظة", callback_data=f"t:rev_back:{tid}")])

    elif task["status"] == T.HANDOVER:
        waiting_manager = handover is not None and handover["status"] == "pending"
        waiting_target = (handover is not None and handover["status"] == "awaiting_employee"
                          and handover["to_user"] == viewer["id"])
        if supervises and waiting_manager:
            rows.append([InlineKeyboardButton(text="✅ موافقة على التسليم", callback_data=f"t:ho_ok:{tid}"),
                         InlineKeyboardButton(text="❌ رفض الطلب", callback_data=f"t:ho_no:{tid}")])
        if waiting_target:
            rows.append([InlineKeyboardButton(text="📥 قبول الاستلام", callback_data=f"t:ho_take:{tid}"),
                         InlineKeyboardButton(text="📤 رفض الاستلام", callback_data=f"t:ho_drop:{tid}")])

    elif task["status"] == T.REJECTED and supervises:
        rows.append([InlineKeyboardButton(text="📋 إعادة إسناد", callback_data=f"t:reassign:{tid}"),
                     InlineKeyboardButton(text="🚫 إلغاء", callback_data=f"t:cancel:{tid}")])

    if task["status"] in T.OPEN_STATUSES:
        rows.append([InlineKeyboardButton(text="💬 تعليق", callback_data=f"t:comment:{tid}")])
    return _kb(rows) if rows else None


def people_picker(people: list[sqlite3.Row], prefix: str, task_id: int,
                  columns: int = 3) -> InlineKeyboardMarkup:
    buttons = [InlineKeyboardButton(text=p["name"], callback_data=f"{prefix}:{task_id}:{p['id']}")
               for p in people]
    rows = [buttons[i:i + columns] for i in range(0, len(buttons), columns)]
    rows.append([InlineKeyboardButton(text="إلغاء", callback_data="t:flow_cancel:0")])
    return _kb(rows)


def draft_keyboard(draft: dict) -> InlineKeyboardMarkup:
    """The summary step of /new: tap any value to change it, then confirm."""
    review = "نعم" if draft.get("needs_review") else "لا"
    delegate = "نعم" if draft.get("allow_delegation") else "لا"
    rows = [
        [InlineKeyboardButton(text=f"الموعد: {draft['due_label']}", callback_data="d:due")],
        [InlineKeyboardButton(text=f"الأولوية: {draft['priority_label']}", callback_data="d:priority"),
         InlineKeyboardButton(text=f"المراجعة: {review}", callback_data="d:review")],
    ]
    if draft.get("assignee_is_manager"):
        rows.append([InlineKeyboardButton(text=f"يسمح بالتفويض: {delegate}", callback_data="d:delegation")])
    rows.append([InlineKeyboardButton(text="➕ وصف", callback_data="d:description")])
    rows.append([InlineKeyboardButton(text="✅ تأكيد وإرسال", callback_data="d:confirm"),
                 InlineKeyboardButton(text="إلغاء", callback_data="d:cancel")])
    return _kb(rows)


def due_picker() -> InlineKeyboardMarkup:
    return _kb([
        [InlineKeyboardButton(text="اليوم 5:00 م", callback_data="due:today")],
        [InlineKeyboardButton(text="غداً 5:00 م", callback_data="due:tomorrow")],
        [InlineKeyboardButton(text="تاريخ ووقت آخر", callback_data="due:custom"),
         InlineKeyboardButton(text="بدون موعد", callback_data="due:none")],
    ])


def priority_picker() -> InlineKeyboardMarkup:
    return _kb([[InlineKeyboardButton(text="⚪️ عادية", callback_data="prio:normal"),
                 InlineKeyboardButton(text="🟠 عالية", callback_data="prio:high"),
                 InlineKeyboardButton(text="🔴 عاجلة", callback_data="prio:urgent")]])
