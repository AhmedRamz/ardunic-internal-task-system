"""The task lifecycle. Every status change in the system goes through this module.

The bot, the dashboard and the scheduler all call these functions, so the rules
cannot drift apart between them. Nothing here talks to Telegram or HTTP: the
callers decide who to notify from the returned event.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone

from .. import db

# ----------------------------------------------------------------- constants
SUGGESTED, ASSIGNED, IN_PROGRESS, REJECTED = "suggested", "assigned", "in_progress", "rejected"
HANDOVER, REVIEW, DONE, CANCELLED = "handover", "review", "done", "cancelled"

OPEN_STATUSES = (SUGGESTED, ASSIGNED, IN_PROGRESS, REJECTED, HANDOVER, REVIEW)
PRIORITIES = ("normal", "high", "urgent")
GM, MANAGER, EMPLOYEE = "gm", "manager", "employee"


class RuleError(Exception):
    """A rule of the system refused the action. The message is shown to the user in Arabic."""

    def __init__(self, ar: str, en: str = "") -> None:
        super().__init__(en or ar)
        self.ar = ar
        self.en = en or ar


@dataclass(frozen=True)
class Event:
    """What just happened — the caller uses it to decide who gets a Telegram message."""
    task_id: int
    action: str
    actor_id: int
    from_status: str | None
    to_status: str | None
    note: str | None = None
    recipients: tuple[int, ...] = ()


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


# ----------------------------------------------------------------- lookups
def get_user(conn: sqlite3.Connection, user_id: int) -> sqlite3.Row:
    row = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if row is None:
        raise RuleError("المستخدم غير موجود", "unknown user")
    return row


def get_task(conn: sqlite3.Connection, task_id: int) -> sqlite3.Row:
    row = db.one(conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))
    if row is None:
        raise RuleError("المهمة غير موجودة", "unknown task")
    return row


def _manager_of(conn: sqlite3.Connection, user: sqlite3.Row) -> sqlite3.Row | None:
    if user["manager_id"]:
        return db.one(conn, "SELECT * FROM users WHERE id = ?", (user["manager_id"],))
    return db.one(
        conn,
        "SELECT * FROM users WHERE role = 'manager' AND location_id = ? AND active = 1 LIMIT 1",
        (user["location_id"],),
    )


def _gm(conn: sqlite3.Connection) -> sqlite3.Row | None:
    return db.one(conn, "SELECT * FROM users WHERE role = 'gm' AND active = 1 LIMIT 1")


def _managers_for(conn: sqlite3.Connection, task: sqlite3.Row) -> tuple[int, ...]:
    """The people who supervise this task: the branch manager and the GM."""
    rows = db.all_rows(
        conn,
        "SELECT id FROM users WHERE active = 1 AND (role = 'gm' OR (role = 'manager' AND location_id = ?))",
        (task["location_id"],),
    )
    return tuple(r["id"] for r in rows)


def _log(conn, task_id, actor_id, action, from_status, to_status, note=None) -> None:
    db.insert(
        conn,
        "task_events",
        task_id=task_id,
        actor_id=actor_id,
        action=action,
        from_status=from_status,
        to_status=to_status,
        note=note,
        created_at=_now(),
    )


def _require(condition: bool, ar: str, en: str = "") -> None:
    if not condition:
        raise RuleError(ar, en)


def _is_supervisor(conn: sqlite3.Connection, actor: sqlite3.Row, task: sqlite3.Row) -> bool:
    if actor["role"] == GM:
        return True
    return actor["role"] == MANAGER and actor["location_id"] == task["location_id"]


# ----------------------------------------------------------------- creating
def create_task(
    conn: sqlite3.Connection,
    actor_id: int,
    title: str,
    assignee_id: int,
    *,
    description: str = "",
    due_at: str | None = None,
    priority: str = "normal",
    needs_review: bool = False,
    allow_delegation: bool = False,
    source: str = "dashboard",
) -> tuple[int, Event]:
    """The GM assigns to the branch manager or any employee; a manager assigns inside their branch."""
    actor = get_user(conn, actor_id)
    assignee = get_user(conn, assignee_id)
    _require(bool(title.strip()), "عنوان المهمة مطلوب", "title is required")
    _require(priority in PRIORITIES, "أولوية غير معروفة", "unknown priority")
    _require(actor["role"] in (GM, MANAGER), "الموظف لا ينشئ مهام — استخدم /suggest", "employees must suggest")
    _require(bool(assignee["active"]), "الموظف غير نشط", "assignee is not active")

    if actor["role"] == MANAGER:
        _require(assignee["role"] == EMPLOYEE, "مدير الفرع يُسند للموظفين فقط", "manager assigns to employees")
        _require(
            assignee["location_id"] == actor["location_id"],
            "الموظف ليس في فرعك",
            "assignee belongs to another branch",
        )
    else:  # GM
        _require(assignee["role"] != GM, "لا يمكن إسناد مهمة للمدير العام", "cannot assign to the GM")

    # Delegation only makes sense when a manager holds the task.
    allow_delegation = bool(allow_delegation and assignee["role"] == MANAGER)

    task_id = db.insert(
        conn,
        "tasks",
        title=title.strip(),
        description=description.strip(),
        status=ASSIGNED,
        priority=priority,
        due_at=due_at,
        needs_review=int(needs_review),
        allow_delegation=int(allow_delegation),
        assignee_id=assignee_id,
        created_by=actor_id,
        location_id=assignee["location_id"],
        source=source,
        created_at=_now(),
    )
    _log(conn, task_id, actor_id, "created", None, ASSIGNED, None)
    return task_id, Event(task_id, "created", actor_id, None, ASSIGNED, recipients=(assignee_id,))


def suggest_task(
    conn: sqlite3.Connection,
    actor_id: int,
    title: str,
    *,
    description: str = "",
    due_at: str | None = None,
    priority: str = "normal",
    source: str = "bot",
) -> tuple[int, Event]:
    """A suggestion goes one level up: employee -> branch manager, manager -> GM."""
    actor = get_user(conn, actor_id)
    _require(bool(title.strip()), "عنوان المهمة مطلوب", "title is required")
    _require(actor["role"] in (EMPLOYEE, MANAGER), "المدير العام ينشئ المهام مباشرة", "the GM creates directly")

    approver = _manager_of(conn, actor) if actor["role"] == EMPLOYEE else _gm(conn)
    _require(approver is not None, "لا يوجد مسؤول لاستلام المقترح", "no approver found")

    task_id = db.insert(
        conn,
        "tasks",
        title=title.strip(),
        description=description.strip(),
        status=SUGGESTED,
        priority=priority,
        due_at=due_at,
        assignee_id=None,
        created_by=actor_id,
        location_id=actor["location_id"],
        source="suggestion",
        created_at=_now(),
    )
    _log(conn, task_id, actor_id, "suggested", None, SUGGESTED, None)
    return task_id, Event(task_id, "suggested", actor_id, None, SUGGESTED, recipients=(approver["id"],))


def approve_suggestion(
    conn: sqlite3.Connection,
    actor_id: int,
    task_id: int,
    *,
    assignee_id: int | None = None,
    due_at: str | None = None,
    priority: str | None = None,
    needs_review: bool | None = None,
) -> Event:
    """The approver may change the assignee, the due date and the priority while approving."""
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(task["status"] == SUGGESTED, "المهمة ليست مقترحاً", "task is not a suggestion")
    _require(_is_supervisor(conn, actor, task), "لا تملك صلاحية الموافقة", "not allowed to approve")

    assignee_id = assignee_id or task["created_by"]
    assignee = get_user(conn, assignee_id)
    if actor["role"] == MANAGER:
        _require(assignee["role"] == EMPLOYEE, "مدير الفرع يُسند للموظفين فقط", "manager assigns to employees")

    values = {"status": ASSIGNED, "assignee_id": assignee_id}
    if due_at is not None:
        values["due_at"] = due_at
    if priority is not None:
        _require(priority in PRIORITIES, "أولوية غير معروفة", "unknown priority")
        values["priority"] = priority
    if needs_review is not None:
        values["needs_review"] = int(needs_review)
    db.update(conn, "tasks", task_id, **values)
    _log(conn, task_id, actor_id, "suggestion_approved", SUGGESTED, ASSIGNED, None)
    return Event(task_id, "suggestion_approved", actor_id, SUGGESTED, ASSIGNED,
                 recipients=(assignee_id, task["created_by"]))


def decline_suggestion(conn: sqlite3.Connection, actor_id: int, task_id: int, reason: str) -> Event:
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(task["status"] == SUGGESTED, "المهمة ليست مقترحاً", "task is not a suggestion")
    _require(_is_supervisor(conn, actor, task), "لا تملك صلاحية الرفض", "not allowed")
    _require(bool(reason.strip()), "سبب الرفض مطلوب", "a reason is required")
    db.update(conn, "tasks", task_id, status=CANCELLED, closed_at=_now())
    _log(conn, task_id, actor_id, "suggestion_declined", SUGGESTED, CANCELLED, reason.strip())
    return Event(task_id, "suggestion_declined", actor_id, SUGGESTED, CANCELLED, reason.strip(),
                 recipients=(task["created_by"],))


# ----------------------------------------------------------------- the assignee acts
def accept(conn: sqlite3.Connection, actor_id: int, task_id: int) -> Event:
    task = get_task(conn, task_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(task["status"] == ASSIGNED, "لا يمكن قبول المهمة في حالتها الحالية", "task is not assigned")
    db.update(conn, "tasks", task_id, status=IN_PROGRESS, accepted_at=_now())
    _log(conn, task_id, actor_id, "accepted", ASSIGNED, IN_PROGRESS, None)
    recipients = (task["created_by"],) + ((task["delegated_from"],) if task["delegated_from"] else ())
    return Event(task_id, "accepted", actor_id, ASSIGNED, IN_PROGRESS, recipients=recipients)


def reject(conn: sqlite3.Connection, actor_id: int, task_id: int, reason: str) -> Event:
    """A rejection without a reason is refused — the bot keeps asking until it has one."""
    task = get_task(conn, task_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(task["status"] == ASSIGNED, "لا يمكن رفض المهمة في حالتها الحالية", "task is not assigned")
    _require(bool(reason.strip()), "سبب الرفض مطلوب", "a reason is required")
    db.update(conn, "tasks", task_id, status=REJECTED)
    _log(conn, task_id, actor_id, "rejected", ASSIGNED, REJECTED, reason.strip())
    recipients = (task["created_by"],) + _managers_for(conn, task)
    return Event(task_id, "rejected", actor_id, ASSIGNED, REJECTED, reason.strip(), recipients=recipients)


def delegate(conn: sqlite3.Connection, actor_id: int, task_id: int, to_user_id: int, note: str = "") -> Event:
    """The branch manager passes a GM task to an employee, when the task allows it."""
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    target = get_user(conn, to_user_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(actor["role"] == MANAGER, "التفويض لمدير الفرع فقط", "only a manager delegates")
    _require(bool(task["allow_delegation"]), "هذه المهمة لا تسمح بالتفويض", "delegation is not allowed")
    _require(task["status"] in (ASSIGNED, IN_PROGRESS), "لا يمكن تفويض المهمة في حالتها الحالية", "bad status")
    _require(target["role"] == EMPLOYEE and target["location_id"] == actor["location_id"],
             "اختر موظفاً من فرعك", "pick an employee of your branch")

    db.update(conn, "tasks", task_id, status=ASSIGNED, assignee_id=to_user_id,
              delegated_from=actor_id, accepted_at=None)
    _log(conn, task_id, actor_id, "delegated", task["status"], ASSIGNED, note.strip() or None)
    return Event(task_id, "delegated", actor_id, task["status"], ASSIGNED, note.strip() or None,
                 recipients=(to_user_id, task["created_by"]))


def post_update(conn: sqlite3.Connection, actor_id: int, task_id: int, answer: str, note: str = "") -> Event:
    """Answer to a scheduled update: done / working / blocked."""
    _require(answer in ("done", "working", "blocked"), "إجابة غير معروفة", "unknown answer")
    task = get_task(conn, task_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(task["status"] in (ASSIGNED, IN_PROGRESS), "المهمة ليست مفتوحة", "task is not open")
    if answer == "done":
        return mark_done(conn, actor_id, task_id, note)
    if answer == "blocked":
        _require(bool(note.strip()), "اكتب سبب التوقف", "a note is required when blocked")
    _log(conn, task_id, actor_id, f"update_{answer}", task["status"], task["status"], note.strip() or None)
    recipients = _managers_for(conn, task) if answer == "blocked" else ()
    return Event(task_id, f"update_{answer}", actor_id, task["status"], task["status"],
                 note.strip() or None, recipients=recipients)


def carry_over(conn: sqlite3.Connection, actor_id: int, task_id: int, note: str) -> Event:
    """Close-out answer: the task stays open and tomorrow's brief shows it again."""
    task = get_task(conn, task_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(task["status"] in (ASSIGNED, IN_PROGRESS), "المهمة ليست مفتوحة", "task is not open")
    _require(bool(note.strip()), "اكتب ملاحظة الترحيل", "a note is required")
    _log(conn, task_id, actor_id, "carried_over", task["status"], task["status"], note.strip())
    return Event(task_id, "carried_over", actor_id, task["status"], task["status"], note.strip())


def mark_done(conn: sqlite3.Connection, actor_id: int, task_id: int, note: str = "") -> Event:
    task = get_task(conn, task_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(task["status"] in (ASSIGNED, IN_PROGRESS), "المهمة ليست مفتوحة", "task is not open")
    if task["needs_review"]:
        db.update(conn, "tasks", task_id, status=REVIEW)
        _log(conn, task_id, actor_id, "done_pending_review", task["status"], REVIEW, note.strip() or None)
        return Event(task_id, "done_pending_review", actor_id, task["status"], REVIEW,
                     note.strip() or None, recipients=_managers_for(conn, task))
    db.update(conn, "tasks", task_id, status=DONE, closed_at=_now())
    _log(conn, task_id, actor_id, "done", task["status"], DONE, note.strip() or None)
    recipients = (task["created_by"],) + ((task["delegated_from"],) if task["delegated_from"] else ())
    return Event(task_id, "done", actor_id, task["status"], DONE, note.strip() or None, recipients=recipients)


# ----------------------------------------------------------------- handover (two approvals)
def request_handover(conn: sqlite3.Connection, actor_id: int, task_id: int,
                     to_user_id: int, reason: str) -> tuple[int, Event]:
    task = get_task(conn, task_id)
    target = get_user(conn, to_user_id)
    _require(task["assignee_id"] == actor_id, "المهمة ليست مسندة إليك", "not your task")
    _require(task["status"] == IN_PROGRESS, "طلب التسليم بعد قبول المهمة", "task must be in progress")
    _require(bool(reason.strip()), "سبب طلب التسليم مطلوب", "a reason is required")
    _require(to_user_id != actor_id, "اختر شخصاً آخر", "pick someone else")
    _require(bool(target["active"]), "الموظف غير نشط", "target is not active")

    handover_id = db.insert(conn, "handovers", task_id=task_id, from_user=actor_id,
                            to_user=to_user_id, reason=reason.strip(), status="pending", created_at=_now())
    db.update(conn, "tasks", task_id, status=HANDOVER)
    _log(conn, task_id, actor_id, "handover_requested", IN_PROGRESS, HANDOVER, reason.strip())
    return handover_id, Event(task_id, "handover_requested", actor_id, IN_PROGRESS, HANDOVER,
                              reason.strip(), recipients=_managers_for(conn, task))


def _pending_handover(conn: sqlite3.Connection, task_id: int) -> sqlite3.Row:
    row = db.one(
        conn,
        "SELECT * FROM handovers WHERE task_id = ? AND status IN ('pending','awaiting_employee') ORDER BY id DESC LIMIT 1",
        (task_id,),
    )
    if row is None:
        raise RuleError("لا يوجد طلب تسليم معلّق", "no pending handover")
    return row


def approve_handover(conn: sqlite3.Connection, actor_id: int, task_id: int) -> Event:
    """Step 1 of 2. The task only moves once the receiving employee accepts."""
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(_is_supervisor(conn, actor, task), "الموافقة للمدير فقط", "manager only")
    handover = _pending_handover(conn, task_id)
    _require(handover["status"] == "pending", "الطلب بانتظار قبول الموظف", "already approved")
    db.update(conn, "handovers", handover["id"], manager_decision="approved", status="awaiting_employee")
    _log(conn, task_id, actor_id, "handover_approved", HANDOVER, HANDOVER, None)
    return Event(task_id, "handover_approved", actor_id, HANDOVER, HANDOVER,
                 recipients=(handover["to_user"], handover["from_user"]))


def decline_handover(conn: sqlite3.Connection, actor_id: int, task_id: int, reason: str = "") -> Event:
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(_is_supervisor(conn, actor, task), "الرفض للمدير فقط", "manager only")
    handover = _pending_handover(conn, task_id)
    db.update(conn, "handovers", handover["id"], manager_decision="declined", status="declined")
    db.update(conn, "tasks", task_id, status=IN_PROGRESS)
    _log(conn, task_id, actor_id, "handover_declined", HANDOVER, IN_PROGRESS, reason.strip() or None)
    return Event(task_id, "handover_declined", actor_id, HANDOVER, IN_PROGRESS, reason.strip() or None,
                 recipients=(handover["from_user"],))


def accept_handover(conn: sqlite3.Connection, actor_id: int, task_id: int) -> Event:
    """Step 2 of 2 — only now does the task change hands."""
    task = get_task(conn, task_id)
    handover = _pending_handover(conn, task_id)
    _require(handover["to_user"] == actor_id, "الطلب ليس موجهاً إليك", "not your handover")
    _require(handover["status"] == "awaiting_employee", "الطلب بانتظار موافقة المدير", "manager has not approved yet")
    db.update(conn, "handovers", handover["id"], employee_decision="accepted", status="completed")
    db.update(conn, "tasks", task_id, status=IN_PROGRESS, assignee_id=actor_id, accepted_at=_now())
    _log(conn, task_id, actor_id, "handover_accepted", HANDOVER, IN_PROGRESS, None)
    return Event(task_id, "handover_accepted", actor_id, HANDOVER, IN_PROGRESS,
                 recipients=(handover["from_user"],) + _managers_for(conn, task))


def reject_handover(conn: sqlite3.Connection, actor_id: int, task_id: int, reason: str) -> Event:
    """The receiving employee says no: the task goes back to its owner and the manager is told."""
    task = get_task(conn, task_id)
    handover = _pending_handover(conn, task_id)
    _require(handover["to_user"] == actor_id, "الطلب ليس موجهاً إليك", "not your handover")
    _require(bool(reason.strip()), "سبب الرفض مطلوب", "a reason is required")
    db.update(conn, "handovers", handover["id"], employee_decision="rejected", status="declined")
    db.update(conn, "tasks", task_id, status=IN_PROGRESS)
    _log(conn, task_id, actor_id, "handover_rejected", HANDOVER, IN_PROGRESS, reason.strip())
    return Event(task_id, "handover_rejected", actor_id, HANDOVER, IN_PROGRESS, reason.strip(),
                 recipients=(handover["from_user"],) + _managers_for(conn, task))


# ----------------------------------------------------------------- review and admin
def review_approve(conn: sqlite3.Connection, actor_id: int, task_id: int, note: str = "") -> Event:
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(task["status"] == REVIEW, "المهمة ليست بانتظار المراجعة", "task is not in review")
    _require(_is_supervisor(conn, actor, task), "المراجعة للمدير فقط", "manager only")
    db.update(conn, "tasks", task_id, status=DONE, closed_at=_now())
    _log(conn, task_id, actor_id, "review_approved", REVIEW, DONE, note.strip() or None)
    return Event(task_id, "review_approved", actor_id, REVIEW, DONE, note.strip() or None,
                 recipients=(task["assignee_id"],))


def review_return(conn: sqlite3.Connection, actor_id: int, task_id: int, note: str) -> Event:
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(task["status"] == REVIEW, "المهمة ليست بانتظار المراجعة", "task is not in review")
    _require(_is_supervisor(conn, actor, task), "المراجعة للمدير فقط", "manager only")
    _require(bool(note.strip()), "اكتب ملاحظة الإعادة", "a note is required")
    db.update(conn, "tasks", task_id, status=IN_PROGRESS)
    _log(conn, task_id, actor_id, "review_returned", REVIEW, IN_PROGRESS, note.strip())
    return Event(task_id, "review_returned", actor_id, REVIEW, IN_PROGRESS, note.strip(),
                 recipients=(task["assignee_id"],))


def reassign(conn: sqlite3.Connection, actor_id: int, task_id: int, to_user_id: int, note: str = "") -> Event:
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    target = get_user(conn, to_user_id)
    _require(_is_supervisor(conn, actor, task), "إعادة الإسناد للمدير فقط", "manager only")
    _require(task["status"] in OPEN_STATUSES, "المهمة مغلقة", "task is closed")
    if actor["role"] == MANAGER:
        _require(target["role"] == EMPLOYEE and target["location_id"] == actor["location_id"],
                 "اختر موظفاً من فرعك", "pick an employee of your branch")
    db.update(conn, "tasks", task_id, status=ASSIGNED, assignee_id=to_user_id, accepted_at=None)
    _log(conn, task_id, actor_id, "reassigned", task["status"], ASSIGNED, note.strip() or None)
    return Event(task_id, "reassigned", actor_id, task["status"], ASSIGNED, note.strip() or None,
                 recipients=(to_user_id,) + ((task["assignee_id"],) if task["assignee_id"] else ()))


def cancel(conn: sqlite3.Connection, actor_id: int, task_id: int, reason: str) -> Event:
    """Tasks are never deleted — they are cancelled and the history stays."""
    actor, task = get_user(conn, actor_id), get_task(conn, task_id)
    _require(_is_supervisor(conn, actor, task), "الإلغاء للمدير فقط", "manager only")
    _require(task["status"] in OPEN_STATUSES, "المهمة مغلقة", "task is closed")
    _require(bool(reason.strip()), "سبب الإلغاء مطلوب", "a reason is required")
    db.update(conn, "tasks", task_id, status=CANCELLED, closed_at=_now())
    _log(conn, task_id, actor_id, "cancelled", task["status"], CANCELLED, reason.strip())
    recipients = (task["assignee_id"],) if task["assignee_id"] else ()
    return Event(task_id, "cancelled", actor_id, task["status"], CANCELLED, reason.strip(), recipients=recipients)


def add_comment(conn: sqlite3.Connection, actor_id: int, task_id: int, text: str) -> Event:
    task = get_task(conn, task_id)
    _require(bool(text.strip()), "التعليق فارغ", "empty comment")
    _log(conn, task_id, actor_id, "comment", task["status"], task["status"], text.strip())
    people = {task["assignee_id"], task["created_by"]}
    if task["delegated_from"]:
        people.add(task["delegated_from"])
    people.discard(actor_id)
    people.discard(None)
    return Event(task_id, "comment", actor_id, task["status"], task["status"], text.strip(),
                 recipients=tuple(sorted(p for p in people if p)))


# ----------------------------------------------------------------- reading
def open_tasks_for(conn: sqlite3.Connection, user_id: int) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT * FROM tasks
           WHERE assignee_id = ? AND status IN ('assigned','in_progress','handover','review')
           ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 ELSE 2 END, due_at""",
        (user_id,),
    )


def history(conn: sqlite3.Connection, task_id: int) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT e.*, u.name AS actor_name FROM task_events e
           LEFT JOIN users u ON u.id = e.actor_id
           WHERE e.task_id = ? ORDER BY e.id""",
        (task_id,),
    )


def visible_tasks(conn: sqlite3.Connection, actor_id: int) -> list[sqlite3.Row]:
    """What this account may see: the GM everything, a manager their branch, an employee their own."""
    actor = get_user(conn, actor_id)
    if actor["role"] == GM:
        return db.all_rows(conn, "SELECT * FROM tasks ORDER BY id DESC")
    if actor["role"] == MANAGER:
        return db.all_rows(conn, "SELECT * FROM tasks WHERE location_id = ? ORDER BY id DESC",
                           (actor["location_id"],))
    return db.all_rows(conn, "SELECT * FROM tasks WHERE assignee_id = ? ORDER BY id DESC", (actor_id,))
