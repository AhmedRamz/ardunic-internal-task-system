"""Every Arabic string the bot sends. Keeping them here means wording changes never touch logic."""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

TZ = ZoneInfo("Asia/Baghdad")

STATUS = {
    "suggested": "مقترحة",
    "assigned": "مسندة",
    "in_progress": "قيد التنفيذ",
    "rejected": "مرفوضة",
    "handover": "بانتظار التسليم",
    "review": "بانتظار المراجعة",
    "done": "منجزة",
    "cancelled": "ملغاة",
}
PRIORITY = {"normal": "عادية", "high": "عالية", "urgent": "عاجلة"}
PRIORITY_DOT = {"normal": "⚪️", "high": "🟠", "urgent": "🔴"}
ROLE = {"gm": "المدير العام", "manager": "مدير الفرع", "employee": "موظف"}

NOT_LINKED = (
    "حسابك غير مرتبط بنظام أردونك الداخلي.\n"
    "اطلب من المدير رمز الربط، ثم أرسل:\n<code>/start 123456</code>"
)
HELP = (
    "<b>أوامر البوت</b>\n"
    "/mytasks — مهامي المفتوحة\n"
    "/new — مهمة جديدة (للمدراء)\n"
    "/suggest — اقتراح مهمة على مديرك\n"
    "/task 124 — عرض مهمة برقمها\n"
    "/help — هذه القائمة"
)
LINK_DONE = (
    "أهلاً {name}!\nتم ربط حسابك بنظام أردونك الداخلي — فرع {location}.\n\n"
    "ستصلك المهام هنا مباشرة، ومعها:\n"
    "• موجز صباحي 9:00\n• تحديثات 10:00 و12:00 و2:00\n• إغلاق اليوم 4:30"
)
LINK_BAD = "الرمز غير صحيح أو منتهي. اطلب رمزاً جديداً من المدير."
ASK_TITLE = "عنوان المهمة؟"
ASK_ASSIGNEE = "اختر المسؤول:"
ASK_REASON_REJECT = "اكتب سبب رفض المهمة #{id}:\n<i>لن يُرسل الرفض بدون سبب</i>"
ASK_REASON_HANDOVER = "ما سبب طلب التسليم؟"
ASK_HANDOVER_TARGET = "لمن تريد تسليم المهمة؟"
ASK_DELEGATE_TARGET = "لمن تفوّض المهمة؟"
ASK_DELEGATE_NOTE = "ملاحظة للموظف؟ أرسل <code>-</code> للتجاوز."
ASK_RETURN_NOTE = "اكتب ملاحظة الإعادة:"
ASK_DUE_CUSTOM = "أرسل التاريخ والوقت بالشكل: <code>2026-10-15 17:00</code>"
NO_TASKS = "لا توجد مهام مفتوحة لديك. 👍"
CANCELLED_FLOW = "تم الإلغاء."


def now() -> datetime:
    return datetime.now(TZ)


def today_at(hour: int, minute: int = 0) -> str:
    return now().replace(hour=hour, minute=minute, second=0, microsecond=0).strftime("%Y-%m-%d %H:%M")


def tomorrow_at(hour: int, minute: int = 0) -> str:
    return (now() + timedelta(days=1)).replace(
        hour=hour, minute=minute, second=0, microsecond=0
    ).strftime("%Y-%m-%d %H:%M")


def due_label(due_at: str | None) -> str:
    if not due_at:
        return "بدون موعد"
    try:
        value = datetime.strptime(due_at, "%Y-%m-%d %H:%M").replace(tzinfo=TZ)
    except ValueError:
        return due_at
    day = value.strftime("%Y-%m-%d")
    clock = value.strftime("%I:%M").lstrip("0") + (" م" if value.hour >= 12 else " ص")
    if day == now().strftime("%Y-%m-%d"):
        return f"اليوم {clock}"
    if day == (now() + timedelta(days=1)).strftime("%Y-%m-%d"):
        return f"غداً {clock}"
    return f"{day} · {clock}"


def task_card(task: sqlite3.Row, *, creator: str = "", assignee: str = "") -> str:
    lines = [f"<b>مهمة #{task['id']}</b>", task["title"]]
    if task["description"]:
        lines.append(f"\n{task['description']}")
    lines.append("")
    if creator:
        lines.append(f"من: {creator}")
    if assignee:
        lines.append(f"المسؤول: {assignee}")
    lines.append(f"الحالة: {STATUS[task['status']]}")
    lines.append(f"الموعد: {due_label(task['due_at'])}")
    lines.append(f"الأولوية: {PRIORITY_DOT[task['priority']]} {PRIORITY[task['priority']]}")
    if task["needs_review"]:
        lines.append("تحتاج مراجعة قبل الإغلاق")
    if task["allow_delegation"]:
        lines.append("<i>يسمح بتفويضها لموظف</i>")
    return "\n".join(lines)


def task_line(task: sqlite3.Row) -> str:
    return (f"{PRIORITY_DOT[task['priority']]} <b>#{task['id']}</b> {task['title']}\n"
            f"    <i>{STATUS[task['status']]} · {due_label(task['due_at'])}</i>")


def my_tasks(rows: list[sqlite3.Row], name: str) -> str:
    if not rows:
        return NO_TASKS
    body = "\n".join(task_line(r) for r in rows)
    return f"<b>مهام {name} المفتوحة ({len(rows)})</b>\n{body}"


# ------------------------------------------------------------- notifications
EVENT_TEXT = {
    "created": "📋 <b>مهمة جديدة #{id}</b>\n{title}\nمن: {actor}\nالموعد: {due}\nالأولوية: {priority}",
    "suggested": "💡 <b>اقتراح مهمة #{id}</b>\n{title}\nمن: {actor}",
    "suggestion_approved": "✅ تمت الموافقة على الاقتراح #{id} وأصبح مهمة.\n{title}",
    "suggestion_declined": "❌ رُفض الاقتراح #{id}.\nالسبب: {note}",
    "accepted": "✅ قبل {actor} المهمة #{id}.\n{title}",
    "rejected": "❌ رفض {actor} المهمة #{id}.\nالسبب: {note}",
    "delegated": "🔀 <b>مهمة مُفوَّضة #{id}</b>\n{title}\nفوّضها {actor}\nالموعد: {due}",
    "update_blocked": "⚠️ المهمة #{id} متوقفة — {actor}.\nالسبب: {note}",
    "done": "✔️ أنجز {actor} المهمة #{id}.\n{title}",
    "done_pending_review": "🔎 <b>بانتظار مراجعتك</b>\nالمهمة #{id} — {title}\nأنجزها {actor}",
    "review_approved": "✅ اعتُمدت المهمة #{id} وأُغلقت. شكراً!",
    "review_returned": "↩️ أُعيدت المهمة #{id} إليك.\nالملاحظة: {note}",
    "handover_requested": "🔄 <b>طلب تسليم المهمة #{id}</b>\n{title}\nمن: {actor}\nالسبب: {note}",
    "handover_approved": "🔄 وافق المدير على تسليم المهمة #{id}. بانتظار قبول الموظف.",
    "handover_declined": "🔄 رفض المدير طلب تسليم المهمة #{id}. تبقى لديك.",
    "handover_accepted": "🔄 قبل {actor} المهمة #{id} وانتقلت إليه.",
    "handover_rejected": "🔄 رفض {actor} استلام المهمة #{id}.\nالسبب: {note}",
    "reassigned": "📋 أُعيد إسناد المهمة #{id}.\n{title}",
    "cancelled": "🚫 أُلغيت المهمة #{id}.\nالسبب: {note}",
    "comment": "💬 تعليق على المهمة #{id} من {actor}:\n{note}",
    "carried_over": "📅 رُحّلت المهمة #{id} لغد.\n{note}",
}
