-- Ardunic Internal Management System — schema (V1)
-- SQLite for the Jadriya pilot; the same DDL ports to PostgreSQL with minor type changes.
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS locations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS users (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    name               TEXT    NOT NULL,
    role               TEXT    NOT NULL CHECK (role IN ('gm', 'manager', 'employee')),
    location_id        INTEGER REFERENCES locations(id),
    manager_id         INTEGER REFERENCES users(id),
    telegram_id        INTEGER UNIQUE,
    telegram_username  TEXT,
    link_code          TEXT,
    link_code_expires  TEXT,
    password_hash      TEXT,              -- managers only (dashboard login)
    last_login         TEXT,
    active             INTEGER NOT NULL DEFAULT 1,
    created_at         TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_users_location ON users(location_id);

CREATE TABLE IF NOT EXISTS tasks (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT    NOT NULL,
    description      TEXT    NOT NULL DEFAULT '',
    status           TEXT    NOT NULL CHECK (status IN
                        ('suggested','assigned','in_progress','rejected','handover','review','done','cancelled')),
    priority         TEXT    NOT NULL DEFAULT 'normal' CHECK (priority IN ('normal','high','urgent')),
    due_at           TEXT,
    needs_review     INTEGER NOT NULL DEFAULT 0,
    allow_delegation INTEGER NOT NULL DEFAULT 0,
    assignee_id      INTEGER REFERENCES users(id),
    delegated_from   INTEGER REFERENCES users(id),   -- manager who passed it to an employee
    created_by       INTEGER NOT NULL REFERENCES users(id),
    location_id      INTEGER REFERENCES locations(id),
    source           TEXT    NOT NULL DEFAULT 'dashboard'
                        CHECK (source IN ('dashboard','bot','group','suggestion')),
    accepted_at      TEXT,
    created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
    closed_at        TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assignee_id, status);
CREATE INDEX IF NOT EXISTS idx_tasks_status   ON tasks(status, location_id);

-- Full history. Nothing is ever overwritten or deleted.
CREATE TABLE IF NOT EXISTS task_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id     INTEGER NOT NULL REFERENCES tasks(id),
    actor_id    INTEGER REFERENCES users(id),
    action      TEXT    NOT NULL,
    from_status TEXT,
    to_status   TEXT,
    note        TEXT,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_task ON task_events(task_id, id);

CREATE TABLE IF NOT EXISTS handovers (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id           INTEGER NOT NULL REFERENCES tasks(id),
    from_user         INTEGER NOT NULL REFERENCES users(id),
    to_user           INTEGER NOT NULL REFERENCES users(id),
    reason            TEXT    NOT NULL,
    manager_decision  TEXT    CHECK (manager_decision IN ('approved','declined')),
    employee_decision TEXT    CHECK (employee_decision IN ('accepted','rejected')),
    status            TEXT    NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','awaiting_employee','completed','declined')),
    created_at        TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS attachments (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id          INTEGER REFERENCES tasks(id),
    routine_log_id   INTEGER,
    telegram_file_id TEXT NOT NULL,
    file_name        TEXT,
    uploaded_by      INTEGER REFERENCES users(id),
    created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Scheduled check-in times, editable from Settings.
CREATE TABLE IF NOT EXISTS checkin_slots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id INTEGER REFERENCES locations(id),
    kind        TEXT NOT NULL CHECK (kind IN ('brief','update','closeout','report')),
    time        TEXT NOT NULL,              -- 'HH:MM', Asia/Baghdad
    active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS checkins (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    task_id    INTEGER REFERENCES tasks(id),
    slot_id    INTEGER REFERENCES checkin_slots(id),
    kind       TEXT NOT NULL,
    date       TEXT NOT NULL,
    answer     TEXT,
    note       TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ------------------------------------------------------------------ routines
CREATE TABLE IF NOT EXISTS routines (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    code         TEXT    NOT NULL,          -- R1..R7
    name         TEXT    NOT NULL,
    instructions TEXT    NOT NULL DEFAULT '',
    days         TEXT    NOT NULL DEFAULT 'sat,sun,mon,tue,wed,thu',
    count_label  TEXT,
    location_id  INTEGER REFERENCES locations(id),
    active       INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS routine_owners (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    routine_id INTEGER NOT NULL REFERENCES routines(id),
    user_id    INTEGER NOT NULL REFERENCES users(id),
    role       TEXT    NOT NULL DEFAULT 'owner' CHECK (role IN ('owner','backup'))
);

-- A routine with no rows here runs as one whole-day routine.
CREATE TABLE IF NOT EXISTS routine_periods (
    id                           INTEGER PRIMARY KEY AUTOINCREMENT,
    routine_id                   INTEGER NOT NULL REFERENCES routines(id),
    name                         TEXT    NOT NULL,     -- صباحية / مسائية / ليلية / ف1..ف4
    days                         TEXT    NOT NULL DEFAULT 'sat,sun,mon,tue,wed,thu',
    start_time                   TEXT    NOT NULL,     -- 'HH:MM'
    end_time                     TEXT    NOT NULL,
    checkin_minutes_before_end   INTEGER NOT NULL DEFAULT 15
);

-- The weekly board: one person per period per weekday. No backup row.
CREATE TABLE IF NOT EXISTS period_schedule (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id  INTEGER NOT NULL REFERENCES routine_periods(id),
    weekday    TEXT    NOT NULL CHECK (weekday IN ('sat','sun','mon','tue','wed','thu','fri')),
    user_id    INTEGER REFERENCES users(id),
    UNIQUE (period_id, weekday)
);

-- Who really holds a period on one date; the board stays untouched.
CREATE TABLE IF NOT EXISTS period_overrides (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id        INTEGER NOT NULL REFERENCES routine_periods(id),
    date             TEXT    NOT NULL,
    user_id          INTEGER REFERENCES users(id),
    reason           TEXT    NOT NULL CHECK (reason IN ('swap','leave','absence','manager')),
    swap_request_id  INTEGER,
    created_by       INTEGER REFERENCES users(id),
    created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
    UNIQUE (period_id, date)
);

CREATE TABLE IF NOT EXISTS swap_requests (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    period_id          INTEGER NOT NULL REFERENCES routine_periods(id),
    date               TEXT    NOT NULL,
    from_user          INTEGER NOT NULL REFERENCES users(id),
    to_user            INTEGER NOT NULL REFERENCES users(id),
    kind               TEXT    NOT NULL CHECK (kind IN ('swap','cover')),
    return_period_id   INTEGER REFERENCES routine_periods(id),
    return_date        TEXT,
    reason             TEXT,
    colleague_decision TEXT    CHECK (colleague_decision IN ('accepted','declined')),
    manager_decision   TEXT    CHECK (manager_decision IN ('approved','declined')),
    status             TEXT    NOT NULL DEFAULT 'awaiting_colleague'
                        CHECK (status IN ('awaiting_colleague','awaiting_manager','approved','declined','expired')),
    created_at         TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS routine_logs (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    routine_id    INTEGER NOT NULL REFERENCES routines(id),
    period_id     INTEGER REFERENCES routine_periods(id),
    user_id       INTEGER NOT NULL REFERENCES users(id),
    date          TEXT    NOT NULL,
    result        TEXT    CHECK (result IN ('done','partly','not_done','nothing_today')),
    count         INTEGER,
    note          TEXT,
    covering_for  INTEGER REFERENCES users(id),
    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_routine_logs_date ON routine_logs(date, routine_id);

CREATE TABLE IF NOT EXISTS leaves (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id),
    from_date  TEXT    NOT NULL,
    to_date    TEXT    NOT NULL,
    kind       TEXT    NOT NULL DEFAULT 'leave' CHECK (kind IN ('leave','absent')),
    created_by INTEGER REFERENCES users(id),
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS coverages (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    leave_id        INTEGER NOT NULL REFERENCES leaves(id),
    routine_id      INTEGER REFERENCES routines(id),
    period_id       INTEGER REFERENCES routine_periods(id),
    cover_user_id   INTEGER NOT NULL REFERENCES users(id),
    acknowledged_at TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telegram_groups (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id    INTEGER NOT NULL UNIQUE,
    title      TEXT,
    location_id INTEGER REFERENCES locations(id),
    active     INTEGER NOT NULL DEFAULT 1
);
