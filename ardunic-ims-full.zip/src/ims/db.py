"""SQLite access layer. One connection per process; WAL keeps the bot and the web app happy."""
from __future__ import annotations

import sqlite3
from pathlib import Path

SCHEMA = Path(__file__).resolve().parents[2] / "schema.sql"


BUSY_TIMEOUT_MS = 5000


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, isolation_level=None, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    # Two processes write to this file: the dashboard and the bot (its scheduler ticks
    # every minute and its outbox every two seconds). Without a busy timeout SQLite
    # gives up the instant the other one holds the write lock, which the browser saw
    # as a random Internal Server Error. Five seconds is far longer than any write here.
    conn.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}")
    return conn


# Columns added after a table first shipped. CREATE TABLE IF NOT EXISTS cannot add
# them to an existing database, so each one is applied by hand, additively.
ADDED_COLUMNS: tuple[tuple[str, str, str], ...] = (
    ("outbox", "keyboard", "TEXT"),
    ("routines", "checkin_time", "TEXT"),        # when a routine with no periods is asked
    ("leaves", "from_time", "TEXT"),             # set on a part-day leave ("إجازة ساعتين")
    ("leaves", "to_time", "TEXT"),
    ("users", "weekly_day_off", "TEXT"),   # the fixed day agreed with the GM
)


def migrate(conn: sqlite3.Connection) -> None:
    """Apply schema.sql, then any column added since. Safe to re-run; nothing is dropped."""
    conn.executescript(SCHEMA.read_text(encoding="utf-8"))
    for table, column, decl in ADDED_COLUMNS:
        existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
        if existing and column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")


def one(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> sqlite3.Row | None:
    return conn.execute(sql, params).fetchone()


def all_rows(conn: sqlite3.Connection, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
    return conn.execute(sql, params).fetchall()


def insert(conn: sqlite3.Connection, table: str, **values) -> int:
    cols = ", ".join(values)
    marks = ", ".join("?" for _ in values)
    cur = conn.execute(f"INSERT INTO {table} ({cols}) VALUES ({marks})", tuple(values.values()))
    return int(cur.lastrowid)


def update(conn: sqlite3.Connection, table: str, row_id: int, **values) -> None:
    sets = ", ".join(f"{k} = ?" for k in values)
    conn.execute(f"UPDATE {table} SET {sets} WHERE id = ?", (*values.values(), row_id))
