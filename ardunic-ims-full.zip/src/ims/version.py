"""Which build is running.

The VERSION file is written into the zip when a release is packaged. It is the
answer to "did the update actually land?" — it shows in the dashboard sidebar,
at /health, and update.sh prints it before and after replacing the code.
"""
from __future__ import annotations

from pathlib import Path

VERSION_FILE = Path(__file__).resolve().parents[2] / "VERSION"
UNKNOWN = "نسخة غير مُعلَّمة"


def current() -> str:
    try:
        value = VERSION_FILE.read_text(encoding="utf-8").strip()
    except OSError:
        return UNKNOWN
    return value.splitlines()[0].strip() if value else UNKNOWN


if __name__ == "__main__":
    print(current())
