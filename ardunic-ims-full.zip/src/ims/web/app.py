"""The dashboard: FastAPI + server-rendered Arabic pages.

Accounts are for the GM and the branch managers. The GM sees every branch;
a manager sees their own. Employees have no login — they work from the bot.

    PYTHONPATH=src uvicorn ims.web.app:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import csv
import io
import logging
import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path
from urllib.parse import urlencode

from fastapi import Depends, FastAPI, Form, HTTPException, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from .. import db, texts, version
from ..config import Config
from ..core import auth
from ..core import cleanup
from ..core import feed
from ..core import ledger
from ..core import notify
from ..core import periods as P
from ..core import recurring as R
from ..core import schedule
from ..core import tasks as T

log = logging.getLogger(__name__)
BASE = Path(__file__).resolve().parent
config = Config.load()
conn = db.connect(config.db_path)
db.migrate(conn)

app = FastAPI(title="Ardunic Internal Management System", docs_url=None, redoc_url=None)
app.add_middleware(SessionMiddleware, secret_key=auth.session_secret(), session_cookie="ims_session",
                   https_only=False, max_age=60 * 60 * 24 * 14)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

templates = Jinja2Templates(directory=str(BASE / "templates"))
templates.env.globals.update(
    STATUS=texts.STATUS, PRIORITY=texts.PRIORITY, ROLE=texts.ROLE,
    RESULTS=P.RESULTS, TASK_KINDS=R.TASK_KINDS, day_number=R.day_number,
    due_label=texts.due_label,
)

# The board carries today's work. منجزة holds what was finished since the last
# sweep (23:59 by default) and empties itself then; the ledger keeps it for good.
COLUMNS = [
    ("suggested", "مقترحة", "#5B3E96"),
    ("assigned", "مسندة", "#1D4F91"),
    ("in_progress", "قيد التنفيذ", "#0E6B63"),
    ("handover", "بانتظار التسليم", "#8F4507"),
    ("review", "بانتظار المراجعة", "#6B6558"),
    ("done", "منجزة", "#1E6B3A"),
]
BUILD = version.current()     # shown in the sidebar, so "did it update?" has an answer
CONFIRM_WORD = "حذف"          # typed by hand before anything is really deleted
WEEKDAYS = [("sat", "السبت"), ("sun", "الأحد"), ("mon", "الاثنين"), ("tue", "الثلاثاء"),
            ("wed", "الأربعاء"), ("thu", "الخميس"), ("fri", "الجمعة")]


# ----------------------------------------------------------------- auth plumbing
def current_user(request: Request) -> sqlite3.Row:
    user_id = request.session.get("user_id")
    user = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,)) if user_id else None
    if user is None:
        raise HTTPException(status_code=303, headers={"Location": "/login"})
    return user


@app.exception_handler(HTTPException)
async def redirect_handler(request: Request, exc: HTTPException):
    if exc.status_code == 303 and exc.headers and "Location" in exc.headers:
        return RedirectResponse(exc.headers["Location"], status_code=303)
    return HTMLResponse(_problem_page(str(exc.detail), back=True), status_code=exc.status_code)


@app.exception_handler(Exception)
async def crash_handler(request: Request, exc: Exception):
    """Anything unexpected: log the whole traceback, show the person something readable."""
    log.exception("%s %s failed", request.method, request.url.path)
    return HTMLResponse(_problem_page(
        "حدث خطأ غير متوقع ولم يُحفظ هذا الإجراء.<br>"
        f"<small dir='ltr' style='color:#8A8577'>{type(exc).__name__}: {exc}</small><br>"
        "التفاصيل الكاملة في سجل الخادم: <code dir='ltr'>journalctl -u ims-web -n 50</code>",
        back=True), status_code=500)


def _problem_page(message: str, *, back: bool = False) -> str:
    link = '<p><a href="/">العودة إلى لوحة المهام</a></p>' if back else ""
    return f"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
<title>خطأ — نظام أردونك الداخلي</title><link rel="stylesheet" href="/static/app.css"></head>
<body><div class="login-wrap"><div class="login-card" style="text-align:center">
<span class="logo">أ</span><p style="line-height:1.9">{message}</p>{link}</div></div></body></html>"""


def page(request: Request, name: str, user: sqlite3.Row, **context) -> HTMLResponse:
    location = db.one(conn, "SELECT name FROM locations WHERE id = ?", (user["location_id"],))
    response = templates.TemplateResponse(
        request, name,
        {"user": user, "location": location["name"] if location else "", "today": date.today().isoformat(),
         "is_gm": user["role"] == "gm", "unread_total": feed.unread_total(conn, user),
         "build": BUILD, "refresh_seconds": refresh_seconds(), **context},
    )
    # the browser must never show yesterday's dashboard after an update
    response.headers["Cache-Control"] = "no-store, must-revalidate"
    return response


def refresh_seconds() -> int:
    """How often a page reloads itself. 0 switches it off."""
    row = db.one(conn, "SELECT value FROM settings WHERE key = 'refresh_seconds'")
    try:
        return max(0, min(int(row["value"]), 3600)) if row else 60
    except (TypeError, ValueError):
        return 60


def branch_filter(user: sqlite3.Row) -> tuple[str, tuple]:
    if user["role"] == "gm":
        return "1=1", ()
    return "location_id = ?", (user["location_id"],)


def people(user: sqlite3.Row, roles=("employee",)) -> list[sqlite3.Row]:
    marks = ",".join("?" for _ in roles)
    where, params = branch_filter(user)
    return db.all_rows(
        conn,
        f"SELECT * FROM users WHERE active = 1 AND role IN ({marks}) AND {where} ORDER BY role, name",
        (*roles, *params),
    )


# ----------------------------------------------------------------- login
@app.get("/login", response_class=HTMLResponse)
def login_form(request: Request, error: str = ""):
    return templates.TemplateResponse(request, "login.html", {"error": error, "build": BUILD})


@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    user = auth.authenticate(conn, username, password)
    if user is None:
        return RedirectResponse("/login?error=1", status_code=303)
    request.session["user_id"] = user["id"]
    return RedirectResponse("/", status_code=303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


# ----------------------------------------------------------------- board
@app.get("/", response_class=HTMLResponse)
def board(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    now = texts.now()
    cutoff = ledger.board_cutoff(conn, now)          # منجزة shows what came after this
    rows = db.all_rows(
        conn,
        f"""SELECT t.*, u.name AS assignee_name, c.name AS creator_name,
                   (SELECT w.name FROM handovers h JOIN users w ON w.id = h.to_user
                     WHERE h.task_id = t.id AND h.status IN ('pending','awaiting_employee')
                     ORDER BY h.id DESC LIMIT 1) AS handover_to,
                   (SELECT h.status FROM handovers h
                     WHERE h.task_id = t.id AND h.status IN ('pending','awaiting_employee')
                     ORDER BY h.id DESC LIMIT 1) AS handover_stage
            FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
                         LEFT JOIN users c ON c.id = t.created_by
            WHERE {where} AND (t.status NOT IN ('done','cancelled')
                               OR (t.status = 'done' AND t.closed_at >= ?))
            ORDER BY t.id DESC""",
        (*params, cutoff.strftime("%Y-%m-%d %H:%M:%S")),
    )
    columns = []
    for key, title, colour in COLUMNS:
        cards = [r for r in rows if r["status"] == key or (key == "assigned" and r["status"] == "rejected")]
        columns.append({"key": key, "title": title, "colour": colour, "cards": cards})
    swept = cutoff + timedelta(days=1)
    return page(request, "board.html", user, columns=columns,
                closed_today=len([c for c in columns[-1]["cards"]]),
                sweep_at=swept.strftime("%H:%M"),
                unread=feed.unread_by_task(conn, user["id"]),
                now=now.strftime("%Y-%m-%d · %H:%M"))


# ----------------------------------------------------------------- the ledger
def _ledger_filters(request: Request, user: sqlite3.Row) -> dict:
    """Read the filter bar off the query string, with sane defaults."""
    today = texts.now().date()
    quick = request.query_params.get("range", "")
    spans = ledger.ranges(today)
    if quick in spans:
        start, end = spans[quick]
    else:
        def parse(name: str, fallback: date) -> date:
            try:
                return date.fromisoformat(request.query_params.get(name, ""))
            except ValueError:
                return fallback
        start = parse("start", ledger.month_start(today))
        end = parse("end", today)
    if end < start:
        start, end = end, start
    anchor = request.query_params.get("anchor", "created")
    page = max(0, int(request.query_params.get("page", "0") or 0))
    return {"start": start, "end": end,
            "anchor": anchor if anchor in ledger.ANCHORS else "created",
            "status": request.query_params.get("status", "all"),
            "assignee": int(request.query_params.get("assignee", "0") or 0),
            "text": request.query_params.get("text", ""), "page": page}


@app.get("/ledger", response_class=HTMLResponse)
def ledger_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    chosen = _ledger_filters(request, user)
    page_no = chosen.pop("page")
    result = ledger.query(conn, user, **chosen, offset=page_no * ledger.PAGE_SIZE)
    query = {**chosen, "start": chosen["start"].isoformat(), "end": chosen["end"].isoformat()}
    return page(request, "ledger.html", user, **result, filters=chosen, page_no=page_no,
                query=urlencode(query),                       # same filters, next page
                without_dates=urlencode({k: v for k, v in query.items()
                                         if k not in ("start", "end")}),
                anchors=ledger.ANCHORS, staff=people(user, ("employee", "manager")),
                statuses={"all": "الكل", "open": "المفتوحة", "done": "المنجزة",
                          "cancelled": "الملغاة"},
                quick={"today": "اليوم", "week": "هذا الأسبوع", "month": "هذا الشهر",
                       "prev_month": "الشهر الماضي"})


@app.get("/ledger.csv")
def ledger_csv(request: Request, user: sqlite3.Row = Depends(current_user)):
    """The same rows as a file Excel opens with the Arabic intact."""
    chosen = _ledger_filters(request, user)
    chosen.pop("page")
    result = ledger.query(conn, user, **chosen, limit=5000, offset=0)
    buffer = io.StringIO()
    csv.writer(buffer).writerows(ledger.csv_rows(result))
    name = f"ardunic-tasks-{chosen['start']}-{chosen['end']}.csv"
    return Response("﻿" + buffer.getvalue(),            # the BOM is what Excel reads
                    media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.get("/tasks/new", response_class=HTMLResponse)
def new_task_form(request: Request, user: sqlite3.Row = Depends(current_user)):
    roles = ("employee", "manager") if user["role"] == "gm" else ("employee",)
    return page(request, "new_task.html", user, candidates=people(user, roles),
                default_due=texts.today_at(17))


@app.post("/tasks/new")
def new_task(request: Request, user: sqlite3.Row = Depends(current_user),
             title: str = Form(...), description: str = Form(""), assignee_id: int = Form(...),
             due_at: str = Form(""), priority: str = Form("normal"),
             needs_review: str = Form(""), allow_delegation: str = Form("")):
    try:
        task_id, event = T.create_task(conn, user["id"], title, assignee_id, description=description,
                                       due_at=due_at or None, priority=priority,
                                       needs_review=bool(needs_review),
                                       allow_delegation=bool(allow_delegation))
        notify.queue(conn, event)            # the assignee hears about it on Telegram
    except T.RuleError as exc:
        return page(request, "new_task.html", user, candidates=people(user, ("employee", "manager")),
                    default_due=texts.today_at(17), error=exc.ar)
    return RedirectResponse(f"/tasks/{task_id}", status_code=303)


@app.get("/tasks/{task_id}", response_class=HTMLResponse)
def task_detail(request: Request, task_id: int, user: sqlite3.Row = Depends(current_user), error: str = ""):
    task = db.one(conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))
    if task is None or (user["role"] != "gm" and task["location_id"] != user["location_id"]):
        raise HTTPException(404, "المهمة غير موجودة")
    names = {r["id"]: r["name"] for r in db.all_rows(conn, "SELECT id, name FROM users")}
    handover = db.one(
        conn,
        """SELECT * FROM handovers WHERE task_id = ? AND status IN ('pending','awaiting_employee')
           ORDER BY id DESC LIMIT 1""",
        (task_id,),
    )
    template = db.one(conn, "SELECT * FROM routines WHERE id = ?", (task["template_id"],)) \
        if task["template_id"] else None
    feed.mark_read(conn, user["id"], task_id)        # everything on this page counts as seen
    return page(request, "task.html", user, task=task, names=names, handover=handover,
                template=template,
                events=T.history(conn, task_id), candidates=people(user, ("employee", "manager")),
                labels=feed.FEED_ACTIONS, error=error)


@app.post("/tasks/{task_id}/action")
def task_action(request: Request, task_id: int, user: sqlite3.Row = Depends(current_user),
                action: str = Form(...), note: str = Form(""), target_id: int = Form(0)):
    handlers = {
        "review_approve": lambda: T.review_approve(conn, user["id"], task_id, note),
        "review_return": lambda: T.review_return(conn, user["id"], task_id, note),
        "reassign": lambda: T.reassign(conn, user["id"], task_id, target_id, note),
        "cancel": lambda: T.cancel(conn, user["id"], task_id, note),
        "comment": lambda: T.add_comment(conn, user["id"], task_id, note),
        "approve_handover": lambda: T.approve_handover(conn, user["id"], task_id),
        "decline_handover": lambda: T.decline_handover(conn, user["id"], task_id, note),
        "approve_suggestion": lambda: T.approve_suggestion(conn, user["id"], task_id,
                                                           assignee_id=target_id),
        "decline_suggestion": lambda: T.decline_suggestion(conn, user["id"], task_id, note),
        "accept": lambda: T.accept(conn, user["id"], task_id),
        "done": lambda: T.mark_done(conn, user["id"], task_id, note),
        "delegate": lambda: T.delegate(conn, user["id"], task_id, target_id, note),
    }
    if action not in handlers:
        return RedirectResponse(f"/tasks/{task_id}", status_code=303)
    try:
        event = handlers[action]()
        notify.queue(conn, event)            # everyone concerned hears about it on Telegram
    except T.RuleError as exc:
        return RedirectResponse(f"/tasks/{task_id}?error={exc.ar}", status_code=303)
    return RedirectResponse(f"/tasks/{task_id}", status_code=303)


# ----------------------------------------------------------------- today
@app.get("/today", response_class=HTMLResponse)
def today_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    today = date.today().isoformat()
    staff = people(user, ("employee",))
    stats = {
        "open": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND status IN "
                             "('assigned','in_progress','handover','review')", params)["c"],
        "done": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND status = 'done' "
                             "AND date(closed_at) = date('now')", params)["c"],
        "overdue": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND due_at < datetime('now') "
                                "AND status IN ('assigned','in_progress')", params)["c"],
        "unaccepted": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND status = 'assigned'",
                             params)["c"],
    }
    now = texts.now()
    rows = []
    for person in staff:
        answers = db.all_rows(
            conn,
            "SELECT * FROM checkins WHERE user_id = ? AND date = ? ORDER BY id",
            (person["id"], today),
        )
        duties = P.duties_today(conn, person["id"], now)
        last = db.one(
            conn,
            """SELECT e.note FROM task_events e JOIN tasks t ON t.id = e.task_id
               WHERE e.actor_id = ? AND e.note IS NOT NULL ORDER BY e.id DESC LIMIT 1""",
            (person["id"],),
        )
        rows.append({"person": person, "answers": answers, "duties": duties,
                     "off": P.on_leave(conn, person["id"], now.date()) is not None,
                     "last_note": last["note"] if last else "—"})
    attention = db.all_rows(
        conn,
        f"""SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
            WHERE {where} AND (t.status IN ('rejected','handover','review','suggested')
                  OR (t.due_at < datetime('now') AND t.status IN ('assigned','in_progress')))
            ORDER BY t.id DESC LIMIT 12""",
        params,
    )
    scope = None if user["role"] == "gm" else user["location_id"]
    return page(request, "today.html", user, stats=stats, rows=rows, attention=attention,
                board=P.day_board(conn, now.date(), scope), duty_ar=P.DUTY_STATE_AR,
                reasons={"swap": "تغطية", "leave": "بدل إجازة", "absence": "بدل غياب",
                         "manager": "تعيين المدير"},
                checkin_ar={"brief": "الموجز", "update": "تحديث", "closeout": "الإغلاق",
                            "report": "التقرير"},
                answer_ar={"done": "تمت", "working": "مستمرة", "blocked": "متوقفة",
                           "carried_over": "مُرحّلة"})


# ----------------------------------------------------------------- routines and periods
@app.get("/routines", response_class=HTMLResponse)
def routines_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    routines = db.all_rows(conn, f"SELECT * FROM routines WHERE {where} AND active = 1 ORDER BY code", params)
    today = texts.now().date().isoformat()
    data = []
    for routine in routines:
        owners = db.all_rows(
            conn,
            """SELECT u.name, ro.role FROM routine_owners ro JOIN users u ON u.id = ro.user_id
               WHERE ro.routine_id = ?""",
            (routine["id"],),
        )
        periods = db.all_rows(conn, "SELECT * FROM routine_periods WHERE routine_id = ? ORDER BY start_time",
                              (routine["id"],))
        logs = db.all_rows(
            conn,
            """SELECT l.*, u.name FROM routine_logs l JOIN users u ON u.id = l.user_id
               WHERE l.routine_id = ? AND l.date = ?""",
            (routine["id"], today),
        )
        kind = R.kind_of(routine)
        item = {"routine": routine, "kind": kind, "owners": owners, "periods": periods,
                "logs": logs, "checkin": P.checkin_time(routine)}
        if kind == R.PERIODIC:
            item.update({"rota": P.has_rota(conn, routine["id"]),
                         "today_people": [] if periods else
                         P.on_duty(conn, routine, texts.now().date())})
        elif kind == R.ROUTINE:
            item.update({"days": R.expected_days(routine),
                         "open_runs": R.open_runs(conn, routine["id"])})
        else:
            owner = db.one(conn, "SELECT name FROM users WHERE id = ?",
                           (routine["default_assignee"],)) if routine["default_assignee"] else None
            item.update({"cycle": R.cycle_label(routine), "owner_name": owner["name"] if owner else "",
                         "next_due": R.next_due(routine, texts.now().date()),
                         "recent": R.history(conn, routine["id"], 3)})
        data.append(item)
    retired = db.all_rows(conn, f"SELECT * FROM routines WHERE {where} AND active = 0 ORDER BY code",
                          params)
    return page(request, "routines.html", user, retired=retired, weekdays=WEEKDAYS,
                groups={kind: [i for i in data if i["kind"] == kind] for kind in R.KINDS},
                kinds=R.KINDS, hints=R.KIND_HINT, cycles=R.CYCLES,
                staff=people(user, ("employee", "manager")), all_weekdays=P.ALL_WEEKDAYS,
                weekday_ar=P.WEEKDAY_AR, error=request.query_params.get("error", ""))


@app.post("/routines")
async def routine_create(request: Request, user: sqlite3.Row = Depends(current_user)):
    form = await request.form()
    kind = str(form.get("kind", R.PERIODIC))
    kind = kind if kind in R.KINDS else R.PERIODIC
    days = form.getlist("days") or list(P.ALL_WEEKDAYS[:6])      # the two new kinds need no week
    try:
        routine_id = P.create_routine(
            conn, user, code=str(form.get("code", "")), name=str(form.get("name", "")),
            days=days, instructions=str(form.get("instructions", "")),
            count_label=str(form.get("count_label", "")), checkin=str(form.get("checkin", "")))
        _save_kind_fields(routine_id, kind, form)
    except (P.RuleError, ValueError) as exc:
        reason = exc.ar if isinstance(exc, P.RuleError) else "قيمة غير صحيحة"
        return RedirectResponse(f"/routines?error={reason}", status_code=303)
    return RedirectResponse(f"/routines/{routine_id}", status_code=303)


def _save_kind_fields(routine_id: int, kind: str, form) -> None:
    """The handful of fields that only one kind of template uses."""
    fields = {"kind": kind}
    if kind == R.ROUTINE:
        fields["expected_days"] = max(1, min(int(str(form.get("expected_days") or 1)), R.MAX_DAYS))
    if kind == R.SCHEDULED:
        cycle = str(form.get("cycle", "monthly"))
        fields["cycle"] = cycle if cycle in R.CYCLES else "monthly"
        raw = int(str(form.get("cycle_day") or 1))
        fields["cycle_day"] = max(0, min(raw, 6)) if fields["cycle"] == "weekly" else max(1, min(raw, 28))
        fields["expected_days"] = max(1, min(int(str(form.get("expected_days") or 1)), R.MAX_DAYS))
    if kind in (R.ROUTINE, R.SCHEDULED):
        fields["default_assignee"] = int(str(form.get("default_assignee") or 0)) or None
    db.update(conn, "routines", routine_id, **fields)


@app.get("/routines/{routine_id}", response_class=HTMLResponse)
def routine_detail(request: Request, routine_id: int, user: sqlite3.Row = Depends(current_user)):
    routine = db.one(conn, "SELECT * FROM routines WHERE id = ?", (routine_id,))
    if routine is None or (user["role"] != "gm" and routine["location_id"] != user["location_id"]):
        raise HTTPException(404, "الروتين غير موجود")
    periods = db.all_rows(conn, "SELECT * FROM routine_periods WHERE routine_id = ? ORDER BY start_time",
                          (routine_id,))
    owners = {row["id"]: row["owner_role"] for row in P.owners_of(conn, routine_id)}
    logs = db.all_rows(
        conn,
        """SELECT g.*, u.name AS who, p.name AS period_name FROM routine_logs g
           JOIN users u ON u.id = g.user_id LEFT JOIN routine_periods p ON p.id = g.period_id
           WHERE g.routine_id = ? ORDER BY g.date DESC, g.id DESC LIMIT 20""",
        (routine_id,))
    rota = P.routine_rota(conn, routine_id)
    slots = {day: [row["id"] for row in rota[day]] + [0] for day in P.ALL_WEEKDAYS}
    while max(len(ids) for ids in slots.values()) < 2:          # always one spare box per day
        for ids in slots.values():
            ids.append(0)
    kind = R.kind_of(routine)
    return page(request, "routine.html", user, routine=routine, periods=periods, owners=owners,
                logs=logs, staff=people(user, ("employee", "manager")), weekdays=WEEKDAYS,
                days=P.routine_days(routine), checkin=P.checkin_time(routine),
                rota=slots, rota_size=max(len(ids) for ids in slots.values()),
                kind=kind, kinds=R.KINDS, hints=R.KIND_HINT, cycles=R.CYCLES,
                expected=R.expected_days(routine), cycle=R.cycle_of(routine),
                cycle_day=R.cycle_day(routine), cycle_text=R.cycle_label(routine),
                next_due=R.next_due(routine, texts.now().date()),
                runs=R.history(conn, routine_id, 12), day_number=R.day_number,
                all_weekdays=P.ALL_WEEKDAYS, weekday_ar=P.WEEKDAY_AR,
                error=request.query_params.get("error", ""))


@app.post("/routines/{routine_id}")
async def routine_save(request: Request, routine_id: int, user: sqlite3.Row = Depends(current_user)):
    form = await request.form()
    action = str(form.get("action", "edit"))
    try:
        if action == "edit":
            current = db.one(conn, "SELECT * FROM routines WHERE id = ?", (routine_id,))
            P.update_routine(conn, routine_id, name=str(form.get("name", "")),
                             days=form.getlist("days") or P.routine_days(current),
                             instructions=str(form.get("instructions", "")),
                             count_label=str(form.get("count_label", "")),
                             checkin=str(form.get("checkin", "")))
            wanted = str(form.get("kind") or R.kind_of(current))
            if wanted != R.kind_of(current):
                R.change_kind(conn, routine_id, wanted)
            _save_kind_fields(routine_id, wanted, form)
        elif action == "start":
            task_id, event = R.start_run(
                conn, user["id"], routine_id,
                assignee_id=int(str(form.get("assignee") or 0)),
                reference=str(form.get("reference", "")),
                days=int(str(form.get("days") or 0)) or None,
                description=str(form.get("note", "")))
            notify.queue(conn, event)
            return RedirectResponse(f"/tasks/{task_id}", status_code=303)
        elif action == "owners":
            P.set_owners(conn, routine_id, form.getlist("owners"), form.getlist("backups"))
        elif action == "rota":
            # one select per box: rota[<weekday>] repeated, "0" meaning nobody
            P.set_routine_rota(conn, routine_id,
                               {day: form.getlist(f"rota[{day}]") for day in P.ALL_WEEKDAYS})
        elif action == "add_period":
            P.add_period(conn, routine_id, name=str(form.get("period_name", "")),
                         days=form.getlist("period_days"), start=str(form.get("start", "")),
                         end=str(form.get("end", "")),
                         minutes_before=int(str(form.get("minutes_before", "15")) or 15))
        elif action == "remove_period":
            P.remove_period(conn, int(str(form.get("period_id"))))
        elif action in ("retire", "restore"):
            P.retire_routine(conn, routine_id, active=action == "restore")
            return RedirectResponse("/routines", status_code=303)
    except (P.RuleError, ValueError) as exc:
        reason = exc.ar if isinstance(exc, P.RuleError) else "قيمة غير صحيحة"
        return RedirectResponse(f"/routines/{routine_id}?error={reason}", status_code=303)
    return RedirectResponse(f"/routines/{routine_id}", status_code=303)


@app.get("/periods", response_class=HTMLResponse)
def periods_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    scoped = "1=1" if user["role"] == "gm" else "r.location_id = ?"
    periods = db.all_rows(
        conn,
        f"""SELECT p.*, r.code, r.name AS routine_name FROM routine_periods p
            JOIN routines r ON r.id = p.routine_id WHERE {scoped}
            ORDER BY p.id""",
        () if user["role"] == "gm" else params,
    )
    schedule = {(s["period_id"], s["weekday"]): s["user_id"]
                for s in db.all_rows(conn, "SELECT * FROM period_schedule")}
    monday = date.today() - timedelta(days=(date.today().weekday() + 2) % 7)   # the Saturday of this week
    dates = {code: (monday + timedelta(days=i)).isoformat() for i, (code, _) in enumerate(WEEKDAYS)}
    overrides = {(o["period_id"], o["date"]): o
                 for o in db.all_rows(conn, "SELECT * FROM period_overrides WHERE date >= ?",
                                      (monday.isoformat(),))}
    swaps = db.all_rows(
        conn,
        """SELECT s.*, f.name AS from_name, t.name AS to_name, p.name AS period_name
           FROM swap_requests s JOIN users f ON f.id = s.from_user JOIN users t ON t.id = s.to_user
           JOIN routine_periods p ON p.id = s.period_id
           WHERE s.status IN ('awaiting_colleague','awaiting_manager') ORDER BY s.id DESC""",
    )
    scope = None if user["role"] == "gm" else user["location_id"]
    today = texts.now().date()
    return page(request, "periods.html", user, periods=periods, schedule=schedule, dates=dates,
                overrides=overrides, weekdays=WEEKDAYS, staff=people(user, ("employee", "manager")),
                swaps=swaps, today_board=P.day_board(conn, today, scope), today=today,
                names={r["id"]: r["name"] for r in db.all_rows(conn, "SELECT id, name FROM users")},
                leaves=P.leaves_from(conn, today, scope),
                reasons={"swap": "تغطية", "leave": "بدل إجازة", "absence": "بدل غياب",
                         "manager": "تعيين المدير"},
                error=request.query_params.get("error", ""))


@app.post("/periods/cover/{request_id}")
def period_cover_decide(request: Request, request_id: int,
                        user: sqlite3.Row = Depends(current_user),
                        decision: str = Form(...), note: str = Form("")):
    """The branch manager settles a cover request from the dashboard."""
    try:
        messages = (P.manager_approves(conn, user["id"], request_id) if decision == "approve"
                    else P.manager_declines(conn, user["id"], request_id, note))
    except P.RuleError as exc:
        return RedirectResponse(f"/periods?error={exc.ar}", status_code=303)
    for message in messages:                 # the bot delivers them
        notify.queue_raw(conn, message.user_id, message.body, keyboard=message.keyboard,
                         action="cover_decision")
    return RedirectResponse("/periods", status_code=303)


@app.get("/leaves", response_class=HTMLResponse)
def leaves_view(request: Request, user: sqlite3.Row = Depends(current_user), week: str = ""):
    """The weekly off-day grid, plus every recorded leave."""
    today = texts.now().date()
    start = date.fromisoformat(week) if week else today - timedelta(days=(today.weekday() + 2) % 7)
    days = [start + timedelta(days=offset) for offset in range(7)]
    scope = None if user["role"] == "gm" else user["location_id"]
    staff = db.all_rows(
        conn,
        """SELECT u.*, l.name AS branch FROM users u LEFT JOIN locations l ON l.id = u.location_id
           WHERE u.active = 1 AND u.role != 'gm' AND (? IS NULL OR u.location_id = ?)
           ORDER BY l.name, u.role DESC, u.name""",
        (scope, scope),
    )
    return page(request, "leaves.html", user, staff=staff, days=days, start=start,
                marks=P.week_marks(conn, days, scope), weekday_ar=P.WEEKDAY_AR,
                weekday_key=P.weekday_key, today=today, weekdays=WEEKDAYS,
                fixed={row["id"]: P.fixed_day_off(row) for row in staff},
                workdays=schedule.workdays(conn),
                prev_week=(start - timedelta(days=7)).isoformat(),
                next_week=(start + timedelta(days=7)).isoformat(),
                leaves=P.leaves_from(conn, today, scope),
                error=request.query_params.get("error", ""))


@app.post("/leaves/grid")
async def leaves_grid(request: Request, user: sqlite3.Row = Depends(current_user)):
    """Save the whole week at once: a ticked box is a day off, an empty one is not."""
    form = await request.form()
    week = str(form.get("week", ""))
    start = date.fromisoformat(week)
    days = [start + timedelta(days=offset) for offset in range(7)]
    ticked = {str(value) for value in form.getlist("off")}        # "<user id>|<date>"
    locked = {key for key, mark in P.week_marks(conn, days).items() if mark["kind"] != "off"}
    for person_id in {int(str(value)) for value in form.getlist("person")}:
        for day in days:
            if (person_id, day.isoformat()) in locked:            # a recorded leave, not a tick
                continue
            P.set_day_off(conn, user["id"], person_id, day,
                          f"{person_id}|{day.isoformat()}" in ticked)
    return RedirectResponse(f"/leaves?week={week}", status_code=303)


@app.post("/leaves/dayoff")
def leaves_day_off(request: Request, user: sqlite3.Row = Depends(current_user),
                   user_id: int = Form(...), weekday: str = Form(""), week: str = Form("")):
    """The one fixed weekday a person is off, agreed with the GM."""
    if user["role"] != "gm":
        raise HTTPException(403, "العطلة الأسبوعية الثابتة يحددها المدير العام")
    try:
        P.set_fixed_day_off(conn, user_id, weekday)
    except P.RuleError as exc:
        return RedirectResponse(f"/leaves?week={week}&error={exc.ar}", status_code=303)
    return RedirectResponse(f"/leaves?week={week}", status_code=303)


@app.post("/leaves/add")
async def leaves_add(request: Request, user: sqlite3.Row = Depends(current_user)):
    """Manual entry: a full leave over days, or a couple of hours out of one day."""
    form = await request.form()
    back = f"/leaves?week={form.get('week', '')}"
    try:
        person_id = int(str(form["user_id"]))
        start = date.fromisoformat(str(form["from_date"]))
        end = date.fromisoformat(str(form.get("to_date") or form["from_date"]))
    except (KeyError, ValueError):
        return RedirectResponse(f"{back}&error=تواريخ غير صحيحة", status_code=303)
    hours = None
    if str(form.get("from_time", "")).strip():
        hours = (str(form.get("from_time")), str(form.get("to_time", "")))
    try:
        _, messages = P.record_leave(conn, user["id"], person_id, start, end,
                                     kind=str(form.get("kind", "leave")), hours=hours)
    except P.RuleError as exc:
        return RedirectResponse(f"{back}&error={exc.ar}", status_code=303)
    for message in messages:
        notify.queue_raw(conn, message.user_id, message.body, action="leave")
    if hours is None and P.periods_during_leave(conn, person_id, start, end):
        return RedirectResponse(f"/leaves/{person_id}?from_date={start}&to_date={end}", status_code=303)
    return RedirectResponse(back, status_code=303)


@app.post("/leaves/{leave_id}/remove")
def leaves_remove(request: Request, leave_id: int, user: sqlite3.Row = Depends(current_user),
                  week: str = Form("")):
    P.remove_leave(conn, leave_id)
    return RedirectResponse(f"/leaves?week={week}", status_code=303)


@app.get("/leaves/{user_id}", response_class=HTMLResponse)
def leave_form(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user),
               from_date: str = "", to_date: str = ""):
    """Step 1: pick the dates. Step 2 (same page): pick who covers each period."""
    person = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))
    if person is None or (user["role"] != "gm" and person["location_id"] != user["location_id"]):
        raise HTTPException(404, "الموظف غير موجود")
    today = texts.now().date()
    start = date.fromisoformat(from_date) if from_date else today
    end = date.fromisoformat(to_date) if to_date else start
    affected = P.periods_during_leave(conn, user_id, start, end) if end >= start else []
    return page(request, "leave.html", user, person=person, start=start, end=end,
                affected=affected, weekday_ar=P.WEEKDAY_AR, weekday_key=P.weekday_key,
                candidates=[p for p in people(user, ("employee", "manager")) if p["id"] != user_id],
                error=request.query_params.get("error", ""))


@app.post("/leaves/{user_id}")
async def leave_save(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    form = await request.form()
    try:
        start = date.fromisoformat(str(form["from_date"]))
        end = date.fromisoformat(str(form["to_date"]))
    except (KeyError, ValueError):
        return RedirectResponse(f"/leaves/{user_id}?error=تواريخ غير صحيحة", status_code=303)
    # cover[<period_id>|<date>] = user id, straight from the selects on the page
    cover = {}
    for key, value in form.items():
        if key.startswith("cover[") and str(value).isdigit() and int(value):
            inner = key[len("cover["):-1]
            period_id, day = inner.split("|")
            cover[(int(period_id), day)] = int(value)
    try:
        _, messages = P.record_leave(conn, user["id"], user_id, start, end,
                                     kind=str(form.get("kind", "leave")), cover=cover)
    except P.RuleError as exc:
        return RedirectResponse(f"/leaves/{user_id}?error={exc.ar}", status_code=303)
    for message in messages:
        notify.queue_raw(conn, message.user_id, message.body, keyboard=message.keyboard,
                         action="leave")
    return RedirectResponse("/periods", status_code=303)


@app.post("/periods/assign")
def period_assign(request: Request, user: sqlite3.Row = Depends(current_user),
                  period_id: int = Form(...), weekday: str = Form(...), user_id: int = Form(0)):
    existing = db.one(conn, "SELECT * FROM period_schedule WHERE period_id = ? AND weekday = ?",
                      (period_id, weekday))
    before = existing["user_id"] if existing else None
    if existing:
        db.update(conn, "period_schedule", existing["id"], user_id=user_id or None)
    else:
        db.insert(conn, "period_schedule", period_id=period_id, weekday=weekday, user_id=user_id or None)

    if user_id and user_id != before:        # tell the person they are on the rota
        period = P.get_period(conn, period_id)
        notify.queue_raw(conn, user_id,
                         f"📅 <b>فترة ثابتة جديدة</b>\n{P.WEEKDAY_AR[weekday]} · {P.label(period)}\n"
                         f"{period['code']} · {period['routine_name']}\n"
                         "كل أسبوع، ويصلك تذكير قبل نهايتها بـ15 دقيقة.",
                         action="period_assigned")
    return RedirectResponse("/periods", status_code=303)


# ----------------------------------------------------------------- people
@app.get("/employees", response_class=HTMLResponse)
def employees_view(request: Request, user: sqlite3.Row = Depends(current_user), code: str = ""):
    where, params = branch_filter(user)
    scoped = "1=1" if user["role"] == "gm" else "u.location_id = ?"
    staff = db.all_rows(
        conn,
        f"""SELECT u.*, (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id = u.id
             AND t.status IN ('assigned','in_progress','handover','review')) AS open_tasks
            FROM users u WHERE {scoped} ORDER BY u.active DESC,
            CASE u.role WHEN 'gm' THEN 0 WHEN 'manager' THEN 1 ELSE 2 END, u.name""",
        () if user["role"] == "gm" else params,
    )
    return page(request, "employees.html", user, staff=staff, new_code=code,
                error=request.query_params.get("error", ""))


@app.post("/employees")
def add_employee(request: Request, user: sqlite3.Row = Depends(current_user),
                 name: str = Form(...), role: str = Form("employee"), telegram: str = Form("")):
    if user["role"] != "gm":
        raise HTTPException(403, "إضافة الأشخاص للمدير العام فقط")
    manager = db.one(conn, "SELECT id FROM users WHERE role = 'manager' AND location_id = ?",
                     (user["location_id"],))
    user_id = db.insert(conn, "users", name=name.strip(), role=role, location_id=user["location_id"],
                        telegram_username=telegram.strip().lstrip("@") or None,
                        manager_id=manager["id"] if manager and role == "employee" else None)
    code = auth.new_link_code(conn, user_id)
    return RedirectResponse(f"/employees?code={code}", status_code=303)


@app.post("/employees/{user_id}/code")
def reset_code(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    code = auth.new_link_code(conn, user_id)
    return RedirectResponse(f"/employees?code={code}", status_code=303)


def _person_or_404(user: sqlite3.Row, user_id: int) -> sqlite3.Row:
    person = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if person is None or (user["role"] != "gm" and person["location_id"] != user["location_id"]):
        raise HTTPException(404, "الموظف غير موجود")
    return person


@app.get("/employees/{user_id}/remove", response_class=HTMLResponse)
def remove_form(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    """What this person is still holding, before they are taken off the team."""
    if user["role"] != "gm":
        raise HTTPException(403, "إيقاف الأشخاص للمدير العام فقط")
    person = _person_or_404(user, user_id)
    open_tasks = T.open_tasks_for(conn, user_id)
    slots = db.all_rows(
        conn,
        """SELECT s.*, p.name AS period_name, p.start_time, p.end_time, r.code
           FROM period_schedule s JOIN routine_periods p ON p.id = s.period_id
           JOIN routines r ON r.id = p.routine_id WHERE s.user_id = ?""",
        (user_id,),
    )
    routines = P.routines_of(conn, user_id)
    others = [p for p in people(user, ("employee", "manager")) if p["id"] != user_id]
    return page(request, "employee_remove.html", user, person=person, open_tasks=open_tasks,
                slots=slots, routines=routines, candidates=others,
                weekday_ar=P.WEEKDAY_AR)


@app.post("/employees/{user_id}/remove")
def remove_employee(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user),
                    move_to: int = Form(0), clear_slots: str = Form("")):
    """Nothing is deleted: the person is switched off and their history stays whole."""
    if user["role"] != "gm":
        raise HTTPException(403, "إيقاف الأشخاص للمدير العام فقط")
    person = _person_or_404(user, user_id)
    if person["id"] == user["id"]:
        return RedirectResponse("/employees?error=لا يمكنك إيقاف حسابك", status_code=303)

    for task in T.open_tasks_for(conn, user_id):          # hand the work over first
        if move_to:
            try:
                notify.queue(conn, T.reassign(conn, user["id"], task["id"], move_to,
                                              f"إيقاف حساب {person['name']}"))
            except T.RuleError:
                pass
    if clear_slots:
        conn.execute("UPDATE period_schedule SET user_id = NULL WHERE user_id = ?", (user_id,))
    conn.execute("DELETE FROM routine_owners WHERE user_id = ?", (user_id,))
    db.update(conn, "users", user_id, active=0, link_code=None, link_code_expires=None)
    return RedirectResponse("/employees", status_code=303)


@app.post("/employees/{user_id}/edit")
def edit_employee(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user),
                  name: str = Form(...), telegram: str = Form(""), role: str = Form("")):
    """Fix a name or a Telegram handle without touching anything else."""
    person = _person_or_404(user, user_id)
    if user["role"] != "gm" and person["role"] != "employee":
        raise HTTPException(403, "تعديل المدراء للمدير العام فقط")
    if not name.strip():
        return RedirectResponse(f"/employees/{user_id}?error=الاسم مطلوب", status_code=303)
    fields = {"name": name.strip(),
              "telegram_username": telegram.strip().lstrip("@") or None}
    if role in ("employee", "manager") and user["role"] == "gm" and person["role"] != "gm":
        fields["role"] = role
    db.update(conn, "users", user_id, **fields)
    return RedirectResponse(f"/employees/{user_id}", status_code=303)


@app.post("/employees/{user_id}/unlink")
def unlink_employee(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user),
                    issue_code: str = Form("")):
    """Cut the bot connection — for a changed phone or a handed-over account."""
    person = _person_or_404(user, user_id)
    db.update(conn, "users", user_id, telegram_id=None)
    log.info("%s unlinked %s from the bot", user["name"], person["name"])
    if issue_code:
        code = auth.new_link_code(conn, user_id)
        return RedirectResponse(f"/employees?code={code}", status_code=303)
    return RedirectResponse(f"/employees/{user_id}", status_code=303)


@app.post("/employees/{user_id}/delete")
def delete_employee(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user),
                    confirm: str = Form("")):
    """Really remove a person — only for the placeholders, and only once the board is clear."""
    if user["role"] != "gm":
        raise HTTPException(403, "الحذف النهائي للمدير العام فقط")
    person = _person_or_404(user, user_id)
    if person["id"] == user["id"] or person["role"] == "gm":
        return RedirectResponse("/employees?error=لا يمكن حذف حساب المدير العام", status_code=303)
    if confirm.strip() != CONFIRM_WORD:
        return RedirectResponse(f"/employees?error=اكتب «{CONFIRM_WORD}» لتأكيد حذف {person['name']}",
                                status_code=303)
    try:
        removed = cleanup.delete_person(conn, user_id)
    except ValueError as exc:
        return RedirectResponse(f"/employees?error={exc}", status_code=303)
    log.warning("%s deleted %s: %s", user["name"], person["name"], removed)
    return RedirectResponse("/employees", status_code=303)


@app.post("/employees/{user_id}/restore")
def restore_employee(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    if user["role"] != "gm":
        raise HTTPException(403, "إعادة التفعيل للمدير العام فقط")
    _person_or_404(user, user_id)
    db.update(conn, "users", user_id, active=1)
    return RedirectResponse("/employees", status_code=303)


# ----------------------------------------------------------------- settings
@app.get("/settings", response_class=HTMLResponse)
def settings_view(request: Request, user: sqlite3.Row = Depends(current_user), saved: str = ""):
    if user["role"] != "gm":
        raise HTTPException(403, "الإعدادات للمدير العام فقط")
    slots = db.all_rows(conn, "SELECT * FROM checkin_slots ORDER BY time")
    values = {r["key"]: r["value"] for r in db.all_rows(conn, "SELECT * FROM settings")}
    return page(request, "settings.html", user, slots=slots, values=values, saved=saved,
                counts=cleanup.summary(conn), error=request.query_params.get("error", ""))


@app.post("/settings/slots")
def save_slots(request: Request, user: sqlite3.Row = Depends(current_user),
               slot_id: list[int] = Form([]), time: list[str] = Form([])):
    if user["role"] != "gm":
        raise HTTPException(403, "الإعدادات للمدير العام فقط")
    for sid, value in zip(slot_id, time):
        db.update(conn, "checkin_slots", sid, time=value)
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.post("/settings/board")
def save_board_rules(request: Request, user: sqlite3.Row = Depends(current_user),
                     board_clear_time: str = Form("23:59"), refresh_seconds: str = Form("60")):
    """When منجزة is swept, and how often a page reloads itself."""
    if user["role"] != "gm":
        raise HTTPException(403, "الإعدادات للمدير العام فقط")
    try:
        clock = P._clean_time(board_clear_time, ledger.DEFAULT_BOARD_CLEAR)
        seconds = max(0, min(int(refresh_seconds or 60), 3600))
    except (P.RuleError, ValueError):
        return RedirectResponse("/settings?error=قيمة غير صحيحة", status_code=303)
    for key, value in (("board_clear_time", clock), ("refresh_seconds", str(seconds))):
        row = db.one(conn, "SELECT key FROM settings WHERE key = ?", (key,))
        if row:
            conn.execute("UPDATE settings SET value = ? WHERE key = ?", (value, key))
        else:
            db.insert(conn, "settings", key=key, value=value)
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.post("/settings/slots/add")
def add_slot(request: Request, user: sqlite3.Row = Depends(current_user),
             kind: str = Form("update"), time: str = Form(...)):
    db.insert(conn, "checkin_slots", location_id=user["location_id"], kind=kind, time=time)
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.post("/settings/slots/{slot_id}/delete")
def delete_slot(request: Request, slot_id: int, user: sqlite3.Row = Depends(current_user)):
    conn.execute("DELETE FROM checkin_slots WHERE id = ?", (slot_id,))
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.post("/settings/clear")
def clear_data(request: Request, user: sqlite3.Row = Depends(current_user),
               what: str = Form(...), confirm: str = Form("")):
    """The one place in the system that really deletes. The GM types the word first."""
    if user["role"] != "gm":
        raise HTTPException(403, "تفريغ البيانات للمدير العام فقط")
    if confirm.strip() != CONFIRM_WORD:
        return RedirectResponse(f"/settings?error=اكتب كلمة «{CONFIRM_WORD}» للتأكيد",
                                status_code=303)
    if what == "tasks":
        removed = cleanup.clear_tasks(conn)
        log.warning("board cleared by %s: %s", user["name"], removed)
    elif what == "history":
        removed = cleanup.clear_routine_history(conn)
        log.warning("routine history cleared by %s: %s", user["name"], removed)
    elif what == "everything":
        cleanup.clear_tasks(conn)
        cleanup.clear_routine_history(conn)
        log.warning("board and history cleared by %s", user["name"])
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.get("/notifications", response_class=HTMLResponse)
def notifications(request: Request, user: sqlite3.Row = Depends(current_user),
                  kind: str = "all", page_no: int = 1):
    kind = kind if kind in feed.FEED_FILTERS else "all"
    per_page = 60
    rows = feed.feed(conn, user, kind=kind, limit=per_page, offset=(max(page_no, 1) - 1) * per_page)
    return page(request, "notifications.html", user, rows=rows, kind=kind, page_no=max(page_no, 1),
                has_more=len(rows) == per_page, labels=feed.FEED_ACTIONS)


@app.post("/notifications/read")
def notifications_read(request: Request, user: sqlite3.Row = Depends(current_user)):
    feed.mark_all_read(conn, user)
    return RedirectResponse("/notifications", status_code=303)


@app.get("/employees/{user_id}", response_class=HTMLResponse)
def employee_detail(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    summary = feed.employee_summary(conn, user_id)
    if not summary:
        raise HTTPException(404, "الموظف غير موجود")
    if user["role"] != "gm" and summary["person"]["location_id"] != user["location_id"]:
        raise HTTPException(403, "هذا الموظف ليس في فرعك")
    return page(request, "employee.html", user, **summary, labels=feed.FEED_ACTIONS,
                error=request.query_params.get("error", ""))


@app.get("/health")
def health():
    """Open without a login, so a deploy can be checked with one curl."""
    return {"ok": True, "build": BUILD,
            "time": texts.now().isoformat(timespec="seconds")}
