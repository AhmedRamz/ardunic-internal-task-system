"""The dashboard: FastAPI + server-rendered Arabic pages.

Accounts are for the GM and the branch managers. The GM sees every branch;
a manager sees their own. Employees have no login — they work from the bot.

    PYTHONPATH=src uvicorn ims.web.app:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta
from pathlib import Path

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from .. import db, texts
from ..config import Config
from ..core import auth
from ..core import feed
from ..core import notify
from ..core import periods as P
from ..core import tasks as T

BASE = Path(__file__).resolve().parent
config = Config.load()
conn = db.connect(config.db_path)
db.migrate(conn)

app = FastAPI(title="Ardunic Internal Management System", docs_url=None, redoc_url=None)
app.add_middleware(SessionMiddleware, secret_key=auth.session_secret(), session_cookie="ims_session",
                   https_only=False, max_age=60 * 60 * 24 * 14)
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

templates = Jinja2Templates(directory=str(BASE / "templates"))
templates.env.globals.update(
    STATUS=texts.STATUS, PRIORITY=texts.PRIORITY, ROLE=texts.ROLE,
    RESULTS=P.RESULTS, due_label=texts.due_label,
)

COLUMNS = [
    ("suggested", "مقترحة", "#5B3E96"),
    ("assigned", "مسندة", "#1D4F91"),
    ("in_progress", "قيد التنفيذ", "#0E6B63"),
    ("handover", "بانتظار التسليم", "#8F4507"),
    ("review", "بانتظار المراجعة", "#6B6558"),
    ("done", "منجزة", "#1E6B3A"),
]
WEEKDAYS = [("sat", "السبت"), ("sun", "الأحد"), ("mon", "الاثنين"), ("tue", "الثلاثاء"),
            ("wed", "الأربعاء"), ("thu", "الخميس"), ("fri", "الجمعة")]


# ----------------------------------------------------------------- auth plumbing
def current_user(request: Request) -> sqlite3.Row:
    user_id = request.session.get("user_id")
    user = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,)) if user_id else None
    if user is None:
        raise HTTPException(status_code=303, headers={"Location": "/login"})
    return user


@app.exception_handler(HTTPException)
async def redirect_handler(request: Request, exc: HTTPException):
    if exc.status_code == 303 and exc.headers and "Location" in exc.headers:
        return RedirectResponse(exc.headers["Location"], status_code=303)
    return HTMLResponse(f"<h1>{exc.status_code}</h1><p>{exc.detail}</p>", status_code=exc.status_code)


def page(request: Request, name: str, user: sqlite3.Row, **context) -> HTMLResponse:
    location = db.one(conn, "SELECT name FROM locations WHERE id = ?", (user["location_id"],))
    return templates.TemplateResponse(
        request, name,
        {"user": user, "location": location["name"] if location else "", "today": date.today().isoformat(),
         "is_gm": user["role"] == "gm", "unread_total": feed.unread_total(conn, user), **context},
    )


def branch_filter(user: sqlite3.Row) -> tuple[str, tuple]:
    if user["role"] == "gm":
        return "1=1", ()
    return "location_id = ?", (user["location_id"],)


def people(user: sqlite3.Row, roles=("employee",)) -> list[sqlite3.Row]:
    marks = ",".join("?" for _ in roles)
    where, params = branch_filter(user)
    return db.all_rows(
        conn,
        f"SELECT * FROM users WHERE active = 1 AND role IN ({marks}) AND {where} ORDER BY role, name",
        (*roles, *params),
    )


# ----------------------------------------------------------------- login
@app.get("/login", response_class=HTMLResponse)
def login_form(request: Request, error: str = ""):
    return templates.TemplateResponse(request, "login.html", {"error": error})


@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    user = auth.authenticate(conn, username, password)
    if user is None:
        return RedirectResponse("/login?error=1", status_code=303)
    request.session["user_id"] = user["id"]
    return RedirectResponse("/", status_code=303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", status_code=303)


# ----------------------------------------------------------------- board
@app.get("/", response_class=HTMLResponse)
def board(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    rows = db.all_rows(
        conn,
        f"""SELECT t.*, u.name AS assignee_name, c.name AS creator_name,
                   (SELECT w.name FROM handovers h JOIN users w ON w.id = h.to_user
                     WHERE h.task_id = t.id AND h.status IN ('pending','awaiting_employee')
                     ORDER BY h.id DESC LIMIT 1) AS handover_to,
                   (SELECT h.status FROM handovers h
                     WHERE h.task_id = t.id AND h.status IN ('pending','awaiting_employee')
                     ORDER BY h.id DESC LIMIT 1) AS handover_stage
            FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
                         LEFT JOIN users c ON c.id = t.created_by
            WHERE {where} AND (t.status != 'done' OR t.closed_at > datetime('now','-7 days'))
            ORDER BY t.id DESC""",
        params,
    )
    columns = []
    for key, title, colour in COLUMNS:
        cards = [r for r in rows if r["status"] == key or (key == "assigned" and r["status"] == "rejected")]
        columns.append({"key": key, "title": title, "colour": colour, "cards": cards})
    return page(request, "board.html", user, columns=columns, unread=feed.unread_by_task(conn, user["id"]),
                now=texts.now().strftime("%Y-%m-%d · %H:%M"))


@app.get("/tasks/new", response_class=HTMLResponse)
def new_task_form(request: Request, user: sqlite3.Row = Depends(current_user)):
    roles = ("employee", "manager") if user["role"] == "gm" else ("employee",)
    return page(request, "new_task.html", user, candidates=people(user, roles),
                default_due=texts.today_at(17))


@app.post("/tasks/new")
def new_task(request: Request, user: sqlite3.Row = Depends(current_user),
             title: str = Form(...), description: str = Form(""), assignee_id: int = Form(...),
             due_at: str = Form(""), priority: str = Form("normal"),
             needs_review: str = Form(""), allow_delegation: str = Form("")):
    try:
        task_id, event = T.create_task(conn, user["id"], title, assignee_id, description=description,
                                       due_at=due_at or None, priority=priority,
                                       needs_review=bool(needs_review),
                                       allow_delegation=bool(allow_delegation))
        notify.queue(conn, event)            # the assignee hears about it on Telegram
    except T.RuleError as exc:
        return page(request, "new_task.html", user, candidates=people(user, ("employee", "manager")),
                    default_due=texts.today_at(17), error=exc.ar)
    return RedirectResponse(f"/tasks/{task_id}", status_code=303)


@app.get("/tasks/{task_id}", response_class=HTMLResponse)
def task_detail(request: Request, task_id: int, user: sqlite3.Row = Depends(current_user), error: str = ""):
    task = db.one(conn, "SELECT * FROM tasks WHERE id = ?", (task_id,))
    if task is None or (user["role"] != "gm" and task["location_id"] != user["location_id"]):
        raise HTTPException(404, "المهمة غير موجودة")
    names = {r["id"]: r["name"] for r in db.all_rows(conn, "SELECT id, name FROM users")}
    handover = db.one(
        conn,
        """SELECT * FROM handovers WHERE task_id = ? AND status IN ('pending','awaiting_employee')
           ORDER BY id DESC LIMIT 1""",
        (task_id,),
    )
    feed.mark_read(conn, user["id"], task_id)        # everything on this page counts as seen
    return page(request, "task.html", user, task=task, names=names, handover=handover,
                events=T.history(conn, task_id), candidates=people(user, ("employee", "manager")),
                labels=feed.FEED_ACTIONS, error=error)


@app.post("/tasks/{task_id}/action")
def task_action(request: Request, task_id: int, user: sqlite3.Row = Depends(current_user),
                action: str = Form(...), note: str = Form(""), target_id: int = Form(0)):
    handlers = {
        "review_approve": lambda: T.review_approve(conn, user["id"], task_id, note),
        "review_return": lambda: T.review_return(conn, user["id"], task_id, note),
        "reassign": lambda: T.reassign(conn, user["id"], task_id, target_id, note),
        "cancel": lambda: T.cancel(conn, user["id"], task_id, note),
        "comment": lambda: T.add_comment(conn, user["id"], task_id, note),
        "approve_handover": lambda: T.approve_handover(conn, user["id"], task_id),
        "decline_handover": lambda: T.decline_handover(conn, user["id"], task_id, note),
        "approve_suggestion": lambda: T.approve_suggestion(conn, user["id"], task_id,
                                                           assignee_id=target_id),
        "decline_suggestion": lambda: T.decline_suggestion(conn, user["id"], task_id, note),
        "accept": lambda: T.accept(conn, user["id"], task_id),
        "done": lambda: T.mark_done(conn, user["id"], task_id, note),
        "delegate": lambda: T.delegate(conn, user["id"], task_id, target_id, note),
    }
    if action not in handlers:
        return RedirectResponse(f"/tasks/{task_id}", status_code=303)
    try:
        event = handlers[action]()
        notify.queue(conn, event)            # everyone concerned hears about it on Telegram
    except T.RuleError as exc:
        return RedirectResponse(f"/tasks/{task_id}?error={exc.ar}", status_code=303)
    return RedirectResponse(f"/tasks/{task_id}", status_code=303)


# ----------------------------------------------------------------- today
@app.get("/today", response_class=HTMLResponse)
def today_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    today = date.today().isoformat()
    staff = people(user, ("employee",))
    stats = {
        "open": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND status IN "
                             "('assigned','in_progress','handover','review')", params)["c"],
        "done": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND status = 'done' "
                             "AND date(closed_at) = date('now')", params)["c"],
        "overdue": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND due_at < datetime('now') "
                                "AND status IN ('assigned','in_progress')", params)["c"],
        "unaccepted": db.one(conn, f"SELECT COUNT(*) c FROM tasks WHERE {where} AND status = 'assigned'",
                             params)["c"],
    }
    rows = []
    for person in staff:
        answers = db.all_rows(
            conn,
            "SELECT * FROM checkins WHERE user_id = ? AND date = ? ORDER BY id",
            (person["id"], today),
        )
        routines = db.all_rows(
            conn,
            "SELECT * FROM routine_logs WHERE user_id = ? AND date = ?",
            (person["id"], today),
        )
        last = db.one(
            conn,
            """SELECT e.note FROM task_events e JOIN tasks t ON t.id = e.task_id
               WHERE e.actor_id = ? AND e.note IS NOT NULL ORDER BY e.id DESC LIMIT 1""",
            (person["id"],),
        )
        rows.append({"person": person, "answers": answers, "routines": routines,
                     "last_note": last["note"] if last else "—"})
    attention = db.all_rows(
        conn,
        f"""SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
            WHERE {where} AND (t.status IN ('rejected','handover','review','suggested')
                  OR (t.due_at < datetime('now') AND t.status IN ('assigned','in_progress')))
            ORDER BY t.id DESC LIMIT 12""",
        params,
    )
    return page(request, "today.html", user, stats=stats, rows=rows, attention=attention)


# ----------------------------------------------------------------- routines and periods
@app.get("/routines", response_class=HTMLResponse)
def routines_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    routines = db.all_rows(conn, f"SELECT * FROM routines WHERE {where} AND active = 1 ORDER BY code", params)
    today = date.today().isoformat()
    data = []
    for routine in routines:
        owners = db.all_rows(
            conn,
            """SELECT u.name, ro.role FROM routine_owners ro JOIN users u ON u.id = ro.user_id
               WHERE ro.routine_id = ?""",
            (routine["id"],),
        )
        periods = db.all_rows(conn, "SELECT * FROM routine_periods WHERE routine_id = ? ORDER BY start_time",
                              (routine["id"],))
        logs = db.all_rows(
            conn,
            """SELECT l.*, u.name FROM routine_logs l JOIN users u ON u.id = l.user_id
               WHERE l.routine_id = ? AND l.date = ?""",
            (routine["id"], today),
        )
        data.append({"routine": routine, "owners": owners, "periods": periods, "logs": logs})
    return page(request, "routines.html", user, routines=data)


@app.get("/periods", response_class=HTMLResponse)
def periods_view(request: Request, user: sqlite3.Row = Depends(current_user)):
    where, params = branch_filter(user)
    scoped = "1=1" if user["role"] == "gm" else "r.location_id = ?"
    periods = db.all_rows(
        conn,
        f"""SELECT p.*, r.code, r.name AS routine_name FROM routine_periods p
            JOIN routines r ON r.id = p.routine_id WHERE {scoped}
            ORDER BY p.id""",
        () if user["role"] == "gm" else params,
    )
    schedule = {(s["period_id"], s["weekday"]): s["user_id"]
                for s in db.all_rows(conn, "SELECT * FROM period_schedule")}
    monday = date.today() - timedelta(days=(date.today().weekday() + 2) % 7)   # the Saturday of this week
    dates = {code: (monday + timedelta(days=i)).isoformat() for i, (code, _) in enumerate(WEEKDAYS)}
    overrides = {(o["period_id"], o["date"]): o
                 for o in db.all_rows(conn, "SELECT * FROM period_overrides WHERE date >= ?",
                                      (monday.isoformat(),))}
    swaps = db.all_rows(
        conn,
        """SELECT s.*, f.name AS from_name, t.name AS to_name, p.name AS period_name
           FROM swap_requests s JOIN users f ON f.id = s.from_user JOIN users t ON t.id = s.to_user
           JOIN routine_periods p ON p.id = s.period_id
           WHERE s.status IN ('awaiting_colleague','awaiting_manager') ORDER BY s.id DESC""",
    )
    scope = None if user["role"] == "gm" else user["location_id"]
    today = texts.now().date()
    return page(request, "periods.html", user, periods=periods, schedule=schedule, dates=dates,
                overrides=overrides, weekdays=WEEKDAYS, staff=people(user, ("employee", "manager")),
                swaps=swaps, today_board=P.day_board(conn, today, scope), today=today,
                names={r["id"]: r["name"] for r in db.all_rows(conn, "SELECT id, name FROM users")},
                leaves=P.leaves_from(conn, today, scope),
                reasons={"swap": "تغطية", "leave": "بدل إجازة", "absence": "بدل غياب",
                         "manager": "تعيين المدير"},
                error=request.query_params.get("error", ""))


@app.post("/periods/cover/{request_id}")
def period_cover_decide(request: Request, request_id: int,
                        user: sqlite3.Row = Depends(current_user),
                        decision: str = Form(...), note: str = Form("")):
    """The branch manager settles a cover request from the dashboard."""
    try:
        messages = (P.manager_approves(conn, user["id"], request_id) if decision == "approve"
                    else P.manager_declines(conn, user["id"], request_id, note))
    except P.RuleError as exc:
        return RedirectResponse(f"/periods?error={exc.ar}", status_code=303)
    for message in messages:                 # the bot delivers them
        notify.queue_raw(conn, message.user_id, message.body, keyboard=message.keyboard,
                         action="cover_decision")
    return RedirectResponse("/periods", status_code=303)


@app.get("/leaves/{user_id}", response_class=HTMLResponse)
def leave_form(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user),
               from_date: str = "", to_date: str = ""):
    """Step 1: pick the dates. Step 2 (same page): pick who covers each period."""
    person = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))
    if person is None or (user["role"] != "gm" and person["location_id"] != user["location_id"]):
        raise HTTPException(404, "الموظف غير موجود")
    today = texts.now().date()
    start = date.fromisoformat(from_date) if from_date else today
    end = date.fromisoformat(to_date) if to_date else start
    affected = P.periods_during_leave(conn, user_id, start, end) if end >= start else []
    return page(request, "leave.html", user, person=person, start=start, end=end,
                affected=affected, weekday_ar=P.WEEKDAY_AR, weekday_key=P.weekday_key,
                candidates=[p for p in people(user, ("employee", "manager")) if p["id"] != user_id],
                error=request.query_params.get("error", ""))


@app.post("/leaves/{user_id}")
async def leave_save(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    form = await request.form()
    try:
        start = date.fromisoformat(str(form["from_date"]))
        end = date.fromisoformat(str(form["to_date"]))
    except (KeyError, ValueError):
        return RedirectResponse(f"/leaves/{user_id}?error=تواريخ غير صحيحة", status_code=303)
    # cover[<period_id>|<date>] = user id, straight from the selects on the page
    cover = {}
    for key, value in form.items():
        if key.startswith("cover[") and str(value).isdigit() and int(value):
            inner = key[len("cover["):-1]
            period_id, day = inner.split("|")
            cover[(int(period_id), day)] = int(value)
    try:
        _, messages = P.record_leave(conn, user["id"], user_id, start, end,
                                     kind=str(form.get("kind", "leave")), cover=cover)
    except P.RuleError as exc:
        return RedirectResponse(f"/leaves/{user_id}?error={exc.ar}", status_code=303)
    for message in messages:
        notify.queue_raw(conn, message.user_id, message.body, keyboard=message.keyboard,
                         action="leave")
    return RedirectResponse("/periods", status_code=303)


@app.post("/periods/assign")
def period_assign(request: Request, user: sqlite3.Row = Depends(current_user),
                  period_id: int = Form(...), weekday: str = Form(...), user_id: int = Form(0)):
    existing = db.one(conn, "SELECT id FROM period_schedule WHERE period_id = ? AND weekday = ?",
                      (period_id, weekday))
    before = existing["user_id"] if existing else None
    if existing:
        db.update(conn, "period_schedule", existing["id"], user_id=user_id or None)
    else:
        db.insert(conn, "period_schedule", period_id=period_id, weekday=weekday, user_id=user_id or None)

    if user_id and user_id != before:        # tell the person they are on the rota
        period = P.get_period(conn, period_id)
        notify.queue_raw(conn, user_id,
                         f"📅 <b>فترة ثابتة جديدة</b>\n{P.WEEKDAY_AR[weekday]} · {P.label(period)}\n"
                         f"{period['code']} · {period['routine_name']}\n"
                         "كل أسبوع، ويصلك تذكير قبل نهايتها بـ15 دقيقة.",
                         action="period_assigned")
    return RedirectResponse("/periods", status_code=303)


# ----------------------------------------------------------------- people
@app.get("/employees", response_class=HTMLResponse)
def employees_view(request: Request, user: sqlite3.Row = Depends(current_user), code: str = ""):
    where, params = branch_filter(user)
    scoped = "1=1" if user["role"] == "gm" else "u.location_id = ?"
    staff = db.all_rows(
        conn,
        f"""SELECT u.*, (SELECT COUNT(*) FROM tasks t WHERE t.assignee_id = u.id
             AND t.status IN ('assigned','in_progress','handover','review')) AS open_tasks
            FROM users u WHERE {scoped} ORDER BY CASE u.role WHEN 'gm' THEN 0 WHEN 'manager' THEN 1
            ELSE 2 END, u.name""",
        () if user["role"] == "gm" else params,
    )
    return page(request, "employees.html", user, staff=staff, new_code=code)


@app.post("/employees")
def add_employee(request: Request, user: sqlite3.Row = Depends(current_user),
                 name: str = Form(...), role: str = Form("employee"), telegram: str = Form("")):
    if user["role"] != "gm":
        raise HTTPException(403, "إضافة الأشخاص للمدير العام فقط")
    manager = db.one(conn, "SELECT id FROM users WHERE role = 'manager' AND location_id = ?",
                     (user["location_id"],))
    user_id = db.insert(conn, "users", name=name.strip(), role=role, location_id=user["location_id"],
                        telegram_username=telegram.strip().lstrip("@") or None,
                        manager_id=manager["id"] if manager and role == "employee" else None)
    code = auth.new_link_code(conn, user_id)
    return RedirectResponse(f"/employees?code={code}", status_code=303)


@app.post("/employees/{user_id}/code")
def reset_code(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    code = auth.new_link_code(conn, user_id)
    return RedirectResponse(f"/employees?code={code}", status_code=303)


# ----------------------------------------------------------------- settings
@app.get("/settings", response_class=HTMLResponse)
def settings_view(request: Request, user: sqlite3.Row = Depends(current_user), saved: str = ""):
    if user["role"] != "gm":
        raise HTTPException(403, "الإعدادات للمدير العام فقط")
    slots = db.all_rows(conn, "SELECT * FROM checkin_slots ORDER BY time")
    values = {r["key"]: r["value"] for r in db.all_rows(conn, "SELECT * FROM settings")}
    return page(request, "settings.html", user, slots=slots, values=values, saved=saved)


@app.post("/settings/slots")
def save_slots(request: Request, user: sqlite3.Row = Depends(current_user),
               slot_id: list[int] = Form([]), time: list[str] = Form([])):
    if user["role"] != "gm":
        raise HTTPException(403, "الإعدادات للمدير العام فقط")
    for sid, value in zip(slot_id, time):
        db.update(conn, "checkin_slots", sid, time=value)
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.post("/settings/slots/add")
def add_slot(request: Request, user: sqlite3.Row = Depends(current_user),
             kind: str = Form("update"), time: str = Form(...)):
    db.insert(conn, "checkin_slots", location_id=user["location_id"], kind=kind, time=time)
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.post("/settings/slots/{slot_id}/delete")
def delete_slot(request: Request, slot_id: int, user: sqlite3.Row = Depends(current_user)):
    conn.execute("DELETE FROM checkin_slots WHERE id = ?", (slot_id,))
    return RedirectResponse("/settings?saved=1", status_code=303)


@app.get("/notifications", response_class=HTMLResponse)
def notifications(request: Request, user: sqlite3.Row = Depends(current_user),
                  kind: str = "all", page_no: int = 1):
    kind = kind if kind in feed.FEED_FILTERS else "all"
    per_page = 60
    rows = feed.feed(conn, user, kind=kind, limit=per_page, offset=(max(page_no, 1) - 1) * per_page)
    return page(request, "notifications.html", user, rows=rows, kind=kind, page_no=max(page_no, 1),
                has_more=len(rows) == per_page, labels=feed.FEED_ACTIONS)


@app.post("/notifications/read")
def notifications_read(request: Request, user: sqlite3.Row = Depends(current_user)):
    feed.mark_all_read(conn, user)
    return RedirectResponse("/notifications", status_code=303)


@app.get("/employees/{user_id}", response_class=HTMLResponse)
def employee_detail(request: Request, user_id: int, user: sqlite3.Row = Depends(current_user)):
    summary = feed.employee_summary(conn, user_id)
    if not summary:
        raise HTTPException(404, "الموظف غير موجود")
    if user["role"] != "gm" and summary["person"]["location_id"] != user["location_id"]:
        raise HTTPException(403, "هذا الموظف ليس في فرعك")
    return page(request, "employee.html", user, **summary, labels=feed.FEED_ACTIONS)


@app.get("/health")
def health():
    return {"ok": True, "time": datetime.now().isoformat(timespec="seconds")}
