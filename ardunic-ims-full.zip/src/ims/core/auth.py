"""Dashboard accounts. Only the GM and branch managers have one; employees use the bot."""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import sqlite3
from datetime import datetime, timezone

from .. import db

ITERATIONS = 200_000


def hash_password(password: str) -> str:
    """PBKDF2-SHA256 from the standard library — no extra dependency to keep up to date."""
    salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), ITERATIONS).hex()
    return f"pbkdf2_sha256${ITERATIONS}${salt}${digest}"


def verify_password(password: str, stored: str | None) -> bool:
    if not stored:
        return False
    try:
        algorithm, rounds, salt, digest = stored.split("$")
    except ValueError:
        return False
    if algorithm != "pbkdf2_sha256":
        return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), int(rounds)).hex()
    return hmac.compare_digest(candidate, digest)


def set_password(conn: sqlite3.Connection, user_id: int, password: str) -> None:
    user = db.one(conn, "SELECT role FROM users WHERE id = ?", (user_id,))
    if user is None or user["role"] not in ("gm", "manager"):
        raise ValueError("dashboard accounts are for the GM and branch managers only")
    db.update(conn, "users", user_id, password_hash=hash_password(password))


def authenticate(conn: sqlite3.Connection, username: str, password: str) -> sqlite3.Row | None:
    """Username is the Telegram handle without @, or the person's name."""
    handle = username.strip().lstrip("@")
    user = db.one(
        conn,
        """SELECT * FROM users WHERE active = 1 AND role IN ('gm','manager')
           AND (telegram_username = ? OR name = ?)""",
        (handle, username.strip()),
    )
    if user is None or not verify_password(password, user["password_hash"]):
        return None
    db.update(conn, "users", user["id"], last_login=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"))
    return user


def session_secret() -> str:
    """Stable across restarts when SESSION_SECRET is set; random otherwise (logs everyone out)."""
    return os.environ.get("SESSION_SECRET") or secrets.token_hex(32)


def new_link_code(conn: sqlite3.Connection, user_id: int, hours: int = 24) -> str:
    """A one-time code the person sends to the bot as /start <code>."""
    code = f"{secrets.randbelow(900000) + 100000}"
    conn.execute(
        "UPDATE users SET link_code = ?, link_code_expires = datetime('now', ?) WHERE id = ?",
        (code, f"+{hours} hours", user_id),
    )
    return code
