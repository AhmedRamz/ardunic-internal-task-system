"""Starting clean: emptying the board and removing the people who were only there to test.

Everywhere else in this system nothing is ever deleted — a task is cancelled, a
person is switched off, and the history stays whole. This module is the one
exception, for the moment before the real work starts: it really does delete,
and that is why each function says exactly what it removed and why the pages
that call it ask the GM to type the word first.
"""
from __future__ import annotations

import sqlite3

from .. import db

# every table that hangs off a task, children first
TASK_TABLES = ("task_reads", "attachments", "handovers", "task_events")

# everything that belongs to one person and can go with them
PERSON_TABLES = (
    ("period_schedule", "user_id"),
    ("period_overrides", "user_id"),
    ("period_overrides", "created_by"),
    ("routine_schedule", "user_id"),
    ("routine_owners", "user_id"),
    ("routine_logs", "user_id"),
    ("routine_logs", "covering_for"),
    ("checkins", "user_id"),
    ("days_off", "user_id"),
    ("days_off", "created_by"),
    ("coverages", "cover_user_id"),
    ("leaves", "user_id"),
    ("leaves", "created_by"),
    ("swap_requests", "from_user"),
    ("swap_requests", "to_user"),
    ("outbox", "user_id"),
)

# what still points at a person after the board is empty — these block a delete
TASK_REFERENCES = (
    ("tasks", "assignee_id"),
    ("tasks", "created_by"),
    ("tasks", "delegated_from"),
    ("task_events", "actor_id"),
    ("handovers", "from_user"),
    ("handovers", "to_user"),
)


def clear_tasks(conn: sqlite3.Connection, location_id: int | None = None) -> dict[str, int]:
    """Empty the board: every task of this branch and everything hanging off it."""
    where = "1=1" if location_id is None else "location_id = ?"
    params = () if location_id is None else (location_id,)
    ids = [row["id"] for row in
           db.all_rows(conn, f"SELECT id FROM tasks WHERE {where}", params)]
    removed = {"tasks": len(ids)}
    if not ids:
        return removed
    marks = ",".join("?" for _ in ids)
    for table in TASK_TABLES:
        cursor = conn.execute(f"DELETE FROM {table} WHERE task_id IN ({marks})", ids)
        removed[table] = cursor.rowcount
    removed["outbox"] = conn.execute(
        f"DELETE FROM outbox WHERE task_id IN ({marks})", ids).rowcount
    conn.execute(f"DELETE FROM tasks WHERE id IN ({marks})", ids)
    return removed


def clear_routine_history(conn: sqlite3.Connection) -> dict[str, int]:
    """Throw away the answers given while testing, so the counts start at zero."""
    removed = {}
    for table in ("routine_logs", "checkins", "routine_runs", "period_runs", "slot_runs"):
        removed[table] = conn.execute(f"DELETE FROM {table}").rowcount
    return removed


def blockers(conn: sqlite3.Connection, user_id: int) -> list[str]:
    """Why this person cannot be deleted yet, in words the GM can act on."""
    reasons = []
    counts = {}
    for table, column in TASK_REFERENCES:
        row = db.one(conn, f"SELECT COUNT(*) c FROM {table} WHERE {column} = ?", (user_id,))
        if row["c"]:
            counts[table] = counts.get(table, 0) + row["c"]
    if counts.get("tasks") or counts.get("task_events") or counts.get("handovers"):
        reasons.append("له مهام أو سجل في لوحة المهام — فرّغ اللوحة أولاً أو أوقفه بدل الحذف")
    return reasons


def delete_person(conn: sqlite3.Connection, user_id: int) -> dict[str, int]:
    """Remove a person completely. Refuses while anything on the board still names them."""
    stopped = blockers(conn, user_id)
    if stopped:
        raise ValueError(stopped[0])
    removed: dict[str, int] = {}
    for table, column in PERSON_TABLES:
        cursor = conn.execute(f"DELETE FROM {table} WHERE {column} = ?", (user_id,))
        if cursor.rowcount:
            removed[table] = removed.get(table, 0) + cursor.rowcount
    conn.execute("UPDATE users SET manager_id = NULL WHERE manager_id = ?", (user_id,))
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    removed["users"] = 1
    return removed


def summary(conn: sqlite3.Connection, location_id: int | None = None) -> dict[str, int]:
    """What a clear-out would touch, to show before anyone presses the button."""
    where = "1=1" if location_id is None else "location_id = ?"
    params = () if location_id is None else (location_id,)
    count = lambda sql, args=(): db.one(conn, sql, args)["c"]      # noqa: E731
    return {
        "tasks": count(f"SELECT COUNT(*) c FROM tasks WHERE {where}", params),
        "events": count("SELECT COUNT(*) c FROM task_events"),
        "logs": count("SELECT COUNT(*) c FROM routine_logs"),
        "checkins": count("SELECT COUNT(*) c FROM checkins"),
        "people": count("SELECT COUNT(*) c FROM users WHERE role != 'gm'"),
        "queued": count("SELECT COUNT(*) c FROM outbox WHERE sent_at IS NULL"),
    }
