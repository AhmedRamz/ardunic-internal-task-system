"""The daily rhythm: which message goes to whom, and when.

Pure logic — every function takes `now`, so the whole day can be replayed in a
test without waiting for the clock. The bot process ticks once a minute and
hands the results to the outbox.

    09:00  brief      employees: today's tasks · managers: a team overview
    10:00  update     one message per open task: Done / Working / Blocked
    12:00  update
    14:00  update
    16:30  close-out  each open task: Done or carried over with a note
    17:00  report     managers and the GM: what happened today
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta

from .. import db, texts
from . import tasks as T

WEEKDAY_KEYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
DEFAULT_WORKDAYS = ("sat", "sun", "mon", "tue", "wed", "thu")

# How late a slot may still be useful. If the server was down, a brief is worth
# having at 11:00, but a "how is it going?" from two hours ago is only noise —
# the next update will ask anyway. A slot past its grace is marked as run and skipped.
GRACE_MINUTES = {"brief": 240, "update": 60, "closeout": 90, "report": 240}


# ----------------------------------------------------------------- calendar
def weekday_key(day: date) -> str:
    return WEEKDAY_KEYS[day.weekday()]


def workdays(conn: sqlite3.Connection) -> tuple[str, ...]:
    row = db.one(conn, "SELECT value FROM settings WHERE key = 'workdays'")
    if row and row["value"].strip():
        return tuple(part.strip() for part in row["value"].split(",") if part.strip())
    return DEFAULT_WORKDAYS


def is_workday(conn: sqlite3.Connection, day: date) -> bool:
    return weekday_key(day) in workdays(conn)


def due_slots(conn: sqlite3.Connection, now: datetime) -> list[sqlite3.Row]:
    """Slots whose time has passed today and that have not run yet.

    A slot missed while the server was down still fires when it comes back, as
    long as it is the same day — better a late brief than a silent one.
    """
    if not is_workday(conn, now.date()):
        return []
    today = now.date().isoformat()
    return db.all_rows(
        conn,
        """SELECT s.* FROM checkin_slots s
           WHERE s.active = 1 AND s.time <= ?
             AND NOT EXISTS (SELECT 1 FROM slot_runs r WHERE r.slot_id = s.id AND r.date = ?)
           ORDER BY s.time""",
        (now.strftime("%H:%M"), today),
    )


def minutes_late(slot: sqlite3.Row, now: datetime) -> int:
    hour, minute = (int(part) for part in slot["time"].split(":")[:2])
    due = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    return int((now - due).total_seconds() // 60)


def is_stale(slot: sqlite3.Row, now: datetime) -> bool:
    """True when the slot is so late that sending it would only be noise."""
    return minutes_late(slot, now) > GRACE_MINUTES.get(slot["kind"], 60)


def mark_slot_run(conn: sqlite3.Connection, slot_id: int, day: date, sent: int = 0) -> None:
    db.insert(conn, "slot_runs", slot_id=slot_id, date=day.isoformat(), sent=sent)


# ----------------------------------------------------------------- audiences
def employees(conn: sqlite3.Connection, location_id: int | None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1 AND role = 'employee'
           AND telegram_id IS NOT NULL AND (? IS NULL OR location_id = ?) ORDER BY name""",
        (location_id, location_id),
    )


def supervisors(conn: sqlite3.Connection, location_id: int | None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1 AND telegram_id IS NOT NULL
           AND (role = 'gm' OR (role = 'manager' AND (? IS NULL OR location_id = ?)))
           ORDER BY role""",
        (location_id, location_id),
    )


def on_leave(conn: sqlite3.Connection, user_id: int, day: date) -> bool:
    row = db.one(
        conn,
        "SELECT 1 FROM leaves WHERE user_id = ? AND from_date <= ? AND to_date >= ?",
        (user_id, day.isoformat(), day.isoformat()),
    )
    return row is not None


# ----------------------------------------------------------------- the messages
def _lines(rows: list[sqlite3.Row]) -> str:
    return "\n".join(texts.task_line(r) for r in rows)


def brief_for(conn: sqlite3.Connection, user: sqlite3.Row, now: datetime) -> str | None:
    """The 9:00 message for one employee. None when there is nothing to say."""
    open_rows = T.open_tasks_for(conn, user["id"])
    if not open_rows:
        return None
    stamp = now.strftime("%Y-%m-%d %H:%M")
    overdue = [r for r in open_rows if r["due_at"] and r["due_at"] < stamp]
    overdue_ids = {r["id"] for r in overdue}
    # a task appears once: overdue first, then waiting to be accepted, then the rest
    waiting = [r for r in open_rows if r["status"] == T.ASSIGNED and r["id"] not in overdue_ids]
    waiting_ids = {r["id"] for r in waiting}
    today_rows = [r for r in open_rows if r["id"] not in overdue_ids | waiting_ids]

    parts = [f"<b>صباح الخير {user['name']}</b> · {now.strftime('%Y-%m-%d')}"]
    if today_rows:
        parts += ["", f"<b>مهامك اليوم ({len(today_rows)})</b>", _lines(today_rows)]
    if overdue:
        parts += ["", f"<b>متأخرة ({len(overdue)})</b>", _lines(overdue)]
    if waiting:
        parts += ["", f"<b>بانتظار قبولك ({len(waiting)})</b>", _lines(waiting)]
    slots = db.all_rows(conn, "SELECT time FROM checkin_slots WHERE kind = 'update' AND active = 1 ORDER BY time")
    if slots:
        parts += ["", f"<i>تحديثات اليوم: {' · '.join(s['time'] for s in slots)}</i>"]
    return "\n".join(parts)


def manager_overview(conn: sqlite3.Connection, location_id: int | None, now: datetime) -> str:
    where = "1=1" if location_id is None else "t.location_id = ?"
    params = () if location_id is None else (location_id,)
    rows = db.all_rows(
        conn,
        f"""SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
            WHERE {where} AND t.status IN ('assigned','in_progress','handover','review','suggested')
            ORDER BY t.status, t.due_at""",
        params,
    )
    stamp = now.strftime("%Y-%m-%d %H:%M")
    overdue = [r for r in rows if r["due_at"] and r["due_at"] < stamp and r["status"] in
               (T.ASSIGNED, T.IN_PROGRESS)]
    unaccepted = [r for r in rows if r["status"] == T.ASSIGNED]
    review = [r for r in rows if r["status"] == T.REVIEW]
    suggestions = [r for r in rows if r["status"] == T.SUGGESTED]

    parts = [f"<b>موجز الفريق</b> · {now.strftime('%Y-%m-%d')}",
             f"مهام مفتوحة: {len(rows)}"]
    if unaccepted:
        parts += ["", f"<b>لم تُقبل بعد ({len(unaccepted)})</b>", _lines(unaccepted)]
    if overdue:
        parts += ["", f"<b>متأخرة ({len(overdue)})</b>", _lines(overdue)]
    if review:
        parts += ["", f"<b>بانتظار مراجعتك ({len(review)})</b>", _lines(review)]
    if suggestions:
        parts += ["", f"<b>اقتراحات بانتظار الموافقة ({len(suggestions)})</b>", _lines(suggestions)]

    absent = [u["name"] for u in employees(conn, location_id) if on_leave(conn, u["id"], now.date())]
    if absent:
        parts += ["", f"<b>في إجازة اليوم:</b> {'، '.join(absent)}"]
    return "\n".join(parts)


def update_items(conn: sqlite3.Connection, user: sqlite3.Row) -> list[sqlite3.Row]:
    """Tasks an employee is asked about at 10:00 / 12:00 / 2:00."""
    return [r for r in T.open_tasks_for(conn, user["id"]) if r["status"] in (T.ASSIGNED, T.IN_PROGRESS)]


def day_report(conn: sqlite3.Connection, location_id: int | None, now: datetime) -> str:
    where = "1=1" if location_id is None else "location_id = ?"
    params = () if location_id is None else (location_id,)
    today = now.date().isoformat()

    done = db.all_rows(conn, f"""SELECT t.*, u.name AS who FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
                                 WHERE t.{where} AND t.status = 'done' AND date(t.closed_at) = ?""",
                       (*params, today))
    review = db.all_rows(conn, f"SELECT * FROM tasks WHERE {where} AND status = 'review'", params)
    rejected = db.all_rows(conn, f"SELECT * FROM tasks WHERE {where} AND status = 'rejected'", params)
    overdue = db.all_rows(
        conn,
        f"""SELECT t.*, u.name AS who FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
            WHERE t.{where} AND t.due_at < ? AND t.status IN ('assigned','in_progress')""",
        (*params, now.strftime("%Y-%m-%d %H:%M")),
    )
    carried = db.all_rows(
        conn,
        f"""SELECT t.*, e.note, u.name AS who FROM task_events e JOIN tasks t ON t.id = e.task_id
            LEFT JOIN users u ON u.id = t.assignee_id
            WHERE e.action = 'carried_over' AND date(e.created_at) = ? AND t.{where}""",
        (today, *params),
    )
    silent = [u["name"] for u in employees(conn, location_id)
              if update_items(conn, u)
              and not db.one(conn, "SELECT 1 FROM checkins WHERE user_id = ? AND date = ? AND kind = 'closeout'",
                             (u["id"], today))]

    parts = [f"<b>تقرير نهاية اليوم</b> · {now.strftime('%Y-%m-%d')}"]
    parts += ["", f"<b>أُنجزت اليوم ({len(done)})</b>",
              "\n".join(f"• #{r['id']} {r['title']} — {r['who'] or ''}" for r in done) or "لا شيء"]
    if review:
        parts += ["", f"<b>بانتظار مراجعتك ({len(review)})</b>",
                  "\n".join(f"• #{r['id']} {r['title']}" for r in review)]
    if carried:
        parts += ["", f"<b>مرحّلة لغد ({len(carried)})</b>",
                  "\n".join(f"• #{r['id']} {r['who'] or ''}: {r['note']}" for r in carried)]
    if rejected:
        parts += ["", f"<b>مرفوضة ({len(rejected)})</b>",
                  "\n".join(f"• #{r['id']} {r['title']}" for r in rejected)]
    if overdue:
        parts += ["", f"<b>متأخرة ({len(overdue)})</b>",
                  "\n".join(f"• #{r['id']} {r['title']} — {r['who'] or ''}" for r in overdue)]
    if silent:
        parts += ["", f"<b>لم يرد على الإغلاق:</b> {'، '.join(silent)}"]
    return "\n".join(parts)


# ----------------------------------------------------------------- reminders
def _hours_since(stamp: str, now: datetime) -> float:
    try:
        when = datetime.strptime(stamp, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return 0.0
    return (now.replace(tzinfo=None) - when).total_seconds() / 3600


def _already(conn: sqlite3.Connection, task_id: int, action: str) -> bool:
    return db.one(conn, "SELECT 1 FROM task_events WHERE task_id = ? AND action = ?",
                  (task_id, action)) is not None


# Past this age a task is the manager's problem, not something to chase by message:
# it already shows in the 9:00 overview and on the board. Without this, switching
# the system on would fire a reminder for every old task at once.
STALE_HOURS = 48


def unaccepted_reminders(conn: sqlite3.Connection, now: datetime,
                         remind_after: int = 2, escalate_after: int = 4) -> list[tuple[sqlite3.Row, str]]:
    """Tasks sitting unaccepted: nudge the employee, then tell the manager. Once each."""
    out: list[tuple[sqlite3.Row, str]] = []
    for task in db.all_rows(conn, "SELECT * FROM tasks WHERE status = 'assigned'"):
        hours = _hours_since(task["created_at"], now)
        if hours > STALE_HOURS:
            continue
        if hours >= escalate_after and not _already(conn, task["id"], "accept_escalated"):
            out.append((task, "escalate"))
        elif hours >= remind_after and not _already(conn, task["id"], "accept_reminder"):
            out.append((task, "remind"))
    return out


def overdue_alerts(conn: sqlite3.Connection, now: datetime) -> list[sqlite3.Row]:
    """Tasks that passed their due time recently, flagged once each.

    Only the last STALE_HOURS are considered, so turning the scheduler on does
    not alert about everything that was ever late.
    """
    stamp = now.strftime("%Y-%m-%d %H:%M")
    floor = (now - timedelta(hours=STALE_HOURS)).strftime("%Y-%m-%d %H:%M")
    rows = db.all_rows(
        conn,
        """SELECT * FROM tasks WHERE due_at IS NOT NULL AND due_at < ? AND due_at >= ?
           AND status IN ('assigned','in_progress')""",
        (stamp, floor),
    )
    return [r for r in rows if not _already(conn, r["id"], "overdue_flagged")]


def record_checkin(conn: sqlite3.Connection, user_id: int, task_id: int | None, kind: str,
                   answer: str, note: str = "", now: datetime | None = None) -> int:
    now = now or texts.now()
    return db.insert(conn, "checkins", user_id=user_id, task_id=task_id, kind=kind,
                     date=now.date().isoformat(), answer=answer, note=note or None)


def tomorrow(now: datetime) -> datetime:
    return now + timedelta(days=1)
