"""Routines and their periods: who holds each one, and how it changes hands.

The weekly board (`period_schedule`) says who normally holds a period on each
weekday. Nothing ever rewrites it. A change for one date — a colleague covering,
a leave, a manager's decision — is an `period_overrides` row for that date only,
so next week goes back to the board on its own.

There is no backup: a period with nobody on it is a gap, red on the board, and
the manager fills it. An employee who cannot work a period asks a colleague to
cover, at least `swap_deadline_hours` before it starts; the colleague accepts
and then the branch manager approves. Both yeses, or nothing moves.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from .. import db, texts

WEEKDAY_KEYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")   # python's order
ALL_WEEKDAYS = ("sat", "sun", "mon", "tue", "wed", "thu", "fri")   # the shop's week
WEEKDAY_AR = {"sat": "السبت", "sun": "الأحد", "mon": "الاثنين", "tue": "الثلاثاء",
              "wed": "الأربعاء", "thu": "الخميس", "fri": "الجمعة"}
RESULTS = {"done": "تمت", "partly": "جزئياً", "not_done": "لم تتم", "nothing_today": "لا شيء اليوم"}
DEFAULT_DEADLINE_HOURS = 2


class RuleError(Exception):
    def __init__(self, ar: str, en: str = "") -> None:
        super().__init__(en or ar)
        self.ar, self.en = ar, en or ar


def _require(condition: bool, ar: str, en: str = "") -> None:
    if not condition:
        raise RuleError(ar, en)


@dataclass(frozen=True)
class Message:
    """One thing to say to one person. The caller queues it; the bot sends it."""
    user_id: int
    body: str
    keyboard: str = "none"


# ----------------------------------------------------------------- the calendar
def weekday_key(day: date) -> str:
    return WEEKDAY_KEYS[day.weekday()]


def runs_on(period: sqlite3.Row, day: date) -> bool:
    return weekday_key(day) in [part.strip() for part in period["days"].split(",")]


def _at(day: date, clock: str) -> datetime:
    hour, minute = (int(part) for part in clock.split(":"))
    return datetime.combine(day, time(hour, minute), tzinfo=texts.TZ)


def start_at(period: sqlite3.Row, day: date) -> datetime:
    return _at(day, period["start_time"])


def end_at(period: sqlite3.Row, day: date) -> datetime:
    return _at(day, period["end_time"])


def checkin_at(period: sqlite3.Row, day: date) -> datetime:
    return end_at(period, day) - timedelta(minutes=period["checkin_minutes_before_end"])


def label(period: sqlite3.Row, day: date | None = None) -> str:
    clock = f"{period['start_time']}–{period['end_time']}"
    if day is None:
        return f"{period['name']} ({clock})"
    return f"{WEEKDAY_AR[weekday_key(day)]} {day.isoformat()} · {period['name']} ({clock})"


def deadline_hours(conn: sqlite3.Connection) -> int:
    row = db.one(conn, "SELECT value FROM settings WHERE key = 'swap_deadline_hours'")
    try:
        return int(row["value"]) if row else DEFAULT_DEADLINE_HOURS
    except (TypeError, ValueError):
        return DEFAULT_DEADLINE_HOURS


# ----------------------------------------------------------------- who holds what
def get_period(conn: sqlite3.Connection, period_id: int) -> sqlite3.Row:
    row = db.one(
        conn,
        """SELECT p.*, r.code, r.name AS routine_name, r.count_label, r.location_id,
                  r.instructions
           FROM routine_periods p JOIN routines r ON r.id = p.routine_id WHERE p.id = ?""",
        (period_id,),
    )
    if row is None:
        raise RuleError("الفترة غير موجودة", "no such period")
    return row


def periods_for(conn: sqlite3.Connection, day: date,
                location_id: int | None = None) -> list[sqlite3.Row]:
    """Every active period that runs on this day, earliest first."""
    rows = db.all_rows(
        conn,
        """SELECT p.*, r.code, r.name AS routine_name, r.count_label, r.location_id, r.instructions
           FROM routine_periods p JOIN routines r ON r.id = p.routine_id
           WHERE r.active = 1 AND (? IS NULL OR r.location_id = ?)
           ORDER BY p.start_time, p.id""",
        (location_id, location_id),
    )
    return [row for row in rows if runs_on(row, day)]


def holder(conn: sqlite3.Connection, period_id: int, day: date) -> sqlite3.Row | None:
    """Who really holds this period on this date: the override if there is one, else the board."""
    override = db.one(
        conn, "SELECT user_id FROM period_overrides WHERE period_id = ? AND date = ?",
        (period_id, day.isoformat()))
    if override is not None:
        user_id = override["user_id"]
    else:
        booked = db.one(
            conn, "SELECT user_id FROM period_schedule WHERE period_id = ? AND weekday = ?",
            (period_id, weekday_key(day)))
        user_id = booked["user_id"] if booked else None
    if not user_id:
        return None
    return db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))


def board_holder(conn: sqlite3.Connection, period_id: int, day: date) -> int | None:
    """Who the weekly board says holds it — before any override for that date."""
    row = db.one(conn, "SELECT user_id FROM period_schedule WHERE period_id = ? AND weekday = ?",
                 (period_id, weekday_key(day)))
    return row["user_id"] if row else None


def day_board(conn: sqlite3.Connection, day: date,
              location_id: int | None = None) -> list[dict]:
    """One row per period today: the period, who holds it, and why it is not the board's choice."""
    out = []
    for period in periods_for(conn, day, location_id):
        who = holder(conn, period["id"], day)
        override = db.one(conn, "SELECT * FROM period_overrides WHERE period_id = ? AND date = ?",
                          (period["id"], day.isoformat()))
        out.append({"period": period, "holder": who,
                    "reason": override["reason"] if override else None,
                    "is_gap": who is None})
    return out


def gaps(conn: sqlite3.Connection, day: date, location_id: int | None = None) -> list[sqlite3.Row]:
    return [row["period"] for row in day_board(conn, day, location_id) if row["is_gap"]]


def my_periods(conn: sqlite3.Connection, user_id: int, start: date, days: int = 7) -> list[dict]:
    """A person's own periods over the next few days, in order."""
    user = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if user is None:
        return []
    out = []
    for offset in range(days):
        day = start + timedelta(days=offset)
        for period in periods_for(conn, day, user["location_id"]):
            who = holder(conn, period["id"], day)
            if who is not None and who["id"] == user_id:
                out.append({"period": period, "date": day, "start": start_at(period, day),
                            "end": end_at(period, day)})
    return out


DEFAULT_CHECKIN_TIME = "16:30"       # when a routine with no periods is asked


def routine_days(routine: sqlite3.Row) -> list[str]:
    return [part.strip() for part in (routine["days"] or "").split(",") if part.strip()]


def checkin_time(routine: sqlite3.Row) -> str:
    value = routine["checkin_time"] if "checkin_time" in routine.keys() else None
    return (value or "").strip() or DEFAULT_CHECKIN_TIME


def routines_for(conn: sqlite3.Connection, day: date,
                 location_id: int | None = None) -> list[sqlite3.Row]:
    """Active دورية routines that run on this weekday.

    The other two kinds — روتينية and مجدولة — become tasks instead of being
    asked about daily, so they are not here.
    """
    rows = db.all_rows(
        conn,
        """SELECT * FROM routines WHERE active = 1 AND (? IS NULL OR location_id = ?)
           AND COALESCE(kind, 'periodic') = 'periodic' ORDER BY code""",
        (location_id, location_id),
    )
    return [row for row in rows if weekday_key(day) in routine_days(row)]


def has_periods(conn: sqlite3.Connection, routine_id: int) -> bool:
    return db.one(conn, "SELECT 1 FROM routine_periods WHERE routine_id = ?",
                  (routine_id,)) is not None


def owners_of(conn: sqlite3.Connection, routine_id: int, role: str | None = None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT u.*, o.role AS owner_role FROM routine_owners o JOIN users u ON u.id = o.user_id
           WHERE o.routine_id = ? AND u.active = 1 AND (? IS NULL OR o.role = ?) ORDER BY o.role, u.name""",
        (routine_id, role, role),
    )


def routine_rota(conn: sqlite3.Connection, routine_id: int) -> dict[str, list[sqlite3.Row]]:
    """Who is on this routine each weekday. A day may take two people, or none."""
    out: dict[str, list[sqlite3.Row]] = {day: [] for day in ALL_WEEKDAYS}
    for row in db.all_rows(
            conn,
            """SELECT s.weekday, u.* FROM routine_schedule s JOIN users u ON u.id = s.user_id
               WHERE s.routine_id = ? AND u.active = 1 ORDER BY u.name""",
            (routine_id,)):
        out[row["weekday"]].append(row)
    return out


def set_routine_rota(conn: sqlite3.Connection, routine_id: int,
                     rota: dict[str, list[int]]) -> None:
    """Replace the whole weekly rota in one go, the way the page submits it."""
    conn.execute("DELETE FROM routine_schedule WHERE routine_id = ?", (routine_id,))
    for weekday, ids in rota.items():
        if weekday not in ALL_WEEKDAYS:
            continue
        for user_id in _ids(ids):
            db.insert(conn, "routine_schedule", routine_id=routine_id, weekday=weekday,
                      user_id=user_id)


def on_duty(conn: sqlite3.Connection, routine: sqlite3.Row, day: date) -> list[sqlite3.Row]:
    """Who is asked about this routine on this date.

    The weekly rota decides — تجهيز الطلبات and فحص الطلبات move around the team.
    A routine with no rota falls back to its fixed owners, which is how the
    one-person routines work.
    """
    rostered = db.all_rows(
        conn,
        """SELECT u.* FROM routine_schedule s JOIN users u ON u.id = s.user_id
           WHERE s.routine_id = ? AND s.weekday = ? AND u.active = 1 ORDER BY u.name""",
        (routine["id"], weekday_key(day)))
    if rostered:
        return rostered
    if db.one(conn, "SELECT 1 FROM routine_schedule WHERE routine_id = ?", (routine["id"],)):
        return []                       # it has a rota and nobody is on today — a gap, not the owners
    return owners_of(conn, routine["id"], "owner")


def has_rota(conn: sqlite3.Connection, routine_id: int) -> bool:
    return db.one(conn, "SELECT 1 FROM routine_schedule WHERE routine_id = ?",
                  (routine_id,)) is not None


def routines_of(conn: sqlite3.Connection, user_id: int) -> list[sqlite3.Row]:
    """Routines this person owns outright, or is on the weekly rota for."""
    return db.all_rows(
        conn,
        """SELECT r.*, MIN(o.role) AS owner_role,
                  GROUP_CONCAT(DISTINCT s.weekday) AS rota_days
           FROM routines r
                LEFT JOIN routine_owners o ON o.routine_id = r.id AND o.user_id = ?
                LEFT JOIN routine_schedule s ON s.routine_id = r.id AND s.user_id = ?
           WHERE r.active = 1 AND (o.id IS NOT NULL OR s.id IS NOT NULL)
           GROUP BY r.id ORDER BY r.code""",
        (user_id, user_id),
    )


# ----------------------------------------------------------------- the period log
def log_period(conn: sqlite3.Connection, user_id: int, period_id: int, day: date,
               result: str, *, count: int | None = None, note: str = "") -> int:
    _require(result in RESULTS, "نتيجة غير معروفة", "unknown result")
    period = get_period(conn, period_id)
    board = board_holder(conn, period_id, day)
    existing = db.one(
        conn, "SELECT id FROM routine_logs WHERE period_id = ? AND date = ? AND user_id = ?",
        (period_id, day.isoformat(), user_id))
    fields = dict(result=result, count=count, note=note.strip() or None,
                  covering_for=board if board and board != user_id else None)
    if existing:                                   # answering again replaces the answer
        db.update(conn, "routine_logs", existing["id"], **fields)
        return existing["id"]
    return db.insert(conn, "routine_logs", routine_id=period["routine_id"], period_id=period_id,
                     user_id=user_id, date=day.isoformat(), **fields)


def log_routine(conn: sqlite3.Connection, user_id: int, routine_id: int, day: date,
                result: str, *, count: int | None = None, note: str = "") -> int:
    """The same answer, for a routine that has no periods (R2–R7)."""
    _require(result in RESULTS, "نتيجة غير معروفة", "unknown result")
    existing = db.one(
        conn,
        """SELECT id FROM routine_logs WHERE routine_id = ? AND date = ? AND user_id = ?
           AND period_id IS NULL""",
        (routine_id, day.isoformat(), user_id))
    fields = dict(result=result, count=count, note=note.strip() or None)
    if existing:
        db.update(conn, "routine_logs", existing["id"], **fields)
        return existing["id"]
    return db.insert(conn, "routine_logs", routine_id=routine_id, period_id=None,
                     user_id=user_id, date=day.isoformat(), **fields)


def duties_today(conn: sqlite3.Connection, user_id: int, now: datetime) -> list[dict]:
    """What this person owes the system today — periods and routines — and where each stands.

    This is the honest answer to "did the routine happen?": a routine nobody is
    due to answer until 16:30 is waiting, not missing.
    """
    day = now.date()
    person = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if person is None:
        return []
    answers = {(row["period_id"], row["routine_id"]): row for row in db.all_rows(
        conn, "SELECT * FROM routine_logs WHERE user_id = ? AND date = ?",
        (user_id, day.isoformat()))}
    out = []

    for entry in my_periods(conn, user_id, day, days=1):
        period = entry["period"]
        answer = answers.get((period["id"], period["routine_id"]))
        out.append({
            "label": f"{period['code']} · {period['name']} "
                     f"{period['start_time']}–{period['end_time']}",
            "due": checkin_at(period, day), "answer": answer,
            "state": _duty_state(answer, checkin_at(period, day), now),
        })

    for routine in routines_for(conn, day, person["location_id"]):
        if has_periods(conn, routine["id"]):
            continue
        if user_id not in {p["id"] for p in on_duty(conn, routine, day)}:
            continue
        answer = answers.get((None, routine["id"]))
        due = _at(day, checkin_time(routine))
        out.append({"label": f"{routine['code']} · {routine['name']}", "due": due,
                    "answer": answer, "state": _duty_state(answer, due, now)})
    return sorted(out, key=lambda item: item["due"])


def _duty_state(answer: sqlite3.Row | None, due: datetime, now: datetime) -> str:
    if answer is not None:
        return answer["result"]
    return "late" if due <= now else "waiting"


DUTY_STATE_AR = {"waiting": "لم يحن وقته", "late": "بانتظار الرد", **RESULTS}


def logs_for(conn: sqlite3.Connection, day: date, location_id: int | None = None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT g.*, u.name AS who, p.name AS period_name, p.start_time, p.end_time,
                  r.code, r.name AS routine_name, c.name AS covering_name
           FROM routine_logs g JOIN routines r ON r.id = g.routine_id
                JOIN users u ON u.id = g.user_id
                LEFT JOIN routine_periods p ON p.id = g.period_id
                LEFT JOIN users c ON c.id = g.covering_for
           WHERE g.date = ? AND (? IS NULL OR r.location_id = ?)
           ORDER BY p.start_time, g.id""",
        (day.isoformat(), location_id, location_id),
    )


# ----------------------------------------------------------------- asking a colleague to cover
def _colleagues(conn: sqlite3.Connection, user: sqlite3.Row) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1 AND role = 'employee' AND id != ?
           AND location_id = ? AND telegram_id IS NOT NULL ORDER BY name""",
        (user["id"], user["location_id"]),
    )


def can_cover(conn: sqlite3.Connection, user_id: int, period_id: int, day: date) -> bool:
    """False when that person already holds an overlapping period that day."""
    period = get_period(conn, period_id)
    start, end = start_at(period, day), end_at(period, day)
    for mine in my_periods(conn, user_id, day, days=1):
        if mine["start"] < end and start < mine["end"]:
            return False
    return True


def cover_candidates(conn: sqlite3.Connection, user: sqlite3.Row, period_id: int,
                     day: date) -> list[sqlite3.Row]:
    return [person for person in _colleagues(conn, user)
            if can_cover(conn, person["id"], period_id, day)]


def get_request(conn: sqlite3.Connection, request_id: int) -> sqlite3.Row:
    row = db.one(
        conn,
        """SELECT s.*, f.name AS from_name, t.name AS to_name, f.location_id
           FROM swap_requests s JOIN users f ON f.id = s.from_user JOIN users t ON t.id = s.to_user
           WHERE s.id = ?""",
        (request_id,),
    )
    if row is None:
        raise RuleError("الطلب غير موجود", "no such request")
    return row


def request_cover(conn: sqlite3.Connection, actor_id: int, period_id: int, day: date,
                  to_user_id: int, reason: str, *, now: datetime | None = None
                  ) -> tuple[int, list[Message]]:
    """Step 1 of 3: the holder asks a colleague to take this one date."""
    now = now or texts.now()
    period = get_period(conn, period_id)
    current = holder(conn, period_id, day)
    _require(current is not None and current["id"] == actor_id,
             "هذه الفترة ليست لك في هذا اليوم", "not your period")
    _require(to_user_id != actor_id, "اختر زميلاً آخر", "pick someone else")
    target = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (to_user_id,))
    _require(target is not None, "الزميل غير موجود", "no such colleague")
    _require(target["location_id"] == current["location_id"], "اختر زميلاً من فرعك", "same branch only")

    hours = deadline_hours(conn)
    _require(start_at(period, day) - now >= timedelta(hours=hours),
             f"طلب التبديل قبل {hours} ساعتين على الأقل من بداية الفترة",
             f"at least {hours}h before the period starts")
    _require(can_cover(conn, to_user_id, period_id, day),
             "زميلك يعمل فترة أخرى في نفس الوقت", "the colleague is busy then")
    open_already = db.one(
        conn,
        """SELECT id FROM swap_requests WHERE period_id = ? AND date = ?
           AND status IN ('awaiting_colleague','awaiting_manager')""",
        (period_id, day.isoformat()))
    _require(open_already is None, "يوجد طلب معلّق لهذه الفترة", "a request is already open")

    request_id = db.insert(conn, "swap_requests", period_id=period_id, date=day.isoformat(),
                           from_user=actor_id, to_user=to_user_id, kind="cover",
                           reason=reason.strip() or None, status="awaiting_colleague",
                           created_at=now.strftime("%Y-%m-%d %H:%M:%S"))
    body = (f"🔁 <b>طلب تغطية فترة</b>\n{label(period, day)}\n"
            f"من: {current['name']}\n" + (f"السبب: {reason.strip()}\n" if reason.strip() else "") +
            "هل تستطيع تغطيتها؟")
    return request_id, [Message(to_user_id, body, f"cover:{request_id}")]


def managers_of(conn: sqlite3.Connection, location_id: int) -> list[sqlite3.Row]:
    """The branch manager and the GM — who hears about a gap or approves a cover."""
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1
           AND (role = 'gm' OR (role = 'manager' AND location_id = ?))""",
        (location_id,),
    )


def colleague_accepts(conn: sqlite3.Connection, actor_id: int, request_id: int) -> list[Message]:
    """Step 2 of 3. The board does not move yet — the manager still has to approve."""
    request = get_request(conn, request_id)
    _require(request["to_user"] == actor_id, "الطلب ليس موجهاً إليك", "not your request")
    _require(request["status"] == "awaiting_colleague", "لم يعد الطلب بانتظار ردك", "already answered")
    db.update(conn, "swap_requests", request_id, colleague_decision="accepted",
              status="awaiting_manager")
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    body = (f"🔁 <b>طلب تغطية بانتظار موافقتك</b>\n{label(period, day)}\n"
            f"{request['from_name']} ← {request['to_name']}\n"
            + (f"السبب: {request['reason']}\n" if request["reason"] else "")
            + f"وافق {request['to_name']} على التغطية.")
    out = [Message(m["id"], body, f"cover:{request_id}") for m in managers_of(conn, request["location_id"])]
    out.append(Message(request["from_user"],
                       f"✅ وافق {request['to_name']} على تغطية {label(period, day)}.\n"
                       "بانتظار موافقة مدير الفرع."))
    return out


def colleague_declines(conn: sqlite3.Connection, actor_id: int, request_id: int,
                       reason: str = "") -> list[Message]:
    request = get_request(conn, request_id)
    _require(request["to_user"] == actor_id, "الطلب ليس موجهاً إليك", "not your request")
    _require(request["status"] == "awaiting_colleague", "لم يعد الطلب بانتظار ردك", "already answered")
    db.update(conn, "swap_requests", request_id, colleague_decision="declined", status="declined")
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    note = f"\nالسبب: {reason.strip()}" if reason.strip() else ""
    return [Message(request["from_user"],
                    f"❌ اعتذر {request['to_name']} عن تغطية {label(period, day)}.{note}\n"
                    "الفترة ما زالت لك — جرّب زميلاً آخر أو تحدّث مع المدير.")]


def manager_approves(conn: sqlite3.Connection, actor_id: int, request_id: int) -> list[Message]:
    """Step 3 of 3 — only now does the period change hands, and only for that date."""
    actor = db.one(conn, "SELECT * FROM users WHERE id = ?", (actor_id,))
    request = get_request(conn, request_id)
    _require(actor is not None and (actor["role"] == "gm" or
             (actor["role"] == "manager" and actor["location_id"] == request["location_id"])),
             "الموافقة للمدير فقط", "manager only")
    _require(request["status"] == "awaiting_manager", "الطلب ليس بانتظار موافقتك", "not awaiting you")
    db.update(conn, "swap_requests", request_id, manager_decision="approved", status="approved")
    set_holder(conn, request["period_id"], date.fromisoformat(request["date"]),
               request["to_user"], reason="swap", actor_id=actor_id, swap_request_id=request_id)
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    return [
        Message(request["to_user"], f"✅ اعتُمدت التغطية. {label(period, day)} لك.\n"
                                    f"بدلاً عن {request['from_name']}."),
        Message(request["from_user"], f"✅ اعتُمد طلبك. {label(period, day)} يغطيها "
                                      f"{request['to_name']}."),
    ]


def manager_declines(conn: sqlite3.Connection, actor_id: int, request_id: int,
                     reason: str = "") -> list[Message]:
    actor = db.one(conn, "SELECT * FROM users WHERE id = ?", (actor_id,))
    request = get_request(conn, request_id)
    _require(actor is not None and (actor["role"] == "gm" or
             (actor["role"] == "manager" and actor["location_id"] == request["location_id"])),
             "الرفض للمدير فقط", "manager only")
    _require(request["status"] in ("awaiting_manager", "awaiting_colleague"),
             "الطلب محسوم", "already settled")
    db.update(conn, "swap_requests", request_id, manager_decision="declined", status="declined")
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    note = f"\nالسبب: {reason.strip()}" if reason.strip() else ""
    body = f"❌ لم يوافق المدير على تغطية {label(period, day)}.{note}"
    return [Message(request["from_user"], body + "\nالفترة ما زالت لك."),
            Message(request["to_user"], body)]


def expire_requests(conn: sqlite3.Connection, now: datetime) -> list[Message]:
    """A request nobody answered before the period started is dead — say so once."""
    out: list[Message] = []
    for request in db.all_rows(
            conn, """SELECT s.*, t.name AS to_name FROM swap_requests s JOIN users t ON t.id = s.to_user
                     WHERE s.status IN ('awaiting_colleague','awaiting_manager')"""):
        period = get_period(conn, request["period_id"])
        day = date.fromisoformat(request["date"])
        if start_at(period, day) <= now:
            db.update(conn, "swap_requests", request["id"], status="expired")
            out.append(Message(request["from_user"],
                               f"⌛ انتهى وقت طلب تغطية {label(period, day)} دون حسم. الفترة لك."))
    return out


# ----------------------------------------------------------------- what the clock owes today
CHECKIN_GRACE_MINUTES = 90          # a check-in asked two hours late is only noise
GAP_GRACE_MINUTES = 120


def has_run(conn: sqlite3.Connection, period_id: int, day: date, kind: str) -> bool:
    return db.one(conn, "SELECT 1 FROM period_runs WHERE period_id = ? AND date = ? AND kind = ?",
                  (period_id, day.isoformat(), kind)) is not None


def mark_run(conn: sqlite3.Connection, period_id: int, day: date, kind: str, sent: int = 0) -> None:
    db.insert(conn, "period_runs", period_id=period_id, date=day.isoformat(), kind=kind, sent=sent)


def due_checkins(conn: sqlite3.Connection, now: datetime) -> list[dict]:
    """Periods whose check-in moment has passed today and that have not been asked yet."""
    day = now.date()
    out = []
    for period in periods_for(conn, day):
        if has_run(conn, period["id"], day, "checkin"):
            continue
        moment = checkin_at(period, day)
        if moment > now:
            continue
        out.append({"period": period, "date": day, "holder": holder(conn, period["id"], day),
                    "late": (now - moment).total_seconds() / 60 > CHECKIN_GRACE_MINUTES})
    return out


def due_gaps(conn: sqlite3.Connection, now: datetime) -> list[dict]:
    """Periods that have started today with nobody on them — the manager needs to know once."""
    day = now.date()
    out = []
    for period in periods_for(conn, day):
        if has_run(conn, period["id"], day, "gap") or holder(conn, period["id"], day) is not None:
            continue
        started = start_at(period, day)
        if started > now:
            continue
        out.append({"period": period, "date": day,
                    "late": (now - started).total_seconds() / 60 > GAP_GRACE_MINUTES})
    return out


def checkin_message(conn: sqlite3.Connection, period: sqlite3.Row, day: date,
                    person: sqlite3.Row) -> Message:
    board = board_holder(conn, period["id"], day)
    covering = ""
    if board and board != person["id"]:
        other = db.one(conn, "SELECT name FROM users WHERE id = ?", (board,))
        covering = f"\nتغطية بدلاً عن {other['name']}" if other else ""
    ask = "كيف سارت الفترة؟"
    if period["count_label"]:
        # the label is whatever the routine calls its count, so it is quoted, not inflected
        ask += f"\n<i>سيُطلب العدد: {period['count_label']}</i>"
    body = (f"⏰ <b>نهاية فترة {period['name']}</b>\n"
            f"{period['code']} · {period['routine_name']}\n"
            f"{period['start_time']}–{period['end_time']}{covering}\n\n{ask}")
    return Message(person["id"], body, f"pck:{period['id']}:{day.isoformat()}")


def routine_has_run(conn: sqlite3.Connection, routine_id: int, day: date) -> bool:
    return db.one(conn, "SELECT 1 FROM routine_runs WHERE routine_id = ? AND date = ?",
                  (routine_id, day.isoformat())) is not None


def mark_routine_run(conn: sqlite3.Connection, routine_id: int, day: date, sent: int = 0) -> None:
    db.insert(conn, "routine_runs", routine_id=routine_id, date=day.isoformat(),
              kind="checkin", sent=sent)


def due_routine_checkins(conn: sqlite3.Connection, now: datetime) -> list[dict]:
    """Routines with no periods whose daily question is due — one ask per routine per day."""
    day = now.date()
    out = []
    for routine in routines_for(conn, day):
        if has_periods(conn, routine["id"]) or routine_has_run(conn, routine["id"], day):
            continue
        moment = _at(day, checkin_time(routine))
        if moment > now:
            continue
        out.append({"routine": routine, "date": day,
                    "owners": on_duty(conn, routine, day),
                    "late": (now - moment).total_seconds() / 60 > CHECKIN_GRACE_MINUTES})
    return out


def routine_checkin_message(routine: sqlite3.Row, day: date, person: sqlite3.Row) -> Message:
    body = (f"📋 <b>روتين اليوم</b>\n{routine['code']} · {routine['name']}\n"
            f"{WEEKDAY_AR[weekday_key(day)]} {day.isoformat()}\n\nكيف سار اليوم؟")
    if routine["count_label"]:
        body += f"\n<i>سيُطلب العدد: {routine['count_label']}</i>"
    return Message(person["id"], body, f"rck:{routine['id']}:{day.isoformat()}")


def ownerless_message(conn: sqlite3.Connection, routine: sqlite3.Row) -> list[Message]:
    body = (f"🔴 <b>روتين بلا مسؤول</b>\n{routine['code']} · {routine['name']}\n"
            "عيّن مسؤولاً من صفحة المهام الروتينية.")
    return [Message(m["id"], body) for m in managers_of(conn, routine["location_id"])]


def gap_message(conn: sqlite3.Connection, period: sqlite3.Row, day: date) -> list[Message]:
    body = (f"🔴 <b>فترة بلا مسؤول</b>\n{label(period, day)}\n"
            f"{period['code']} · {period['routine_name']}\n"
            "عيّن شخصاً من لوحة الفترات.")
    return [Message(m["id"], body) for m in managers_of(conn, period["location_id"])]


# ----------------------------------------------------------------- the board and leaves
def set_holder(conn: sqlite3.Connection, period_id: int, day: date, user_id: int | None, *,
               reason: str = "manager", actor_id: int | None = None,
               swap_request_id: int | None = None) -> None:
    """Change who holds a period on one date. The weekly board is never touched."""
    _require(reason in ("swap", "leave", "absence", "manager"), "سبب غير معروف", "unknown reason")
    existing = db.one(conn, "SELECT id FROM period_overrides WHERE period_id = ? AND date = ?",
                      (period_id, day.isoformat()))
    fields = dict(user_id=user_id, reason=reason, created_by=actor_id,
                  swap_request_id=swap_request_id)
    if existing:
        db.update(conn, "period_overrides", existing["id"], **fields)
    else:
        db.insert(conn, "period_overrides", period_id=period_id, date=day.isoformat(), **fields)


def clear_holder(conn: sqlite3.Connection, period_id: int, day: date) -> None:
    """Drop the override so the weekly board applies again."""
    conn.execute("DELETE FROM period_overrides WHERE period_id = ? AND date = ?",
                 (period_id, day.isoformat()))


def days_between(start: date, end: date) -> list[date]:
    return [start + timedelta(days=offset) for offset in range((end - start).days + 1)]


def periods_during_leave(conn: sqlite3.Connection, user_id: int, start: date,
                         end: date) -> list[dict]:
    """Every period that person is due to hold while away — what the manager must cover."""
    out = []
    for day in days_between(start, end):
        for entry in my_periods(conn, user_id, day, days=1):
            out.append(entry)
    return out


def record_leave(conn: sqlite3.Connection, actor_id: int, user_id: int, start: date, end: date, *,
                 kind: str = "leave", cover: dict[tuple[int, str], int] | None = None,
                 hours: tuple[str, str] | None = None) -> tuple[int, list[Message]]:
    """Record a leave and, for each period it touches, who covers it (or leave it a gap).

    With `hours` it is a part-day leave — the two-hour kind. The person is still at
    work that day, so nothing is taken off their board; it is recorded and announced.
    """
    actor = db.one(conn, "SELECT * FROM users WHERE id = ?", (actor_id,))
    person = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))
    _require(person is not None, "الموظف غير موجود", "no such person")
    _require(actor is not None and actor["role"] in ("gm", "manager"),
             "تسجيل الإجازات للمدراء", "managers only")
    _require(end >= start, "تاريخ النهاية قبل البداية", "end before start")
    _require(kind in ("leave", "absent"), "نوع غير معروف", "unknown kind")

    from_time = to_time = None
    if hours:
        from_time, to_time = _clean_time(hours[0]), _clean_time(hours[1])
        _require(bool(from_time) and bool(to_time), "اكتب وقت البداية والنهاية", "times required")
        _require(from_time < to_time, "وقت النهاية قبل البداية", "end before start")
        _require(start == end, "الإجازة الساعية ليوم واحد", "a part-day leave is one day")

    leave_id = db.insert(conn, "leaves", user_id=user_id, from_date=start.isoformat(),
                         to_date=end.isoformat(), kind=kind, created_by=actor_id,
                         from_time=from_time, to_time=to_time)
    if from_time:                       # a couple of hours away: the board is left alone
        span = f"{start.isoformat()} من {from_time} إلى {to_time}"
        told = [Message(user_id, f"📅 سُجّلت لك إجازة ساعية: {span}.")]
        told += [Message(m["id"], f"📅 <b>إجازة ساعية</b>\n{person['name']} · {span}")
                 for m in managers_of(conn, person["location_id"]) if m["id"] != actor_id]
        return leave_id, told

    cover = cover or {}
    messages: list[Message] = []
    gap_list: list[str] = []
    for entry in periods_during_leave(conn, user_id, start, end):
        period, day = entry["period"], entry["date"]
        cover_id = cover.get((period["id"], day.isoformat()))
        set_holder(conn, period["id"], day, cover_id, reason="leave", actor_id=actor_id)
        if cover_id:
            db.insert(conn, "coverages", leave_id=leave_id, routine_id=period["routine_id"],
                      period_id=period["id"], cover_user_id=cover_id)
            messages.append(Message(cover_id,
                                    f"📅 <b>تغطية بدل إجازة</b>\n{label(period, day)}\n"
                                    f"بدلاً عن {person['name']}."))
        else:
            gap_list.append(label(period, day))

    span = start.isoformat() if start == end else f"{start.isoformat()} إلى {end.isoformat()}"
    word = "إجازة" if kind == "leave" else "غياب"
    messages.append(Message(user_id, f"📅 سُجّلت {word} لك: {span}."))
    if gap_list:
        warning = (f"⚠️ <b>فترات بلا مسؤول</b> بسبب {word} {person['name']}:\n"
                   + "\n".join(f"• {item}" for item in gap_list))
        messages += [Message(m["id"], warning) for m in managers_of(conn, person["location_id"])
                     if m["id"] != actor_id]
    return leave_id, messages


# ----------------------------------------------------------------- managing routines
def _clean_days(days) -> str:
    """Accepts a list of codes or the stored comma string, and keeps the week's order."""
    if isinstance(days, str):
        days = [part.strip() for part in days.split(",")]
    chosen = [d for d in ALL_WEEKDAYS if d in {str(d).strip() for d in (days or ())}]
    _require(bool(chosen), "اختر يوماً واحداً على الأقل", "pick at least one day")
    return ",".join(chosen)


def _clean_time(value: str | None, fallback: str = "") -> str:
    value = (value or "").strip()
    if not value:
        return fallback
    try:
        hour, minute = (int(part) for part in value.split(":"))
        _require(0 <= hour <= 23 and 0 <= minute <= 59, "وقت غير صحيح", "bad time")
    except ValueError:
        raise RuleError("اكتب الوقت بالشكل 16:30", "bad time")
    return f"{hour:02d}:{minute:02d}"


def create_routine(conn: sqlite3.Connection, actor: sqlite3.Row, *, code: str, name: str,
                   days, instructions: str = "", count_label: str = "",
                   checkin: str = "", location_id: int | None = None) -> int:
    _require(actor["role"] in ("gm", "manager"), "إنشاء الروتين للمدراء", "managers only")
    _require(bool(code.strip()) and bool(name.strip()), "الرمز والاسم مطلوبان", "code and name required")
    where = location_id or actor["location_id"]
    taken = db.one(conn, "SELECT 1 FROM routines WHERE code = ? AND location_id = ? AND active = 1",
                   (code.strip(), where))
    _require(taken is None, f"الرمز {code.strip()} مستخدم في هذا الفرع", "code already used")
    return db.insert(conn, "routines", code=code.strip(), name=name.strip(),
                     instructions=instructions.strip(), days=_clean_days(days),
                     count_label=count_label.strip() or None, location_id=where,
                     checkin_time=_clean_time(checkin, DEFAULT_CHECKIN_TIME))


def update_routine(conn: sqlite3.Connection, routine_id: int, *, name: str, days,
                   instructions: str = "", count_label: str = "", checkin: str = "") -> None:
    _require(bool(name.strip()), "الاسم مطلوب", "name required")
    db.update(conn, "routines", routine_id, name=name.strip(), days=_clean_days(days),
              instructions=instructions.strip(), count_label=count_label.strip() or None,
              checkin_time=_clean_time(checkin, DEFAULT_CHECKIN_TIME))


def retire_routine(conn: sqlite3.Connection, routine_id: int, active: bool = False) -> None:
    """Switched off, never deleted — the logs behind it stay readable."""
    db.update(conn, "routines", routine_id, active=1 if active else 0)


def _ids(values) -> list[int]:
    """Form values to user ids, dropping the empty ones — "0" means nobody picked."""
    out = []
    for value in values or ():
        text = str(value).strip()
        if text.isdigit() and int(text):
            out.append(int(text))
    return list(dict.fromkeys(out))


def set_owners(conn: sqlite3.Connection, routine_id: int, owner_ids, backup_ids=()) -> None:
    conn.execute("DELETE FROM routine_owners WHERE routine_id = ?", (routine_id,))
    for role, ids in (("owner", owner_ids), ("backup", backup_ids)):
        for user_id in _ids(ids):
            db.insert(conn, "routine_owners", routine_id=routine_id, user_id=user_id, role=role)


def add_period(conn: sqlite3.Connection, routine_id: int, *, name: str, days,
               start: str, end: str, minutes_before: int = 15) -> int:
    _require(bool(name.strip()), "اسم الفترة مطلوب", "name required")
    start, end = _clean_time(start), _clean_time(end)
    _require(bool(start) and bool(end), "وقت البداية والنهاية مطلوبان", "times required")
    _require(start < end, "وقت النهاية قبل البداية", "end before start")
    return db.insert(conn, "routine_periods", routine_id=routine_id, name=name.strip(),
                     days=_clean_days(days), start_time=start, end_time=end,
                     checkin_minutes_before_end=max(0, min(int(minutes_before), 120)))


def remove_period(conn: sqlite3.Connection, period_id: int) -> None:
    """Only a period nothing has happened on yet can go; otherwise it would orphan its log."""
    used = db.one(conn, "SELECT 1 FROM routine_logs WHERE period_id = ?", (period_id,))
    _require(used is None, "لا يمكن حذف فترة لها سجل — عدّل أوقاتها بدلاً من ذلك",
             "the period has history")
    for table in ("period_schedule", "period_overrides", "period_runs"):
        conn.execute(f"DELETE FROM {table} WHERE period_id = ?", (period_id,))
    conn.execute("DELETE FROM swap_requests WHERE period_id = ?", (period_id,))
    conn.execute("DELETE FROM routine_periods WHERE id = ?", (period_id,))


def fixed_day_off(user: sqlite3.Row | None) -> str:
    """The one weekday this person always has off, agreed with the GM."""
    if user is None or "weekly_day_off" not in user.keys():
        return ""
    value = (user["weekly_day_off"] or "").strip()
    return value if value in ALL_WEEKDAYS else ""


def set_fixed_day_off(conn: sqlite3.Connection, user_id: int, weekday: str) -> None:
    weekday = (weekday or "").strip()
    _require(weekday in ALL_WEEKDAYS or weekday == "", "يوم غير معروف", "unknown weekday")
    db.update(conn, "users", user_id, weekly_day_off=weekday or None)


def is_off(conn: sqlite3.Connection, user_id: int, day: date) -> bool:
    """Off for the whole day, for any reason — the one question the clock asks."""
    return on_leave(conn, user_id, day) is not None


def on_leave(conn: sqlite3.Connection, user_id: int, day: date) -> sqlite3.Row | None:
    """A whole day away — the fixed weekly day off, a recorded leave, or a ticked box.

    A two-hour leave is not this: the person is still at work that day and still
    gets their brief and their check-ins.
    """
    person = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if fixed_day_off(person) == weekday_key(day):
        return person                       # the same weekday, every week
    whole_day = db.one(
        conn,
        """SELECT * FROM leaves WHERE user_id = ? AND from_date <= ? AND to_date >= ?
           AND (from_time IS NULL OR from_time = '')""",
        (user_id, day.isoformat(), day.isoformat()))
    if whole_day is not None:
        return whole_day
    return db.one(conn, "SELECT * FROM days_off WHERE user_id = ? AND date = ?",
                  (user_id, day.isoformat()))


def part_day_leaves(conn: sqlite3.Connection, day: date,
                    location_id: int | None = None) -> list[sqlite3.Row]:
    """The two-hour kind: still at work, just away for part of the day."""
    return db.all_rows(
        conn,
        """SELECT l.*, u.name AS who FROM leaves l JOIN users u ON u.id = l.user_id
           WHERE l.from_date <= ? AND l.to_date >= ? AND l.from_time IS NOT NULL
             AND l.from_time != '' AND (? IS NULL OR u.location_id = ?)
           ORDER BY l.from_time""",
        (day.isoformat(), day.isoformat(), location_id, location_id),
    )


def set_day_off(conn: sqlite3.Connection, actor_id: int, user_id: int, day: date,
                off: bool) -> None:
    """One cell of the weekly grid."""
    if off:
        existing = db.one(conn, "SELECT id FROM days_off WHERE user_id = ? AND date = ?",
                          (user_id, day.isoformat()))
        if existing is None:
            db.insert(conn, "days_off", user_id=user_id, date=day.isoformat(), created_by=actor_id)
    else:
        conn.execute("DELETE FROM days_off WHERE user_id = ? AND date = ?",
                     (user_id, day.isoformat()))


def week_marks(conn: sqlite3.Connection, days: list[date],
               location_id: int | None = None) -> dict[tuple[int, str], dict]:
    """What to draw in each cell of the weekly grid: off, leave, or a two-hour leave."""
    if not days:
        return {}
    first, last = days[0].isoformat(), days[-1].isoformat()
    marks: dict[tuple[int, str], dict] = {}
    for person in db.all_rows(
            conn,
            """SELECT * FROM users WHERE active = 1 AND (? IS NULL OR location_id = ?)""",
            (location_id, location_id)):
        fixed = fixed_day_off(person)
        for day in days:
            if fixed and weekday_key(day) == fixed:
                marks[(person["id"], day.isoformat())] = {
                    "kind": "fixed", "label": "عطلة ثابتة", "id": None}
    for row in db.all_rows(
            conn, "SELECT * FROM days_off WHERE date BETWEEN ? AND ?", (first, last)):
        marks[(row["user_id"], row["date"])] = {"kind": "off", "label": "عطلة", "id": row["id"]}
    for leave in db.all_rows(
            conn, "SELECT * FROM leaves WHERE to_date >= ? AND from_date <= ?", (first, last)):
        part = (leave["from_time"] or "").strip()
        for day in days:
            if leave["from_date"] <= day.isoformat() <= leave["to_date"]:
                label = (f"{leave['from_time']}–{leave['to_time']}" if part
                         else ("غياب" if leave["kind"] == "absent" else "إجازة"))
                marks[(leave["user_id"], day.isoformat())] = {
                    "kind": "hours" if part else leave["kind"], "label": label, "id": leave["id"]}
    return marks


def remove_leave(conn: sqlite3.Connection, leave_id: int) -> None:
    """Undo a recorded leave: its covers go, and the periods return to the board."""
    leave = db.one(conn, "SELECT * FROM leaves WHERE id = ?", (leave_id,))
    if leave is None:
        return
    for cover in db.all_rows(conn, "SELECT * FROM coverages WHERE leave_id = ?", (leave_id,)):
        if cover["period_id"]:
            conn.execute(
                """DELETE FROM period_overrides WHERE period_id = ? AND reason = 'leave'
                   AND date BETWEEN ? AND ?""",
                (cover["period_id"], leave["from_date"], leave["to_date"]))
    conn.execute("DELETE FROM coverages WHERE leave_id = ?", (leave_id,))
    conn.execute(
        """DELETE FROM period_overrides WHERE reason = 'leave' AND user_id IS NULL
           AND date BETWEEN ? AND ?""", (leave["from_date"], leave["to_date"]))
    conn.execute("DELETE FROM leaves WHERE id = ?", (leave_id,))


def leaves_from(conn: sqlite3.Connection, day: date,
                location_id: int | None = None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT l.*, u.name AS who FROM leaves l JOIN users u ON u.id = l.user_id
           WHERE l.to_date >= ? AND (? IS NULL OR u.location_id = ?)
           ORDER BY l.from_date""",
        (day.isoformat(), location_id, location_id),
    )
