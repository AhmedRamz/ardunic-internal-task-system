"""Routines and their periods: who holds each one, and how it changes hands.

The weekly board (`period_schedule`) says who normally holds a period on each
weekday. Nothing ever rewrites it. A change for one date — a colleague covering,
a leave, a manager's decision — is an `period_overrides` row for that date only,
so next week goes back to the board on its own.

There is no backup: a period with nobody on it is a gap, red on the board, and
the manager fills it. An employee who cannot work a period asks a colleague to
cover, at least `swap_deadline_hours` before it starts; the colleague accepts
and then the branch manager approves. Both yeses, or nothing moves.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from .. import db, texts

WEEKDAY_KEYS = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
WEEKDAY_AR = {"sat": "السبت", "sun": "الأحد", "mon": "الاثنين", "tue": "الثلاثاء",
              "wed": "الأربعاء", "thu": "الخميس", "fri": "الجمعة"}
RESULTS = {"done": "تمت", "partly": "جزئياً", "not_done": "لم تتم", "nothing_today": "لا شيء اليوم"}
DEFAULT_DEADLINE_HOURS = 2


class RuleError(Exception):
    def __init__(self, ar: str, en: str = "") -> None:
        super().__init__(en or ar)
        self.ar, self.en = ar, en or ar


def _require(condition: bool, ar: str, en: str = "") -> None:
    if not condition:
        raise RuleError(ar, en)


@dataclass(frozen=True)
class Message:
    """One thing to say to one person. The caller queues it; the bot sends it."""
    user_id: int
    body: str
    keyboard: str = "none"


# ----------------------------------------------------------------- the calendar
def weekday_key(day: date) -> str:
    return WEEKDAY_KEYS[day.weekday()]


def runs_on(period: sqlite3.Row, day: date) -> bool:
    return weekday_key(day) in [part.strip() for part in period["days"].split(",")]


def _at(day: date, clock: str) -> datetime:
    hour, minute = (int(part) for part in clock.split(":"))
    return datetime.combine(day, time(hour, minute), tzinfo=texts.TZ)


def start_at(period: sqlite3.Row, day: date) -> datetime:
    return _at(day, period["start_time"])


def end_at(period: sqlite3.Row, day: date) -> datetime:
    return _at(day, period["end_time"])


def checkin_at(period: sqlite3.Row, day: date) -> datetime:
    return end_at(period, day) - timedelta(minutes=period["checkin_minutes_before_end"])


def label(period: sqlite3.Row, day: date | None = None) -> str:
    clock = f"{period['start_time']}–{period['end_time']}"
    if day is None:
        return f"{period['name']} ({clock})"
    return f"{WEEKDAY_AR[weekday_key(day)]} {day.isoformat()} · {period['name']} ({clock})"


def deadline_hours(conn: sqlite3.Connection) -> int:
    row = db.one(conn, "SELECT value FROM settings WHERE key = 'swap_deadline_hours'")
    try:
        return int(row["value"]) if row else DEFAULT_DEADLINE_HOURS
    except (TypeError, ValueError):
        return DEFAULT_DEADLINE_HOURS


# ----------------------------------------------------------------- who holds what
def get_period(conn: sqlite3.Connection, period_id: int) -> sqlite3.Row:
    row = db.one(
        conn,
        """SELECT p.*, r.code, r.name AS routine_name, r.count_label, r.location_id,
                  r.instructions
           FROM routine_periods p JOIN routines r ON r.id = p.routine_id WHERE p.id = ?""",
        (period_id,),
    )
    if row is None:
        raise RuleError("الفترة غير موجودة", "no such period")
    return row


def periods_for(conn: sqlite3.Connection, day: date,
                location_id: int | None = None) -> list[sqlite3.Row]:
    """Every active period that runs on this day, earliest first."""
    rows = db.all_rows(
        conn,
        """SELECT p.*, r.code, r.name AS routine_name, r.count_label, r.location_id, r.instructions
           FROM routine_periods p JOIN routines r ON r.id = p.routine_id
           WHERE r.active = 1 AND (? IS NULL OR r.location_id = ?)
           ORDER BY p.start_time, p.id""",
        (location_id, location_id),
    )
    return [row for row in rows if runs_on(row, day)]


def holder(conn: sqlite3.Connection, period_id: int, day: date) -> sqlite3.Row | None:
    """Who really holds this period on this date: the override if there is one, else the board."""
    override = db.one(
        conn, "SELECT user_id FROM period_overrides WHERE period_id = ? AND date = ?",
        (period_id, day.isoformat()))
    if override is not None:
        user_id = override["user_id"]
    else:
        booked = db.one(
            conn, "SELECT user_id FROM period_schedule WHERE period_id = ? AND weekday = ?",
            (period_id, weekday_key(day)))
        user_id = booked["user_id"] if booked else None
    if not user_id:
        return None
    return db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))


def board_holder(conn: sqlite3.Connection, period_id: int, day: date) -> int | None:
    """Who the weekly board says holds it — before any override for that date."""
    row = db.one(conn, "SELECT user_id FROM period_schedule WHERE period_id = ? AND weekday = ?",
                 (period_id, weekday_key(day)))
    return row["user_id"] if row else None


def day_board(conn: sqlite3.Connection, day: date,
              location_id: int | None = None) -> list[dict]:
    """One row per period today: the period, who holds it, and why it is not the board's choice."""
    out = []
    for period in periods_for(conn, day, location_id):
        who = holder(conn, period["id"], day)
        override = db.one(conn, "SELECT * FROM period_overrides WHERE period_id = ? AND date = ?",
                          (period["id"], day.isoformat()))
        out.append({"period": period, "holder": who,
                    "reason": override["reason"] if override else None,
                    "is_gap": who is None})
    return out


def gaps(conn: sqlite3.Connection, day: date, location_id: int | None = None) -> list[sqlite3.Row]:
    return [row["period"] for row in day_board(conn, day, location_id) if row["is_gap"]]


def my_periods(conn: sqlite3.Connection, user_id: int, start: date, days: int = 7) -> list[dict]:
    """A person's own periods over the next few days, in order."""
    user = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if user is None:
        return []
    out = []
    for offset in range(days):
        day = start + timedelta(days=offset)
        for period in periods_for(conn, day, user["location_id"]):
            who = holder(conn, period["id"], day)
            if who is not None and who["id"] == user_id:
                out.append({"period": period, "date": day, "start": start_at(period, day),
                            "end": end_at(period, day)})
    return out


def routines_of(conn: sqlite3.Connection, user_id: int) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT r.*, o.role AS owner_role FROM routine_owners o JOIN routines r ON r.id = o.routine_id
           WHERE o.user_id = ? AND r.active = 1 ORDER BY r.code""",
        (user_id,),
    )


# ----------------------------------------------------------------- the period log
def log_period(conn: sqlite3.Connection, user_id: int, period_id: int, day: date,
               result: str, *, count: int | None = None, note: str = "") -> int:
    _require(result in RESULTS, "نتيجة غير معروفة", "unknown result")
    period = get_period(conn, period_id)
    board = board_holder(conn, period_id, day)
    existing = db.one(
        conn, "SELECT id FROM routine_logs WHERE period_id = ? AND date = ? AND user_id = ?",
        (period_id, day.isoformat(), user_id))
    fields = dict(result=result, count=count, note=note.strip() or None,
                  covering_for=board if board and board != user_id else None)
    if existing:                                   # answering again replaces the answer
        db.update(conn, "routine_logs", existing["id"], **fields)
        return existing["id"]
    return db.insert(conn, "routine_logs", routine_id=period["routine_id"], period_id=period_id,
                     user_id=user_id, date=day.isoformat(), **fields)


def logs_for(conn: sqlite3.Connection, day: date, location_id: int | None = None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT g.*, u.name AS who, p.name AS period_name, p.start_time, p.end_time,
                  r.code, r.name AS routine_name, c.name AS covering_name
           FROM routine_logs g JOIN routines r ON r.id = g.routine_id
                JOIN users u ON u.id = g.user_id
                LEFT JOIN routine_periods p ON p.id = g.period_id
                LEFT JOIN users c ON c.id = g.covering_for
           WHERE g.date = ? AND (? IS NULL OR r.location_id = ?)
           ORDER BY p.start_time, g.id""",
        (day.isoformat(), location_id, location_id),
    )


# ----------------------------------------------------------------- asking a colleague to cover
def _colleagues(conn: sqlite3.Connection, user: sqlite3.Row) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1 AND role = 'employee' AND id != ?
           AND location_id = ? AND telegram_id IS NOT NULL ORDER BY name""",
        (user["id"], user["location_id"]),
    )


def can_cover(conn: sqlite3.Connection, user_id: int, period_id: int, day: date) -> bool:
    """False when that person already holds an overlapping period that day."""
    period = get_period(conn, period_id)
    start, end = start_at(period, day), end_at(period, day)
    for mine in my_periods(conn, user_id, day, days=1):
        if mine["start"] < end and start < mine["end"]:
            return False
    return True


def cover_candidates(conn: sqlite3.Connection, user: sqlite3.Row, period_id: int,
                     day: date) -> list[sqlite3.Row]:
    return [person for person in _colleagues(conn, user)
            if can_cover(conn, person["id"], period_id, day)]


def get_request(conn: sqlite3.Connection, request_id: int) -> sqlite3.Row:
    row = db.one(
        conn,
        """SELECT s.*, f.name AS from_name, t.name AS to_name, f.location_id
           FROM swap_requests s JOIN users f ON f.id = s.from_user JOIN users t ON t.id = s.to_user
           WHERE s.id = ?""",
        (request_id,),
    )
    if row is None:
        raise RuleError("الطلب غير موجود", "no such request")
    return row


def request_cover(conn: sqlite3.Connection, actor_id: int, period_id: int, day: date,
                  to_user_id: int, reason: str, *, now: datetime | None = None
                  ) -> tuple[int, list[Message]]:
    """Step 1 of 3: the holder asks a colleague to take this one date."""
    now = now or texts.now()
    period = get_period(conn, period_id)
    current = holder(conn, period_id, day)
    _require(current is not None and current["id"] == actor_id,
             "هذه الفترة ليست لك في هذا اليوم", "not your period")
    _require(to_user_id != actor_id, "اختر زميلاً آخر", "pick someone else")
    target = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (to_user_id,))
    _require(target is not None, "الزميل غير موجود", "no such colleague")
    _require(target["location_id"] == current["location_id"], "اختر زميلاً من فرعك", "same branch only")

    hours = deadline_hours(conn)
    _require(start_at(period, day) - now >= timedelta(hours=hours),
             f"طلب التبديل قبل {hours} ساعتين على الأقل من بداية الفترة",
             f"at least {hours}h before the period starts")
    _require(can_cover(conn, to_user_id, period_id, day),
             "زميلك يعمل فترة أخرى في نفس الوقت", "the colleague is busy then")
    open_already = db.one(
        conn,
        """SELECT id FROM swap_requests WHERE period_id = ? AND date = ?
           AND status IN ('awaiting_colleague','awaiting_manager')""",
        (period_id, day.isoformat()))
    _require(open_already is None, "يوجد طلب معلّق لهذه الفترة", "a request is already open")

    request_id = db.insert(conn, "swap_requests", period_id=period_id, date=day.isoformat(),
                           from_user=actor_id, to_user=to_user_id, kind="cover",
                           reason=reason.strip() or None, status="awaiting_colleague",
                           created_at=now.strftime("%Y-%m-%d %H:%M:%S"))
    body = (f"🔁 <b>طلب تغطية فترة</b>\n{label(period, day)}\n"
            f"من: {current['name']}\n" + (f"السبب: {reason.strip()}\n" if reason.strip() else "") +
            "هل تستطيع تغطيتها؟")
    return request_id, [Message(to_user_id, body, f"cover:{request_id}")]


def managers_of(conn: sqlite3.Connection, location_id: int) -> list[sqlite3.Row]:
    """The branch manager and the GM — who hears about a gap or approves a cover."""
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1
           AND (role = 'gm' OR (role = 'manager' AND location_id = ?))""",
        (location_id,),
    )


def colleague_accepts(conn: sqlite3.Connection, actor_id: int, request_id: int) -> list[Message]:
    """Step 2 of 3. The board does not move yet — the manager still has to approve."""
    request = get_request(conn, request_id)
    _require(request["to_user"] == actor_id, "الطلب ليس موجهاً إليك", "not your request")
    _require(request["status"] == "awaiting_colleague", "لم يعد الطلب بانتظار ردك", "already answered")
    db.update(conn, "swap_requests", request_id, colleague_decision="accepted",
              status="awaiting_manager")
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    body = (f"🔁 <b>طلب تغطية بانتظار موافقتك</b>\n{label(period, day)}\n"
            f"{request['from_name']} ← {request['to_name']}\n"
            + (f"السبب: {request['reason']}\n" if request["reason"] else "")
            + f"وافق {request['to_name']} على التغطية.")
    out = [Message(m["id"], body, f"cover:{request_id}") for m in managers_of(conn, request["location_id"])]
    out.append(Message(request["from_user"],
                       f"✅ وافق {request['to_name']} على تغطية {label(period, day)}.\n"
                       "بانتظار موافقة مدير الفرع."))
    return out


def colleague_declines(conn: sqlite3.Connection, actor_id: int, request_id: int,
                       reason: str = "") -> list[Message]:
    request = get_request(conn, request_id)
    _require(request["to_user"] == actor_id, "الطلب ليس موجهاً إليك", "not your request")
    _require(request["status"] == "awaiting_colleague", "لم يعد الطلب بانتظار ردك", "already answered")
    db.update(conn, "swap_requests", request_id, colleague_decision="declined", status="declined")
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    note = f"\nالسبب: {reason.strip()}" if reason.strip() else ""
    return [Message(request["from_user"],
                    f"❌ اعتذر {request['to_name']} عن تغطية {label(period, day)}.{note}\n"
                    "الفترة ما زالت لك — جرّب زميلاً آخر أو تحدّث مع المدير.")]


def manager_approves(conn: sqlite3.Connection, actor_id: int, request_id: int) -> list[Message]:
    """Step 3 of 3 — only now does the period change hands, and only for that date."""
    actor = db.one(conn, "SELECT * FROM users WHERE id = ?", (actor_id,))
    request = get_request(conn, request_id)
    _require(actor is not None and (actor["role"] == "gm" or
             (actor["role"] == "manager" and actor["location_id"] == request["location_id"])),
             "الموافقة للمدير فقط", "manager only")
    _require(request["status"] == "awaiting_manager", "الطلب ليس بانتظار موافقتك", "not awaiting you")
    db.update(conn, "swap_requests", request_id, manager_decision="approved", status="approved")
    set_holder(conn, request["period_id"], date.fromisoformat(request["date"]),
               request["to_user"], reason="swap", actor_id=actor_id, swap_request_id=request_id)
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    return [
        Message(request["to_user"], f"✅ اعتُمدت التغطية. {label(period, day)} لك.\n"
                                    f"بدلاً عن {request['from_name']}."),
        Message(request["from_user"], f"✅ اعتُمد طلبك. {label(period, day)} يغطيها "
                                      f"{request['to_name']}."),
    ]


def manager_declines(conn: sqlite3.Connection, actor_id: int, request_id: int,
                     reason: str = "") -> list[Message]:
    actor = db.one(conn, "SELECT * FROM users WHERE id = ?", (actor_id,))
    request = get_request(conn, request_id)
    _require(actor is not None and (actor["role"] == "gm" or
             (actor["role"] == "manager" and actor["location_id"] == request["location_id"])),
             "الرفض للمدير فقط", "manager only")
    _require(request["status"] in ("awaiting_manager", "awaiting_colleague"),
             "الطلب محسوم", "already settled")
    db.update(conn, "swap_requests", request_id, manager_decision="declined", status="declined")
    period = get_period(conn, request["period_id"])
    day = date.fromisoformat(request["date"])
    note = f"\nالسبب: {reason.strip()}" if reason.strip() else ""
    body = f"❌ لم يوافق المدير على تغطية {label(period, day)}.{note}"
    return [Message(request["from_user"], body + "\nالفترة ما زالت لك."),
            Message(request["to_user"], body)]


def expire_requests(conn: sqlite3.Connection, now: datetime) -> list[Message]:
    """A request nobody answered before the period started is dead — say so once."""
    out: list[Message] = []
    for request in db.all_rows(
            conn, """SELECT s.*, t.name AS to_name FROM swap_requests s JOIN users t ON t.id = s.to_user
                     WHERE s.status IN ('awaiting_colleague','awaiting_manager')"""):
        period = get_period(conn, request["period_id"])
        day = date.fromisoformat(request["date"])
        if start_at(period, day) <= now:
            db.update(conn, "swap_requests", request["id"], status="expired")
            out.append(Message(request["from_user"],
                               f"⌛ انتهى وقت طلب تغطية {label(period, day)} دون حسم. الفترة لك."))
    return out


# ----------------------------------------------------------------- what the clock owes today
CHECKIN_GRACE_MINUTES = 90          # a check-in asked two hours late is only noise
GAP_GRACE_MINUTES = 120


def has_run(conn: sqlite3.Connection, period_id: int, day: date, kind: str) -> bool:
    return db.one(conn, "SELECT 1 FROM period_runs WHERE period_id = ? AND date = ? AND kind = ?",
                  (period_id, day.isoformat(), kind)) is not None


def mark_run(conn: sqlite3.Connection, period_id: int, day: date, kind: str, sent: int = 0) -> None:
    db.insert(conn, "period_runs", period_id=period_id, date=day.isoformat(), kind=kind, sent=sent)


def due_checkins(conn: sqlite3.Connection, now: datetime) -> list[dict]:
    """Periods whose check-in moment has passed today and that have not been asked yet."""
    day = now.date()
    out = []
    for period in periods_for(conn, day):
        if has_run(conn, period["id"], day, "checkin"):
            continue
        moment = checkin_at(period, day)
        if moment > now:
            continue
        out.append({"period": period, "date": day, "holder": holder(conn, period["id"], day),
                    "late": (now - moment).total_seconds() / 60 > CHECKIN_GRACE_MINUTES})
    return out


def due_gaps(conn: sqlite3.Connection, now: datetime) -> list[dict]:
    """Periods that have started today with nobody on them — the manager needs to know once."""
    day = now.date()
    out = []
    for period in periods_for(conn, day):
        if has_run(conn, period["id"], day, "gap") or holder(conn, period["id"], day) is not None:
            continue
        started = start_at(period, day)
        if started > now:
            continue
        out.append({"period": period, "date": day,
                    "late": (now - started).total_seconds() / 60 > GAP_GRACE_MINUTES})
    return out


def checkin_message(conn: sqlite3.Connection, period: sqlite3.Row, day: date,
                    person: sqlite3.Row) -> Message:
    board = board_holder(conn, period["id"], day)
    covering = ""
    if board and board != person["id"]:
        other = db.one(conn, "SELECT name FROM users WHERE id = ?", (board,))
        covering = f"\nتغطية بدلاً عن {other['name']}" if other else ""
    ask = "كيف سارت الفترة؟"
    if period["count_label"]:
        # the label is whatever the routine calls its count, so it is quoted, not inflected
        ask += f"\n<i>سيُطلب العدد: {period['count_label']}</i>"
    body = (f"⏰ <b>نهاية فترة {period['name']}</b>\n"
            f"{period['code']} · {period['routine_name']}\n"
            f"{period['start_time']}–{period['end_time']}{covering}\n\n{ask}")
    return Message(person["id"], body, f"pck:{period['id']}:{day.isoformat()}")


def gap_message(conn: sqlite3.Connection, period: sqlite3.Row, day: date) -> list[Message]:
    body = (f"🔴 <b>فترة بلا مسؤول</b>\n{label(period, day)}\n"
            f"{period['code']} · {period['routine_name']}\n"
            "عيّن شخصاً من لوحة الفترات.")
    return [Message(m["id"], body) for m in managers_of(conn, period["location_id"])]


# ----------------------------------------------------------------- the board and leaves
def set_holder(conn: sqlite3.Connection, period_id: int, day: date, user_id: int | None, *,
               reason: str = "manager", actor_id: int | None = None,
               swap_request_id: int | None = None) -> None:
    """Change who holds a period on one date. The weekly board is never touched."""
    _require(reason in ("swap", "leave", "absence", "manager"), "سبب غير معروف", "unknown reason")
    existing = db.one(conn, "SELECT id FROM period_overrides WHERE period_id = ? AND date = ?",
                      (period_id, day.isoformat()))
    fields = dict(user_id=user_id, reason=reason, created_by=actor_id,
                  swap_request_id=swap_request_id)
    if existing:
        db.update(conn, "period_overrides", existing["id"], **fields)
    else:
        db.insert(conn, "period_overrides", period_id=period_id, date=day.isoformat(), **fields)


def clear_holder(conn: sqlite3.Connection, period_id: int, day: date) -> None:
    """Drop the override so the weekly board applies again."""
    conn.execute("DELETE FROM period_overrides WHERE period_id = ? AND date = ?",
                 (period_id, day.isoformat()))


def days_between(start: date, end: date) -> list[date]:
    return [start + timedelta(days=offset) for offset in range((end - start).days + 1)]


def periods_during_leave(conn: sqlite3.Connection, user_id: int, start: date,
                         end: date) -> list[dict]:
    """Every period that person is due to hold while away — what the manager must cover."""
    out = []
    for day in days_between(start, end):
        for entry in my_periods(conn, user_id, day, days=1):
            out.append(entry)
    return out


def record_leave(conn: sqlite3.Connection, actor_id: int, user_id: int, start: date, end: date, *,
                 kind: str = "leave", cover: dict[tuple[int, str], int] | None = None
                 ) -> tuple[int, list[Message]]:
    """Record a leave and, for each period it touches, who covers it (or leave it a gap)."""
    actor = db.one(conn, "SELECT * FROM users WHERE id = ?", (actor_id,))
    person = db.one(conn, "SELECT * FROM users WHERE id = ? AND active = 1", (user_id,))
    _require(person is not None, "الموظف غير موجود", "no such person")
    _require(actor is not None and actor["role"] in ("gm", "manager"),
             "تسجيل الإجازات للمدراء", "managers only")
    _require(end >= start, "تاريخ النهاية قبل البداية", "end before start")
    _require(kind in ("leave", "absent"), "نوع غير معروف", "unknown kind")

    leave_id = db.insert(conn, "leaves", user_id=user_id, from_date=start.isoformat(),
                         to_date=end.isoformat(), kind=kind, created_by=actor_id)
    cover = cover or {}
    messages: list[Message] = []
    gap_list: list[str] = []
    for entry in periods_during_leave(conn, user_id, start, end):
        period, day = entry["period"], entry["date"]
        cover_id = cover.get((period["id"], day.isoformat()))
        set_holder(conn, period["id"], day, cover_id, reason="leave", actor_id=actor_id)
        if cover_id:
            db.insert(conn, "coverages", leave_id=leave_id, routine_id=period["routine_id"],
                      period_id=period["id"], cover_user_id=cover_id)
            messages.append(Message(cover_id,
                                    f"📅 <b>تغطية بدل إجازة</b>\n{label(period, day)}\n"
                                    f"بدلاً عن {person['name']}."))
        else:
            gap_list.append(label(period, day))

    span = start.isoformat() if start == end else f"{start.isoformat()} إلى {end.isoformat()}"
    word = "إجازة" if kind == "leave" else "غياب"
    messages.append(Message(user_id, f"📅 سُجّلت {word} لك: {span}."))
    if gap_list:
        warning = (f"⚠️ <b>فترات بلا مسؤول</b> بسبب {word} {person['name']}:\n"
                   + "\n".join(f"• {item}" for item in gap_list))
        messages += [Message(m["id"], warning) for m in managers_of(conn, person["location_id"])
                     if m["id"] != actor_id]
    return leave_id, messages


def on_leave(conn: sqlite3.Connection, user_id: int, day: date) -> sqlite3.Row | None:
    return db.one(
        conn, "SELECT * FROM leaves WHERE user_id = ? AND from_date <= ? AND to_date >= ?",
        (user_id, day.isoformat(), day.isoformat()))


def leaves_from(conn: sqlite3.Connection, day: date,
                location_id: int | None = None) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT l.*, u.name AS who FROM leaves l JOIN users u ON u.id = l.user_id
           WHERE l.to_date >= ? AND (? IS NULL OR u.location_id = ?)
           ORDER BY l.from_date""",
        (day.isoformat(), location_id, location_id),
    )
