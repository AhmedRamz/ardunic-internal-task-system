"""What's new, per person.

Every change is already a row in task_events. This module answers three
questions on top of that: what has this manager not seen yet, what happened
across the branch lately, and how is one employee doing.
"""
from __future__ import annotations

import sqlite3

from .. import db, texts

# Events worth showing in the feed. Anything not listed (an internal reminder
# marker, for instance) stays out of sight.
FEED_ACTIONS = {
    "comment": ("💬", "تعليق"),
    "created": ("📋", "مهمة جديدة"),
    "suggested": ("💡", "اقتراح"),
    "accepted": ("✅", "قبول"),
    "rejected": ("❌", "رفض"),
    "delegated": ("🔀", "تفويض"),
    "done": ("✔️", "إنجاز"),
    "done_pending_review": ("🔎", "بانتظار المراجعة"),
    "review_approved": ("✅", "اعتماد"),
    "review_returned": ("↩️", "إعادة"),
    "handover_requested": ("🔄", "طلب تسليم"),
    "handover_approved": ("🔄", "موافقة تسليم"),
    "handover_accepted": ("🔄", "قبول تسليم"),
    "handover_rejected": ("🔄", "رفض تسليم"),
    "handover_declined": ("🔄", "رفض طلب التسليم"),
    "update_blocked": ("⚠️", "متوقفة"),
    "update_working": ("⏳", "تحديث"),
    "carried_over": ("📅", "ترحيل"),
    "reassigned": ("📋", "إعادة إسناد"),
    "cancelled": ("🚫", "إلغاء"),
    "suggestion_approved": ("✅", "موافقة على اقتراح"),
    "suggestion_declined": ("❌", "رفض اقتراح"),
}
FEED_FILTERS = {
    "all": tuple(FEED_ACTIONS),
    "comments": ("comment",),
    "attention": ("rejected", "update_blocked", "handover_requested", "done_pending_review",
                  "suggested", "carried_over"),
}


def _scope(viewer: sqlite3.Row) -> tuple[str, tuple]:
    if viewer["role"] == "gm":
        return "1=1", ()
    return "t.location_id = ?", (viewer["location_id"],)


# ----------------------------------------------------------------- unread
def unread_by_task(conn: sqlite3.Connection, viewer_id: int) -> dict[int, dict[str, int]]:
    """{task_id: {'comments': n, 'other': n}} — what this person has not opened yet."""
    rows = db.all_rows(
        conn,
        """SELECT e.task_id, e.action, COUNT(*) AS n
           FROM task_events e
           LEFT JOIN task_reads r ON r.task_id = e.task_id AND r.user_id = ?
           WHERE e.actor_id IS NOT NULL AND e.actor_id != ?
             AND e.id > COALESCE(r.last_seen_event_id, 0)
             AND e.action IN ({})
           GROUP BY e.task_id, e.action""".format(",".join("?" for _ in FEED_ACTIONS)),
        (viewer_id, viewer_id, *FEED_ACTIONS),
    )
    out: dict[int, dict[str, int]] = {}
    for row in rows:
        bucket = out.setdefault(row["task_id"], {"comments": 0, "other": 0})
        bucket["comments" if row["action"] == "comment" else "other"] += row["n"]
    return out


def unread_total(conn: sqlite3.Connection, viewer: sqlite3.Row) -> int:
    where, params = _scope(viewer)
    row = db.one(
        conn,
        f"""SELECT COUNT(*) AS n FROM task_events e JOIN tasks t ON t.id = e.task_id
            LEFT JOIN task_reads r ON r.task_id = e.task_id AND r.user_id = ?
            WHERE {where} AND e.actor_id IS NOT NULL AND e.actor_id != ?
              AND e.id > COALESCE(r.last_seen_event_id, 0)
              AND e.action IN ({",".join("?" for _ in FEED_ACTIONS)})""",
        (viewer["id"], *params, viewer["id"], *FEED_ACTIONS),
    )
    return int(row["n"]) if row else 0


def mark_read(conn: sqlite3.Connection, viewer_id: int, task_id: int) -> None:
    """Called when the task page is opened."""
    last = db.one(conn, "SELECT COALESCE(MAX(id), 0) AS m FROM task_events WHERE task_id = ?",
                  (task_id,))["m"]
    existing = db.one(conn, "SELECT id FROM task_reads WHERE user_id = ? AND task_id = ?",
                      (viewer_id, task_id))
    if existing:
        conn.execute("UPDATE task_reads SET last_seen_event_id = ?, seen_at = ? WHERE id = ?",
                     (last, texts.now().strftime("%Y-%m-%d %H:%M:%S"), existing["id"]))
    else:
        db.insert(conn, "task_reads", user_id=viewer_id, task_id=task_id,
                  last_seen_event_id=last, seen_at=texts.now().strftime("%Y-%m-%d %H:%M:%S"))


def mark_all_read(conn: sqlite3.Connection, viewer: sqlite3.Row) -> int:
    where, params = _scope(viewer)
    tasks = db.all_rows(conn, f"SELECT t.id FROM tasks t WHERE {where}", params)
    for row in tasks:
        mark_read(conn, viewer["id"], row["id"])
    return len(tasks)


# ----------------------------------------------------------------- the feed
def feed(conn: sqlite3.Connection, viewer: sqlite3.Row, *, kind: str = "all",
         limit: int = 60, offset: int = 0) -> list[sqlite3.Row]:
    """Everything that happened, newest first, inside what this person may see."""
    where, params = _scope(viewer)
    actions = FEED_FILTERS.get(kind, FEED_FILTERS["all"])
    marks = ",".join("?" for _ in actions)
    return db.all_rows(
        conn,
        f"""SELECT e.*, t.title, t.status AS task_status, t.assignee_id,
                   u.name AS actor_name, u.role AS actor_role,
                   a.name AS assignee_name,
                   CASE WHEN e.id > COALESCE(r.last_seen_event_id, 0)
                             AND e.actor_id IS NOT NULL AND e.actor_id != ?
                        THEN 1 ELSE 0 END AS is_new
            FROM task_events e
            JOIN tasks t ON t.id = e.task_id
            LEFT JOIN users u ON u.id = e.actor_id
            LEFT JOIN users a ON a.id = t.assignee_id
            LEFT JOIN task_reads r ON r.task_id = e.task_id AND r.user_id = ?
            WHERE {where} AND e.action IN ({marks})
            ORDER BY e.id DESC LIMIT ? OFFSET ?""",
        (viewer["id"], viewer["id"], *params, *actions, limit, offset),
    )


# ----------------------------------------------------------------- one employee
def employee_summary(conn: sqlite3.Connection, user_id: int) -> dict:
    """Current tasks and how the person is doing — the employee page."""
    person = db.one(conn, "SELECT * FROM users WHERE id = ?", (user_id,))
    if person is None:
        return {}
    now = texts.now().strftime("%Y-%m-%d %H:%M")

    open_tasks = db.all_rows(
        conn,
        """SELECT * FROM tasks WHERE assignee_id = ?
           AND status IN ('assigned','in_progress','handover','review')
           ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 ELSE 2 END, due_at""",
        (user_id,),
    )
    counts = {
        "open": len(open_tasks),
        "overdue": sum(1 for t in open_tasks if t["due_at"] and t["due_at"] < now),
        "unaccepted": sum(1 for t in open_tasks if t["status"] == "assigned"),
        "in_review": sum(1 for t in open_tasks if t["status"] == "review"),
        "done_7": db.one(conn, """SELECT COUNT(*) n FROM tasks WHERE assignee_id = ? AND status = 'done'
                                  AND closed_at >= date('now','-7 days')""", (user_id,))["n"],
        "done_30": db.one(conn, """SELECT COUNT(*) n FROM tasks WHERE assignee_id = ? AND status = 'done'
                                   AND closed_at >= date('now','-30 days')""", (user_id,))["n"],
        "rejected_30": db.one(conn, """SELECT COUNT(*) n FROM task_events WHERE actor_id = ?
                                       AND action = 'rejected' AND created_at >= date('now','-30 days')""",
                              (user_id,))["n"],
    }
    done_30 = counts["done_30"]
    on_time = db.one(
        conn,
        """SELECT COUNT(*) n FROM tasks WHERE assignee_id = ? AND status = 'done'
           AND closed_at >= date('now','-30 days') AND (due_at IS NULL OR closed_at <= due_at)""",
        (user_id,),
    )["n"]
    counts["on_time_pct"] = round(on_time * 100 / done_30) if done_30 else None

    today = texts.now().date().isoformat()
    checkins = db.all_rows(
        conn,
        """SELECT c.*, t.title FROM checkins c LEFT JOIN tasks t ON t.id = c.task_id
           WHERE c.user_id = ? AND c.date = ? ORDER BY c.id DESC""",
        (user_id, today),
    )
    recent = db.all_rows(
        conn,
        """SELECT e.*, t.title FROM task_events e JOIN tasks t ON t.id = e.task_id
           WHERE e.actor_id = ? ORDER BY e.id DESC LIMIT 15""",
        (user_id,),
    )
    periods = db.all_rows(
        conn,
        """SELECT p.name, p.start_time, p.end_time, s.weekday, r.code
           FROM period_schedule s JOIN routine_periods p ON p.id = s.period_id
           JOIN routines r ON r.id = p.routine_id WHERE s.user_id = ? ORDER BY p.start_time""",
        (user_id,),
    )
    routines = db.all_rows(
        conn,
        """SELECT r.code, r.name, ro.role FROM routine_owners ro JOIN routines r ON r.id = ro.routine_id
           WHERE ro.user_id = ? ORDER BY r.code""",
        (user_id,),
    )
    return {"person": person, "open_tasks": open_tasks, "counts": counts, "checkins": checkins,
            "recent": recent, "periods": periods, "routines": routines}
