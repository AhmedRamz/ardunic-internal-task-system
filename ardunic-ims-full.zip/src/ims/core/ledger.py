"""سجل المهام — every task in one table, read by its timestamps.

The board shows what is live; this is the record. Nothing here is ever written:
it reads `tasks` and its history, so a task closed months ago reads exactly as
it did the day it closed.

The one real choice is which timestamp a date range means. "What did we take on
this week" and "what did we finish this week" are different questions, so the
page asks by `anchor`: created_at or closed_at.
"""
from __future__ import annotations

import sqlite3
from datetime import date, datetime, timedelta

from .. import db, texts
from . import tasks as T

ANCHORS = {"created": ("created_at", "حسب تاريخ الإنشاء"),
           "closed": ("closed_at", "حسب تاريخ الإغلاق")}
STATUS_GROUPS = {
    "all": None,
    "open": (T.SUGGESTED, T.ASSIGNED, T.IN_PROGRESS, T.HANDOVER, T.REVIEW, T.REJECTED),
    "done": (T.DONE,),
    "cancelled": (T.CANCELLED,),
}
PAGE_SIZE = 100


def month_start(day: date) -> date:
    return day.replace(day=1)


def ranges(today: date) -> dict[str, tuple[date, date]]:
    """The quick buttons, so the common questions take one click."""
    saturday = today - timedelta(days=(today.weekday() + 2) % 7)
    return {
        "today": (today, today),
        "week": (saturday, saturday + timedelta(days=6)),
        "month": (month_start(today), today),
        "prev_month": (month_start(month_start(today) - timedelta(days=1)),
                       month_start(today) - timedelta(days=1)),
    }


DEFAULT_BOARD_CLEAR = "23:59"


def board_cutoff(conn: sqlite3.Connection, now: datetime) -> datetime:
    """The moment the منجزة column was last emptied.

    Finished work stays on the board for the rest of the day and is swept at
    the clear time — 23:59 by default. Nothing is deleted: it simply stops
    being shown, and the ledger keeps it for good.
    """
    row = db.one(conn, "SELECT value FROM settings WHERE key = 'board_clear_time'")
    clock = ((row["value"] if row else "") or DEFAULT_BOARD_CLEAR).strip()
    try:
        hour, minute = (int(part) for part in clock.split(":"))
        today = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    except ValueError:
        today = now.replace(hour=23, minute=59, second=0, microsecond=0)
    return today if today <= now else today - timedelta(days=1)


def _scope(viewer: sqlite3.Row) -> tuple[str, tuple]:
    if viewer["role"] == "gm":
        return "1=1", ()
    return "t.location_id = ?", (viewer["location_id"],)


def _minutes(start: str | None, end: str | None) -> int | None:
    if not start or not end:
        return None
    try:
        first = datetime.strptime(start[:16], "%Y-%m-%d %H:%M")
        last = datetime.strptime(end[:16], "%Y-%m-%d %H:%M")
    except ValueError:
        return None
    return max(0, int((last - first).total_seconds() // 60))


def duration_ar(minutes: int | None) -> str:
    if minutes is None:
        return "—"
    if minutes < 60:
        return f"{minutes} دقيقة"
    hours, rest = divmod(minutes, 60)
    if hours < 24:
        return f"{hours}:{rest:02d} ساعة"
    days, spare = divmod(hours, 24)
    return f"{days} يوم {spare} ساعة" if spare else f"{days} يوم"


def query(conn: sqlite3.Connection, viewer: sqlite3.Row, *, start: date, end: date,
          anchor: str = "created", status: str = "all", assignee: int = 0,
          text: str = "", limit: int = PAGE_SIZE, offset: int = 0) -> dict:
    """One page of the ledger plus the totals for the whole filtered range."""
    column = ANCHORS.get(anchor, ANCHORS["created"])[0]
    where, params = _scope(viewer)
    clauses = [where, f"date(t.{column}) BETWEEN ? AND ?"]
    values = [*params, start.isoformat(), end.isoformat()]

    group = STATUS_GROUPS.get(status)
    if group:
        clauses.append(f"t.status IN ({','.join('?' for _ in group)})")
        values += list(group)
    if assignee:
        clauses.append("t.assignee_id = ?")
        values.append(assignee)
    if text.strip():
        clauses.append("(t.title LIKE ? OR t.description LIKE ?)")
        values += [f"%{text.strip()}%"] * 2
    sql_where = " AND ".join(clauses)

    rows = db.all_rows(
        conn,
        f"""SELECT t.*, a.name AS assignee_name, c.name AS creator_name, l.name AS branch,
                   d.name AS delegated_name,
                   (SELECT COUNT(*) FROM task_events e
                     WHERE e.task_id = t.id AND e.action = 'comment') AS comments
            FROM tasks t
                 LEFT JOIN users a ON a.id = t.assignee_id
                 LEFT JOIN users c ON c.id = t.created_by
                 LEFT JOIN users d ON d.id = t.delegated_from
                 LEFT JOIN locations l ON l.id = t.location_id
            WHERE {sql_where}
            ORDER BY t.{column} DESC, t.id DESC LIMIT ? OFFSET ?""",
        (*values, limit, offset),
    )

    out = []
    for row in rows:
        minutes = _minutes(row["created_at"], row["closed_at"])
        on_time = None
        if row["status"] == T.DONE and row["due_at"] and row["closed_at"]:
            on_time = row["closed_at"][:16] <= row["due_at"][:16]
        out.append({"task": row, "minutes": minutes, "duration": duration_ar(minutes),
                    "on_time": on_time})

    totals = db.one(
        conn,
        f"""SELECT COUNT(*) AS all_rows,
                   SUM(t.status = 'done') AS done,
                   SUM(t.status = 'cancelled') AS cancelled,
                   SUM(t.status NOT IN ('done','cancelled')) AS open,
                   SUM(t.status = 'done' AND t.due_at IS NOT NULL
                       AND substr(t.closed_at,1,16) <= substr(t.due_at,1,16)) AS on_time,
                   SUM(t.status = 'done' AND t.due_at IS NOT NULL) AS judged
            FROM tasks t WHERE {sql_where}""",
        tuple(values),
    )
    summary = {key: totals[key] or 0 for key in
               ("all_rows", "done", "cancelled", "open", "on_time", "judged")}
    summary["on_time_pct"] = (round(summary["on_time"] * 100 / summary["judged"])
                              if summary["judged"] else None)
    closed = [item["minutes"] for item in out if item["minutes"] is not None]
    summary["average"] = duration_ar(round(sum(closed) / len(closed))) if closed else "—"
    return {"rows": out, "totals": summary,
            "has_more": summary["all_rows"] > offset + len(out)}


CSV_HEADERS = ("الرقم", "العنوان", "الحالة", "المسؤول", "أنشأها", "الفرع", "الأولوية",
               "أُنشئت", "قُبلت", "الموعد", "أُغلقت", "المدة", "في الموعد", "تعليقات", "المصدر")


def csv_rows(result: dict) -> list[tuple]:
    """The same table, flattened for Excel."""
    out = [CSV_HEADERS]
    for item in result["rows"]:
        task = item["task"]
        out.append((
            task["id"], task["title"], texts.STATUS.get(task["status"], task["status"]),
            task["assignee_name"] or "", task["creator_name"] or "", task["branch"] or "",
            texts.PRIORITY.get(task["priority"], task["priority"]),
            task["created_at"] or "", task["accepted_at"] or "", task["due_at"] or "",
            task["closed_at"] or "", item["duration"],
            "" if item["on_time"] is None else ("نعم" if item["on_time"] else "لا"),
            task["comments"], "البوت" if task["source"] == "bot" else "اللوحة",
        ))
    return out
