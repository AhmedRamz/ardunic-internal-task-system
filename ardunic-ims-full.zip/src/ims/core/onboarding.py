"""Putting the Jadriya team and the social-media rota in, from the dashboard.

This is Ahmed's own sheet — Facebook and Instagram, three periods a day, four
on Friday — turned into something the GM can apply with one button instead of
a command on the server. Running it twice changes nothing: people are matched
by name, nothing is ever deleted, and the board is simply written to match.
"""
from __future__ import annotations

import random
import sqlite3
from datetime import datetime, timedelta, timezone

from .. import db
from . import periods as P

# how the name should read in the dashboard -> the spelling on the sheet
TEAM = [
    ("نرجس", "Narjes"),
    ("علي", "Ali"),
    ("طيبة", "Teeba"),
    ("محمد أحمد", "Mohammed Ahmed"),
    ("محمود", "Mahmood"),
    ("أحمد جعفر", "Ahmed Jaffar"),
]

WORKWEEK = "sat,sun,mon,tue,wed,thu"
PERIODS = [
    ("صباحية", WORKWEEK, "08:00", "17:00"),
    ("مسائية", WORKWEEK, "17:00", "20:00"),
    ("ليلية", WORKWEEK, "20:00", "23:59"),
    ("الجمعة ف1", "fri", "08:00", "12:00"),
    ("الجمعة ف2", "fri", "12:00", "16:00"),
    ("الجمعة ف3", "fri", "16:00", "20:00"),
    ("الجمعة ف4", "fri", "20:00", "23:59"),
]

# period -> weekday -> who. None is a gap, exactly as the sheet has it.
ROTA = {
    "صباحية": {"sat": "نرجس", "sun": "علي", "mon": "طيبة", "tue": "محمد أحمد",
               "wed": "أحمد جعفر", "thu": "محمود"},
    "مسائية": {"sat": "محمد أحمد", "sun": "محمود", "mon": "أحمد جعفر", "tue": "طيبة",
               "wed": "علي", "thu": "نرجس"},
    "ليلية": {"sat": "طيبة", "sun": None, "mon": "نرجس", "tue": "علي",
              "wed": "محمود", "thu": "محمد أحمد"},
    "الجمعة ف1": {"fri": "محمود"},
    "الجمعة ف2": {"fri": "محمود"},
    "الجمعة ف3": {"fri": "محمود"},
    "الجمعة ف4": {"fri": "محمود"},
}

R1_CODE = "R1"
R1_NAME = "الرد على العملاء في مواقع التواصل وتتبع الطلبات"
R1_INSTRUCTIONS = "الرد على رسائل فيسبوك وإنستغرام ومتابعة حالة الطلبات."


def branch_of(conn: sqlite3.Connection, location_id: int | None = None) -> sqlite3.Row | None:
    if location_id:
        return db.one(conn, "SELECT * FROM locations WHERE id = ?", (location_id,))
    return db.one(conn, "SELECT * FROM locations ORDER BY id LIMIT 1")


def plan(conn: sqlite3.Connection, location_id: int) -> dict:
    """What applying would do, so nothing happens unseen."""
    people = []
    for name, english in TEAM:
        row = db.one(conn, "SELECT * FROM users WHERE name = ? AND location_id = ?",
                     (name, location_id))
        people.append({
            "name": name, "english": english, "exists": row is not None,
            "linked": bool(row and row["telegram_id"]),
            "inactive": bool(row and not row["active"]),
        })
    routine = db.one(conn, "SELECT * FROM routines WHERE code = ? AND location_id = ?",
                     (R1_CODE, location_id))
    have = {row["name"] for row in db.all_rows(
        conn, "SELECT name FROM routine_periods WHERE routine_id = ?",
        (routine["id"],))} if routine else set()
    rows = []
    for period_name, days, start, end in PERIODS:
        rows.append({"name": period_name, "start": start, "end": end,
                     "exists": period_name in have,
                     "by_day": ROTA.get(period_name, {})})
    return {"people": people, "periods": rows, "routine": routine,
            "missing": sum(1 for p in people if not p["exists"]),
            "gaps": sum(1 for r in rows for who in r["by_day"].values() if not who)}


def _link_code(conn: sqlite3.Connection, user_id: int) -> str:
    code = f"{random.randint(100000, 999999)}"
    expires = (datetime.now(timezone.utc) + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
    db.update(conn, "users", user_id, link_code=code, link_code_expires=expires)
    return code


def apply(conn: sqlite3.Connection, location_id: int) -> dict:
    """Create whoever is missing, then write the board to match the sheet."""
    manager = db.one(conn, "SELECT id FROM users WHERE role = 'manager' AND location_id = ?",
                     (location_id,))
    people: dict[str, int] = {}
    codes: list[tuple[str, str, str]] = []
    created = 0
    for name, english in TEAM:
        row = db.one(conn, "SELECT * FROM users WHERE name = ? AND location_id = ?",
                     (name, location_id))
        if row is None:
            user_id = db.insert(conn, "users", name=name, role="employee",
                                location_id=location_id,
                                manager_id=manager["id"] if manager else None)
            created += 1
            codes.append((name, english, _link_code(conn, user_id)))
        else:
            user_id = row["id"]
            if not row["active"]:
                db.update(conn, "users", user_id, active=1)
            if not row["telegram_id"]:
                codes.append((name, english, _link_code(conn, user_id)))
        people[name] = user_id

    routine = db.one(conn, "SELECT * FROM routines WHERE code = ? AND location_id = ?",
                     (R1_CODE, location_id))
    if routine is None:
        routine_id = db.insert(conn, "routines", code=R1_CODE, name=R1_NAME,
                               location_id=location_id, count_label="المحادثات",
                               days="sat,sun,mon,tue,wed,thu,fri", kind="periodic",
                               instructions=R1_INSTRUCTIONS)
    else:
        routine_id = routine["id"]
        db.update(conn, "routines", routine_id, days="sat,sun,mon,tue,wed,thu,fri",
                  active=1, kind="periodic")

    period_ids = {}
    for name, days, start, end in PERIODS:
        row = db.one(conn, "SELECT * FROM routine_periods WHERE routine_id = ? AND name = ?",
                     (routine_id, name))
        if row is None:
            period_ids[name] = db.insert(conn, "routine_periods", routine_id=routine_id,
                                         name=name, days=days, start_time=start, end_time=end)
        else:
            period_ids[name] = row["id"]
            db.update(conn, "routine_periods", row["id"], days=days,
                      start_time=start, end_time=end)

    filled = gaps = 0
    for period_name, by_day in ROTA.items():
        period_id = period_ids[period_name]
        for weekday, who in by_day.items():
            user_id = people.get(who) if who else None
            row = db.one(conn, "SELECT id FROM period_schedule WHERE period_id = ? AND weekday = ?",
                         (period_id, weekday))
            if row:
                db.update(conn, "period_schedule", row["id"], user_id=user_id)
            else:
                db.insert(conn, "period_schedule", period_id=period_id, weekday=weekday,
                          user_id=user_id)
            filled += 1 if user_id else 0
            gaps += 0 if user_id else 1

    return {"created": created, "people": len(people), "filled": filled, "gaps": gaps,
            "codes": codes, "routine_id": routine_id}


def summary_lines(result: dict) -> list[str]:
    """For the script, which prints rather than renders."""
    out = [f"الفريق: {result['people']} أشخاص ({result['created']} جديد)",
           f"خانات مملوءة: {result['filled']} · فجوات: {result['gaps']}"]
    if result["codes"]:
        out.append("")
        out.append("رموز الربط — يرسلها كل شخص للبوت خلال 24 ساعة:")
        out += [f"  {name:12s} ({english:15s})  /start {code}"
                for name, english, code in result["codes"]]
    else:
        out.append("كل الحسابات مرتبطة بالبوت بالفعل.")
    return out


WEEKDAY_AR = P.WEEKDAY_AR
