"""One path out to Telegram.

The dashboard and the bot both *queue* notifications here; the bot process is
the only one that actually sends. That way a message written from the browser
still reaches the employee's phone, nothing is lost while the bot restarts, and
every attempt is on record.
"""
from __future__ import annotations

import sqlite3

from .. import db, texts
from .tasks import Event, get_task


def render(conn: sqlite3.Connection, event: Event) -> str | None:
    """The Arabic message for an event, or None when the event is silent."""
    template = texts.EVENT_TEXT.get(event.action)
    if not template:
        return None
    task = get_task(conn, event.task_id)
    actor = db.one(conn, "SELECT name FROM users WHERE id = ?", (event.actor_id,))
    return template.format(
        id=task["id"],
        title=task["title"],
        actor=actor["name"] if actor else "",
        due=texts.due_label(task["due_at"]),
        priority=f"{texts.PRIORITY_DOT[task['priority']]} {texts.PRIORITY[task['priority']]}",
        note=event.note or "",
    )


def queue(conn: sqlite3.Connection, event: Event) -> int:
    """Put one row per recipient in the outbox. Returns how many were queued."""
    body = render(conn, event)
    if not body or not event.recipients:
        return 0
    queued = 0
    for user_id in dict.fromkeys(event.recipients):          # de-duplicated, order kept
        if not user_id or user_id == event.actor_id:         # never notify the actor
            continue
        user = db.one(conn, "SELECT id, telegram_id FROM users WHERE id = ? AND active = 1", (user_id,))
        if user is None or not user["telegram_id"]:          # not linked yet — nothing to send to
            continue
        db.insert(conn, "outbox", user_id=user_id, task_id=event.task_id,
                  action=event.action, body=body)
        queued += 1
    return queued


def queue_raw(conn: sqlite3.Connection, user_id: int, body: str, *,
              task_id: int | None = None, keyboard: str = "none", action: str = "scheduled") -> bool:
    """Queue a message the scheduler composed (a brief, an update, a report).

    `keyboard` tells the sender which buttons to attach: 'task', 'update',
    'closeout' or 'none'.
    """
    user = db.one(conn, "SELECT id, telegram_id FROM users WHERE id = ? AND active = 1", (user_id,))
    if user is None or not user["telegram_id"] or not body.strip():
        return False
    db.insert(conn, "outbox", user_id=user_id, task_id=task_id, action=action,
              body=body, keyboard=keyboard)
    return True


def pending(conn: sqlite3.Connection, limit: int = 20) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT o.*, u.telegram_id FROM outbox o JOIN users u ON u.id = o.user_id
           WHERE o.sent_at IS NULL AND o.attempts < 5 ORDER BY o.id LIMIT ?""",
        (limit,),
    )


def mark_sent(conn: sqlite3.Connection, row_id: int) -> None:
    conn.execute("UPDATE outbox SET sent_at = datetime('now'), attempts = attempts + 1 WHERE id = ?",
                 (row_id,))


def mark_failed(conn: sqlite3.Connection, row_id: int, error: str) -> None:
    conn.execute("UPDATE outbox SET attempts = attempts + 1, last_error = ? WHERE id = ?",
                 (error[:300], row_id))
