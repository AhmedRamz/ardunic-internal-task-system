"""The work that repeats, in the three shapes Ardunic actually has.

A template lives in `routines`; what its `kind` is decides how it reaches people:

  دورية (periodic)   the day is cut into periods, or the week into a rota, and
                     whoever is on duty is asked at the time — the social-media
                     shifts, preparing orders, checking orders. Unchanged.

  روتينية (routine)  work that starts when something arrives and then runs for a
                     few days: a shipment to receive, sort and enter, a delivery
                     to send to Sinaa. Started by hand, given an expected number
                     of days, and tracked day by day until it closes.

  مجدولة (scheduled) work on a wider cycle than a day — weekly or monthly. The
                     system opens it on time, by itself, and then chases it.

The last two end up as ordinary tasks. That is the point: they appear on the
board, take comments, get the 10:00 and 12:00 updates, and land in the ledger
with their timestamps, without a single new mechanism behind them.
"""
from __future__ import annotations

import sqlite3
from calendar import monthrange
from datetime import date, datetime, timedelta

from .. import db, texts
from . import periods as P
from . import tasks as T

PERIODIC, ROUTINE, SCHEDULED = "periodic", "routine", "scheduled"
KINDS = {PERIODIC: "دورية", ROUTINE: "روتينية", SCHEDULED: "مجدولة"}
KIND_HINT = {
    PERIODIC: "تُقسَّم على فترات أو توزيع أسبوعي، ويُسأل من هو على دوامها في وقتها",
    ROUTINE: "تبدأ عند وصول شحنة أو طلب، وتستمر أياماً حتى تُغلق",
    SCHEDULED: "تتكرر أسبوعياً أو شهرياً، ويفتحها النظام في موعدها",
}
TASK_KINDS = {"normal": "عادية", ROUTINE: "روتينية", SCHEDULED: "مجدولة"}
CYCLES = {"weekly": "أسبوعياً", "monthly": "شهرياً"}
DEFAULT_DAYS = 1
MAX_DAYS = 60


class RuleError(P.RuleError):
    """Same shape as the other rule errors, so the pages handle it the same way."""


def _require(condition: bool, ar: str, en: str = "") -> None:
    if not condition:
        raise RuleError(ar, en)


def kind_of(routine: sqlite3.Row) -> str:
    value = (routine["kind"] if "kind" in routine.keys() else None) or PERIODIC
    return value if value in KINDS else PERIODIC


def templates(conn: sqlite3.Connection, kind: str,
              location_id: int | None = None, active: bool = True) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT r.*, u.name AS owner_name FROM routines r
           LEFT JOIN users u ON u.id = r.default_assignee
           WHERE r.kind = ? AND r.active = ? AND (? IS NULL OR r.location_id = ?)
           ORDER BY r.code""",
        (kind, 1 if active else 0, location_id, location_id),
    )


def change_kind(conn: sqlite3.Connection, routine_id: int, kind: str) -> None:
    """Move a template to another kind — how R5 and R7 become روتينية and مجدولة.

    A دورية template that already has periods or a weekly rota keeps them, so it
    cannot be moved until those are cleared; otherwise the rota would point at
    nothing.
    """
    _require(kind in KINDS, "نوع غير معروف", "unknown kind")
    routine = db.one(conn, "SELECT * FROM routines WHERE id = ?", (routine_id,))
    _require(routine is not None, "الروتين غير موجود", "no such routine")
    if kind_of(routine) == PERIODIC and kind != PERIODIC:
        _require(not P.has_periods(conn, routine_id),
                 "احذف فترات هذا الروتين قبل تغيير نوعه", "it still has periods")
        _require(not P.has_rota(conn, routine_id),
                 "أفرغ التوزيع الأسبوعي قبل تغيير نوعه", "it still has a rota")
    db.update(conn, "routines", routine_id, kind=kind)


# ----------------------------------------------------------------- روتينية: starts, then runs for days
def expected_days(routine: sqlite3.Row) -> int:
    value = routine["expected_days"] if "expected_days" in routine.keys() else None
    try:
        return max(1, min(int(value), MAX_DAYS))
    except (TypeError, ValueError):
        return DEFAULT_DAYS


def finish_by(start: date, days: int) -> str:
    """The last day of the run, at the end of the shift."""
    return f"{(start + timedelta(days=max(1, days) - 1)).isoformat()} 17:00"


def start_run(conn: sqlite3.Connection, actor_id: int, routine_id: int, *,
              assignee_id: int = 0, reference: str = "", days: int | None = None,
              description: str = "", now: datetime | None = None) -> tuple[int, T.Event]:
    """Open one run of a روتينية template — a shipment that just landed, say."""
    now = now or texts.now()
    routine = db.one(conn, "SELECT * FROM routines WHERE id = ? AND active = 1", (routine_id,))
    _require(routine is not None, "الروتين غير موجود", "no such routine")
    _require(kind_of(routine) == ROUTINE, "هذا النوع لا يُبدأ يدوياً", "not a started routine")

    who = assignee_id or routine["default_assignee"]
    _require(bool(who), "اختر من يتولاها", "pick who takes it")
    span = max(1, min(int(days or expected_days(routine)), MAX_DAYS))
    title = f"{routine['name']} — {reference.strip()}" if reference.strip() else routine["name"]

    task_id, event = T.create_task(
        conn, actor_id, title, int(who),
        description=description.strip() or routine["instructions"],
        due_at=finish_by(now.date(), span), priority="normal", source="dashboard",
        kind=ROUTINE, template_id=routine_id, expected_days=span)
    return task_id, event


def day_number(task: sqlite3.Row, today: date | None = None) -> tuple[int, int] | None:
    """Which day of the run this is — (2, 3) reads as اليوم 2 من 3."""
    if (task["kind"] if "kind" in task.keys() else "normal") != ROUTINE:
        return None
    span = task["expected_days"] or DEFAULT_DAYS
    try:
        started = datetime.strptime(task["created_at"][:10], "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None
    passed = ((today or texts.now().date()) - started).days + 1
    return max(1, passed), max(span, passed)


def open_runs(conn: sqlite3.Connection, routine_id: int) -> list[sqlite3.Row]:
    return db.all_rows(
        conn,
        """SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
           WHERE t.template_id = ? AND t.status NOT IN ('done','cancelled')
           ORDER BY t.id DESC""",
        (routine_id,),
    )


# ----------------------------------------------------------------- مجدولة: the system opens it
def cycle_of(routine: sqlite3.Row) -> str:
    value = (routine["cycle"] if "cycle" in routine.keys() else None) or "monthly"
    return value if value in CYCLES else "monthly"


def cycle_day(routine: sqlite3.Row) -> int:
    value = routine["cycle_day"] if "cycle_day" in routine.keys() else None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return 1
    return max(0, min(number, 6)) if cycle_of(routine) == "weekly" else max(1, min(number, 28))


def falls_on(routine: sqlite3.Row, day: date) -> bool:
    """Is this the day the template is due to open?"""
    if cycle_of(routine) == "weekly":
        return P.ALL_WEEKDAYS[cycle_day(routine)] == P.weekday_key(day)
    wanted = cycle_day(routine)
    last = monthrange(day.year, day.month)[1]
    return day.day == min(wanted, last)          # the 30th of a 28-day month is its last day


def next_due(routine: sqlite3.Row, today: date) -> date:
    for ahead in range(0, 400):
        day = today + timedelta(days=ahead)
        if falls_on(routine, day):
            return day
    return today


def cycle_label(routine: sqlite3.Row) -> str:
    if cycle_of(routine) == "weekly":
        return f"كل {P.WEEKDAY_AR[P.ALL_WEEKDAYS[cycle_day(routine)]]}"
    return f"يوم {cycle_day(routine)} من كل شهر"


def _already_opened(conn: sqlite3.Connection, routine_id: int, day: date) -> bool:
    return db.one(
        conn,
        "SELECT 1 FROM routine_runs WHERE routine_id = ? AND date = ? AND kind = 'scheduled'",
        (routine_id, day.isoformat())) is not None


def due_today(conn: sqlite3.Connection, now: datetime) -> list[sqlite3.Row]:
    """Scheduled templates that should be opened today and have not been."""
    day = now.date()
    out = []
    for routine in templates(conn, SCHEDULED):
        if falls_on(routine, day) and not _already_opened(conn, routine["id"], day):
            out.append(routine)
    return out


def open_scheduled(conn: sqlite3.Connection, routine: sqlite3.Row,
                   now: datetime) -> tuple[int, T.Event] | None:
    """Open today's instance of a مجدولة template, once."""
    day = now.date()
    db.insert(conn, "routine_runs", routine_id=routine["id"], date=day.isoformat(),
              kind="scheduled", sent=0)
    who = routine["default_assignee"]
    if not who:
        return None
    opener = db.one(
        conn,
        """SELECT id FROM users WHERE active = 1 AND (role = 'gm'
             OR (role = 'manager' AND location_id = ?)) ORDER BY role LIMIT 1""",
        (routine["location_id"],))
    if opener is None:
        return None
    span = expected_days(routine)
    return T.create_task(
        conn, opener["id"], routine["name"], int(who),
        description=routine["instructions"], due_at=finish_by(day, span),
        priority="normal", source="dashboard", kind=SCHEDULED,
        template_id=routine["id"], expected_days=span)


def history(conn: sqlite3.Connection, routine_id: int, limit: int = 12) -> list[sqlite3.Row]:
    """The last few runs of a template, whatever its kind."""
    return db.all_rows(
        conn,
        """SELECT t.*, u.name AS assignee_name FROM tasks t LEFT JOIN users u ON u.id = t.assignee_id
           WHERE t.template_id = ? ORDER BY t.id DESC LIMIT ?""",
        (routine_id, limit),
    )
