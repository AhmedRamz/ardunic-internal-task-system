"""Configuration from environment variables (.env in development, systemd EnvironmentFile in production)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def _load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


@dataclass(frozen=True)
class Config:
    bot_token: str
    db_path: str
    timezone: str
    base_url: str
    swap_deadline_hours: int
    accept_reminder_hours: int
    accept_escalate_hours: int

    @classmethod
    def load(cls, dotenv: str | Path = ".env") -> "Config":
        _load_dotenv(Path(dotenv))
        return cls(
            bot_token=os.environ.get("BOT_TOKEN", ""),
            db_path=os.environ.get("DB_PATH", "ims.db"),
            timezone=os.environ.get("TIMEZONE", "Asia/Baghdad"),
            base_url=os.environ.get("BASE_URL", "http://localhost:8000"),
            swap_deadline_hours=int(os.environ.get("SWAP_DEADLINE_HOURS", "2")),
            accept_reminder_hours=int(os.environ.get("ACCEPT_REMINDER_HOURS", "2")),
            accept_escalate_hours=int(os.environ.get("ACCEPT_ESCALATE_HOURS", "4")),
        )
