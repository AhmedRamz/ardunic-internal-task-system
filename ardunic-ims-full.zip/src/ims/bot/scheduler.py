"""The minute tick that runs the day: briefs, updates, close-out, report, reminders.

Everything it decides comes from core/schedule.py; this file only queues the
messages and records that a slot has run.
"""
from __future__ import annotations

import asyncio
import logging
import sqlite3

from .. import db, texts
from ..core import notify, schedule
from ..core import periods as P
from ..core import tasks as T

log = logging.getLogger(__name__)
TICK_SECONDS = 60


def _dispatch_slot(conn: sqlite3.Connection, slot: sqlite3.Row, now) -> int:
    """Queue everything one slot sends. Returns the number of messages queued."""
    sent = 0
    location = slot["location_id"]

    if slot["kind"] == "brief":
        for person in schedule.employees(conn, location):
            if schedule.on_leave(conn, person["id"], now.date()):
                continue
            body = schedule.brief_for(conn, person, now)
            if body and notify.queue_raw(conn, person["id"], body, keyboard="none", action="brief"):
                sent += 1
        for boss in schedule.supervisors(conn, location):
            body = schedule.manager_overview(conn, location, now)
            if notify.queue_raw(conn, boss["id"], body, keyboard="none", action="overview"):
                sent += 1

    elif slot["kind"] == "update":
        header = f"<b>تحديث {slot['time']}</b>\nاختر حالة كل مهمة:"
        for person in schedule.employees(conn, location):
            items = schedule.update_items(conn, person)
            if not items or schedule.on_leave(conn, person["id"], now.date()):
                continue
            if notify.queue_raw(conn, person["id"], header, keyboard="none", action="update"):
                sent += 1
            for task in items:
                body = texts.task_line(task)
                if notify.queue_raw(conn, person["id"], body, task_id=task["id"],
                                    keyboard="update", action="update_item"):
                    sent += 1

    elif slot["kind"] == "closeout":
        header = ("<b>إغلاق اليوم</b> · " + slot["time"] +
                  "\nحدّث مهامك المفتوحة قبل نهاية الدوام:")
        for person in schedule.employees(conn, location):
            items = schedule.update_items(conn, person)
            if not items or schedule.on_leave(conn, person["id"], now.date()):
                continue
            if notify.queue_raw(conn, person["id"], header, keyboard="none", action="closeout"):
                sent += 1
            for task in items:
                if notify.queue_raw(conn, person["id"], texts.task_line(task), task_id=task["id"],
                                    keyboard="closeout", action="closeout_item"):
                    sent += 1

    elif slot["kind"] == "report":
        body = schedule.day_report(conn, location, now)
        for boss in schedule.supervisors(conn, location):
            if notify.queue_raw(conn, boss["id"], body, keyboard="none", action="report"):
                sent += 1

    return sent


def _dispatch_reminders(conn: sqlite3.Connection, now, remind_after: int, escalate_after: int) -> int:
    sent = 0
    for task, kind in schedule.unaccepted_reminders(conn, now, remind_after, escalate_after):
        if kind == "remind":
            body = (f"⏰ تذكير: المهمة #{task['id']} ما زالت بانتظار قبولك.\n{task['title']}")
            if task["assignee_id"] and notify.queue_raw(conn, task["assignee_id"], body,
                                                        task_id=task["id"], keyboard="task",
                                                        action="accept_reminder"):
                sent += 1
            db.insert(conn, "task_events", task_id=task["id"], actor_id=None,
                      action="accept_reminder", from_status=task["status"], to_status=task["status"],
                      created_at=now.strftime("%Y-%m-%d %H:%M:%S"))
        else:
            who = db.one(conn, "SELECT name FROM users WHERE id = ?", (task["assignee_id"],))
            body = (f"⚠️ المهمة #{task['id']} لم تُقبل بعد.\n{task['title']}\n"
                    f"المسؤول: {who['name'] if who else '—'}")
            for boss in schedule.supervisors(conn, task["location_id"]):
                if notify.queue_raw(conn, boss["id"], body, task_id=task["id"], keyboard="task",
                                    action="accept_escalated"):
                    sent += 1
            db.insert(conn, "task_events", task_id=task["id"], actor_id=None,
                      action="accept_escalated", from_status=task["status"], to_status=task["status"],
                      created_at=now.strftime("%Y-%m-%d %H:%M:%S"))

    for task in schedule.overdue_alerts(conn, now):
        body = f"🔴 تجاوزت المهمة #{task['id']} موعدها.\n{task['title']}\nالموعد كان: {texts.due_label(task['due_at'])}"
        targets = [task["assignee_id"], *[b["id"] for b in schedule.supervisors(conn, task["location_id"])]]
        for user_id in dict.fromkeys(t for t in targets if t):
            if notify.queue_raw(conn, user_id, body, task_id=task["id"], keyboard="task",
                                action="overdue"):
                sent += 1
        db.insert(conn, "task_events", task_id=task["id"], actor_id=None, action="overdue_flagged",
                  from_status=task["status"], to_status=task["status"],
                  created_at=now.strftime("%Y-%m-%d %H:%M:%S"))
    return sent


def _queue(conn: sqlite3.Connection, messages, action: str) -> int:
    """Put a list of periods.Message on the outbox. Returns how many went on."""
    sent = 0
    for message in messages:
        if notify.queue_raw(conn, message.user_id, message.body,
                            keyboard=message.keyboard, action=action):
            sent += 1
    return sent


def _dispatch_periods(conn: sqlite3.Connection, now) -> int:
    """Period check-ins 15 minutes before the end, gap alerts, and dead cover requests.

    Runs every day — the social-media periods cover Friday too, when the shop is
    closed and the task side of the system is silent.
    """
    sent = 0
    for item in P.due_checkins(conn, now):
        period, day, person = item["period"], item["date"], item["holder"]
        if item["late"] or person is None:          # too late to ask, or nobody to ask
            P.mark_run(conn, period["id"], day, "checkin", 0)
            continue
        count = _queue(conn, [P.checkin_message(conn, period, day, person)], "period_checkin")
        P.mark_run(conn, period["id"], day, "checkin", count)
        sent += count

    for item in P.due_gaps(conn, now):
        period, day = item["period"], item["date"]
        count = 0 if item["late"] else _queue(conn, P.gap_message(conn, period, day), "period_gap")
        P.mark_run(conn, period["id"], day, "gap", count)
        sent += count

    # routines with no periods (R2–R7): one question a day, to their owners
    for item in P.due_routine_checkins(conn, now):
        routine, day, owners = item["routine"], item["date"], item["owners"]
        here = 0
        if item["late"]:
            pass                                     # too late to be useful; just record it
        elif not owners:
            here = _queue(conn, P.ownerless_message(conn, routine), "routine_ownerless")
        else:
            here = _queue(conn, [P.routine_checkin_message(routine, day, person)
                                 for person in owners
                                 if not schedule.on_leave(conn, person["id"], day)],
                          "routine_checkin")
        P.mark_routine_run(conn, routine["id"], day, here)
        sent += here

    sent += _queue(conn, P.expire_requests(conn, now), "cover_expired")
    return sent


def tick(conn: sqlite3.Connection, now, remind_after: int = 2, escalate_after: int = 4) -> int:
    """One pass of the clock. Returns how many messages were queued."""
    queued = 0
    for slot in schedule.due_slots(conn, now):
        if schedule.is_stale(slot, now):
            schedule.mark_slot_run(conn, slot["id"], now.date(), 0)
            log.info("slot %s %s skipped: %s minutes late", slot["kind"], slot["time"],
                     schedule.minutes_late(slot, now))
            continue
        count = _dispatch_slot(conn, slot, now)
        schedule.mark_slot_run(conn, slot["id"], now.date(), count)
        log.info("slot %s %s fired: %s message(s)", slot["kind"], slot["time"], count)
        queued += count
    queued += _dispatch_reminders(conn, now, remind_after, escalate_after)
    queued += _dispatch_periods(conn, now)
    return queued


async def scheduler_worker(conn: sqlite3.Connection, remind_after: int, escalate_after: int) -> None:
    log.info("scheduler started (tick every %ss, timezone %s)", TICK_SECONDS, texts.TZ)
    while True:
        try:
            tick(conn, texts.now(), remind_after, escalate_after)
        except Exception as exc:                      # a bad day must not stop the clock
            log.exception("scheduler tick failed: %s", exc)
        await asyncio.sleep(TICK_SECONDS)
