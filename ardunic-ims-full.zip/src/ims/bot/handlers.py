"""Bot conversation: linking, creating tasks, and the action buttons."""
from __future__ import annotations

import sqlite3
from datetime import date, timedelta

from aiogram import F, Router
from aiogram.filters import Command, CommandObject
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from .. import db, texts
from ..core import periods as P
from ..core import schedule
from ..core import tasks as T
from . import keyboards as kb
from . import menu
from .notify import send_event, send_messages

router = Router()


class New(StatesGroup):
    title = State()
    description = State()
    due_custom = State()


class Flow(StatesGroup):
    checkin_note = State()
    cover_reason = State()
    cover_decline = State()
    period_count = State()
    period_note = State()
    reject_reason = State()
    handover_reason = State()
    delegate_note = State()
    review_note = State()
    comment = State()
    suggest_title = State()
    cancel_reason = State()


# ----------------------------------------------------------------- helpers
def user_of(conn: sqlite3.Connection, telegram_id: int) -> sqlite3.Row | None:
    return db.one(conn, "SELECT * FROM users WHERE telegram_id = ? AND active = 1", (telegram_id,))


def assignable(conn: sqlite3.Connection, actor: sqlite3.Row) -> list[sqlite3.Row]:
    """Who this person may hand work to."""
    if actor["role"] == "gm":
        return db.all_rows(
            conn,
            "SELECT * FROM users WHERE active = 1 AND role != 'gm' AND telegram_id IS NOT NULL ORDER BY role, name",
        )
    return db.all_rows(
        conn,
        """SELECT * FROM users WHERE active = 1 AND role = 'employee' AND location_id = ?
           AND telegram_id IS NOT NULL ORDER BY name""",
        (actor["location_id"],),
    )


async def show_task(message: Message, conn: sqlite3.Connection, task_id: int, viewer: sqlite3.Row) -> None:
    task = T.get_task(conn, task_id)
    creator = db.one(conn, "SELECT name FROM users WHERE id = ?", (task["created_by"],))
    assignee = db.one(conn, "SELECT name FROM users WHERE id = ?", (task["assignee_id"],)) \
        if task["assignee_id"] else None
    handover = db.one(conn, "SELECT * FROM handovers WHERE task_id = ? ORDER BY id DESC LIMIT 1", (task_id,))
    await message.answer(
        texts.task_card(task, creator=creator["name"] if creator else "",
                        assignee=assignee["name"] if assignee else ""),
        reply_markup=kb.task_actions(task, viewer, handover),
    )


async def draft_summary(message: Message, state: FSMContext, conn: sqlite3.Connection) -> None:
    draft = await state.get_data()
    assignee = db.one(conn, "SELECT * FROM users WHERE id = ?", (draft["assignee_id"],))
    body = (f"<b>مراجعة المهمة قبل الإرسال</b>\n{draft['title']}\n"
            f"المسؤول: {assignee['name']} ({texts.ROLE[assignee['role']]})")
    if draft.get("description"):
        body += f"\n\n{draft['description']}"
    body += "\n\n<i>اضغط على أي زر لتغييره</i>"
    await message.answer(body, reply_markup=kb.draft_keyboard(draft))


# ----------------------------------------------------------------- linking and reading
@router.message(Command("start"))
async def cmd_start(message: Message, command: CommandObject, conn: sqlite3.Connection) -> None:
    existing = user_of(conn, message.from_user.id)
    if existing:
        await menu.apply(message.bot, message.from_user.id, existing["role"])
        await message.answer(texts.help_for(existing["role"]))
        return
    code = (command.args or "").strip()
    row = db.one(
        conn,
        """SELECT * FROM users WHERE link_code = ? AND active = 1
           AND (link_code_expires IS NULL OR link_code_expires > datetime('now'))""",
        (code,),
    ) if code else None
    if row is None:
        await message.answer(texts.LINK_BAD if code else texts.NOT_LINKED)
        return
    db.update(conn, "users", row["id"], telegram_id=message.from_user.id,
              telegram_username=message.from_user.username, link_code=None, link_code_expires=None)
    location = db.one(conn, "SELECT name FROM locations WHERE id = ?", (row["location_id"],))
    await menu.apply(message.bot, message.from_user.id, row["role"])     # their role's menu button
    await message.answer(texts.LINK_DONE.format(name=row["name"],
                                                location=location["name"] if location else ""))
    await message.answer(texts.help_for(row["role"]))


@router.message(Command("help"))
async def cmd_help(message: Message, user: sqlite3.Row | None = None) -> None:
    await message.answer(texts.help_for(user["role"] if user else None))


@router.message(Command("mytasks"))
async def cmd_mytasks(message: Message, conn: sqlite3.Connection, user: sqlite3.Row) -> None:
    rows = T.open_tasks_for(conn, user["id"])
    await message.answer(texts.my_tasks(rows, user["name"]))
    for row in rows[:5]:                     # the first few with their buttons
        await show_task(message, conn, row["id"], user)


@router.message(Command("task"))
async def cmd_task(message: Message, command: CommandObject, conn: sqlite3.Connection,
                   user: sqlite3.Row) -> None:
    raw = (command.args or "").strip().lstrip("#")
    if not raw.isdigit():
        await message.answer("أرسل رقم المهمة: <code>/task 124</code>")
        return
    task = db.one(conn, "SELECT * FROM tasks WHERE id = ?", (int(raw),))
    if task is None or task["id"] not in {t["id"] for t in T.visible_tasks(conn, user["id"])}:
        await message.answer("المهمة غير موجودة أو ليست من صلاحيتك.")
        return
    await show_task(message, conn, task["id"], user)


# ----------------------------------------------------------------- the manager's report
TELEGRAM_LIMIT = 3500          # a message may hold 4096; leave room for the HTML tags


async def send_long(message: Message, body: str, reply_markup=None) -> None:
    """Telegram caps a message, so a long report goes out in whole blocks."""
    chunks: list[str] = []
    current = ""
    for block in body.split("\n\n"):
        if len(current) + len(block) + 2 > TELEGRAM_LIMIT and current:
            chunks.append(current)
            current = block
        else:
            current = f"{current}\n\n{block}" if current else block
    chunks.append(current)
    for index, chunk in enumerate(chunks):
        await message.answer(chunk, reply_markup=reply_markup if index == len(chunks) - 1 else None)


REPORT_VIEWS = {
    "team": schedule.team_report,          # every person and where each task stands
    "status": schedule.manager_overview,   # grouped by what needs attention
    "day": schedule.day_report,            # what happened today
}


async def send_report(message: Message, conn: sqlite3.Connection, user: sqlite3.Row,
                      view: str) -> None:
    scope = None if user["role"] == "gm" else user["location_id"]      # the GM sees every branch
    body = REPORT_VIEWS[view](conn, scope, texts.now())
    await send_long(message, body, kb.report_views(view))


@router.message(Command("report"))
async def cmd_report(message: Message, conn: sqlite3.Connection, user: sqlite3.Row) -> None:
    if user["role"] not in ("gm", "manager"):
        await message.answer("التقارير للمدراء. استخدم /mytasks لعرض مهامك.")
        return
    await send_report(message, conn, user, "team")


@router.callback_query(F.data.startswith("rep:"))
async def report_view(call: CallbackQuery, conn: sqlite3.Connection, user: sqlite3.Row) -> None:
    view = call.data.split(":")[1]
    if user["role"] not in ("gm", "manager") or view not in REPORT_VIEWS:
        return await call.answer()
    await call.message.edit_reply_markup(reply_markup=None)
    await send_report(call.message, conn, user, view)
    await call.answer()


# ----------------------------------------------------------------- creating a task
@router.message(Command("new"))
async def cmd_new(message: Message, state: FSMContext, conn: sqlite3.Connection,
                  user: sqlite3.Row) -> None:
    if user["role"] not in ("gm", "manager"):
        await message.answer("إنشاء المهام للمدراء. استخدم /suggest لاقتراح مهمة على مديرك.")
        return
    await state.clear()
    await state.set_state(New.title)
    await message.answer(texts.ASK_TITLE)


@router.message(New.title)
async def new_title(message: Message, state: FSMContext, conn: sqlite3.Connection,
                    user: sqlite3.Row) -> None:
    people = assignable(conn, user)
    if not people:
        await message.answer("لا يوجد موظفون مرتبطون بالبوت بعد.")
        await state.clear()
        return
    await state.update_data(title=message.text.strip(), description="",
                           due_at=texts.today_at(17), due_label="اليوم 5:00 م",
                           priority="normal", priority_label="عادية",
                           needs_review=False, allow_delegation=False)
    await state.set_state(None)
    await message.answer(texts.ASK_ASSIGNEE, reply_markup=kb.people_picker(people, "na", 0))


@router.callback_query(F.data.startswith("na:"))
async def new_assignee(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection) -> None:
    assignee_id = int(call.data.split(":")[2])
    assignee = db.one(conn, "SELECT * FROM users WHERE id = ?", (assignee_id,))
    await state.update_data(assignee_id=assignee_id,
                            assignee_is_manager=assignee["role"] == "manager",
                            allow_delegation=assignee["role"] == "manager")
    await call.message.delete()
    await draft_summary(call.message, state, conn)
    await call.answer()


@router.callback_query(F.data == "d:due")
async def draft_due(call: CallbackQuery) -> None:
    await call.message.edit_reply_markup(reply_markup=kb.due_picker())
    await call.answer()


@router.callback_query(F.data.startswith("due:"))
async def draft_due_pick(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection) -> None:
    choice = call.data.split(":")[1]
    if choice == "custom":
        await state.set_state(New.due_custom)
        await call.message.answer(texts.ASK_DUE_CUSTOM)
        await call.answer()
        return
    values = {"today": (texts.today_at(17), "اليوم 5:00 م"),
              "tomorrow": (texts.tomorrow_at(17), "غداً 5:00 م"),
              "none": (None, "بدون موعد")}[choice]
    await state.update_data(due_at=values[0], due_label=values[1])
    await call.message.delete()
    await draft_summary(call.message, state, conn)
    await call.answer()


@router.message(New.due_custom)
async def draft_due_custom(message: Message, state: FSMContext, conn: sqlite3.Connection) -> None:
    raw = message.text.strip()
    await state.update_data(due_at=raw, due_label=texts.due_label(raw))
    await state.set_state(None)
    await draft_summary(message, state, conn)


@router.callback_query(F.data == "d:priority")
async def draft_priority(call: CallbackQuery) -> None:
    await call.message.edit_reply_markup(reply_markup=kb.priority_picker())
    await call.answer()


@router.callback_query(F.data.startswith("prio:"))
async def draft_priority_pick(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection) -> None:
    value = call.data.split(":")[1]
    await state.update_data(priority=value, priority_label=texts.PRIORITY[value])
    await call.message.delete()
    await draft_summary(call.message, state, conn)
    await call.answer()


@router.callback_query(F.data.in_({"d:review", "d:delegation"}))
async def draft_toggle(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection) -> None:
    key = "needs_review" if call.data == "d:review" else "allow_delegation"
    data = await state.get_data()
    await state.update_data(**{key: not data.get(key)})
    await call.message.delete()
    await draft_summary(call.message, state, conn)
    await call.answer()


@router.callback_query(F.data == "d:description")
async def draft_description(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(New.description)
    await call.message.answer("أرسل وصف المهمة:")
    await call.answer()


@router.message(New.description)
async def draft_description_text(message: Message, state: FSMContext, conn: sqlite3.Connection) -> None:
    await state.update_data(description=message.text.strip())
    await state.set_state(None)
    await draft_summary(message, state, conn)


@router.callback_query(F.data == "d:cancel")
async def draft_cancel(call: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await call.message.edit_text(texts.CANCELLED_FLOW)
    await call.answer()


@router.callback_query(F.data == "d:confirm")
async def draft_confirm(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                        user: sqlite3.Row) -> None:
    d = await state.get_data()
    try:
        task_id, event = T.create_task(
            conn, user["id"], d["title"], d["assignee_id"],
            description=d.get("description", ""), due_at=d.get("due_at"),
            priority=d.get("priority", "normal"), needs_review=bool(d.get("needs_review")),
            allow_delegation=bool(d.get("allow_delegation")), source="bot",
        )
    except T.RuleError as exc:
        await call.answer(exc.ar, show_alert=True)
        return
    await state.clear()
    assignee = db.one(conn, "SELECT name FROM users WHERE id = ?", (d["assignee_id"],))
    await call.message.edit_text(f"تم إنشاء المهمة #{task_id} وإرسالها إلى {assignee['name']}.")
    await send_event(call.bot, conn, event)
    await call.answer()


# ----------------------------------------------------------------- suggestions
@router.message(Command("suggest"))
async def cmd_suggest(message: Message, state: FSMContext, user: sqlite3.Row) -> None:
    if user["role"] == "gm":
        await message.answer("المدير العام ينشئ المهام مباشرة: /new")
        return
    await state.set_state(Flow.suggest_title)
    await message.answer("ما المهمة التي تقترحها؟")


@router.message(Flow.suggest_title)
async def suggest_title(message: Message, state: FSMContext, conn: sqlite3.Connection,
                        user: sqlite3.Row) -> None:
    await state.clear()
    try:
        task_id, event = T.suggest_task(conn, user["id"], message.text.strip())
    except T.RuleError as exc:
        await message.answer(f"⚠️ {exc.ar}")
        return
    delivered = await send_event(message.bot, conn, event)
    if delivered:
        await message.answer(f"أُرسل الاقتراح #{task_id} إلى مديرك للموافقة.")
    else:
        await message.answer(
            f"سُجّل الاقتراح #{task_id} وسيظهر في لوحة المدير،\n"
            "لكن لم يربط أي مدير حسابه بالبوت بعد فلن يصله تنبيه الآن."
        )


# ----------------------------------------------------------------- routines and periods
@router.message(Command("routines"))
async def cmd_routines(message: Message, conn: sqlite3.Connection, user: sqlite3.Row) -> None:
    rows = P.routines_of(conn, user["id"])
    if not rows:
        await message.answer("لا يوجد روتين مسند إليك. مديرك يسندها من اللوحة.")
        return
    parts = [f"<b>روتين {user['name']}</b>"]
    for routine in rows:
        line = f"\n<b>{routine['code']} · {routine['name']}</b>"
        if routine["owner_role"] == "backup":
            line += " <i>(احتياط)</i>"
        if routine["instructions"]:
            line += f"\n{routine['instructions']}"
        parts.append(line)
    await send_long(message, "\n".join(parts))


@router.message(Command("myperiods"))
async def cmd_myperiods(message: Message, conn: sqlite3.Connection, user: sqlite3.Row) -> None:
    today = texts.now().date()
    entries = P.my_periods(conn, user["id"], today, days=7)
    if not entries:
        await message.answer("لا فترات مسندة إليك في الأيام السبعة القادمة.")
        return
    lines = [f"<b>فتراتي — 7 أيام</b>"]
    for entry in entries:
        period, day = entry["period"], entry["date"]
        when = "اليوم" if day == today else P.WEEKDAY_AR[P.weekday_key(day)]
        lines.append(f"• {when} {day.isoformat()} · {period['name']} "
                     f"{period['start_time']}–{period['end_time']} — {period['code']}")
    upcoming = [e for e in entries if e["start"] > texts.now()]      # only a future one can be covered
    await message.answer("\n".join(lines), reply_markup=kb.my_periods(upcoming[:8]))


@router.message(Command("periods"))
async def cmd_periods_today(message: Message, conn: sqlite3.Connection, user: sqlite3.Row) -> None:
    """A manager's view: who holds every period today, gaps in red."""
    if user["role"] not in ("gm", "manager"):
        return await cmd_myperiods(message, conn, user)
    today = texts.now().date()
    scope = None if user["role"] == "gm" else user["location_id"]
    board = P.day_board(conn, today, scope)
    if not board:
        await message.answer("لا فترات اليوم.")
        return
    reasons = {"swap": "تغطية", "leave": "بدل إجازة", "absence": "بدل غياب", "manager": "تعيين المدير"}
    lines = [f"<b>فترات اليوم</b> · {P.WEEKDAY_AR[P.weekday_key(today)]} {today.isoformat()}"]
    for row in board:
        period = row["period"]
        head = f"• {period['start_time']}–{period['end_time']} {period['name']}"
        if row["is_gap"]:
            lines.append(f"{head} — 🔴 <b>بلا مسؤول</b>")
        else:
            tail = f" ({reasons[row['reason']]})" if row["reason"] else ""
            lines.append(f"{head} — {row['holder']['name']}{tail}")
    await send_long(message, "\n".join(lines))


@router.callback_query(F.data.startswith("pc:"))
async def cover_pick_person(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                            user: sqlite3.Row) -> None:
    """The employee tapped 'ask someone to cover' on one of their periods."""
    _, raw_period, raw_date = call.data.split(":", 2)
    period_id, day = int(raw_period), date.fromisoformat(raw_date)
    period = P.get_period(conn, period_id)
    hours = P.deadline_hours(conn)
    if P.start_at(period, day) - texts.now() < timedelta(hours=hours):
        return await call.answer(f"فات وقت الطلب — قبل {hours} ساعتين على الأقل من بداية الفترة.",
                                 show_alert=True)
    people = P.cover_candidates(conn, user, period_id, day)
    if not people:
        await call.message.answer("لا يوجد زميل متفرغ في هذا الوقت. تحدّث مع المدير.")
        return await call.answer()
    await state.update_data(period_id=period_id, date=raw_date)
    await call.message.answer(
        f"{P.label(period, day)}\nمن تطلب منه التغطية؟",
        reply_markup=kb.people_picker(people, "cp", period_id))
    await call.answer()


@router.callback_query(F.data.startswith("cp:"))
async def cover_reason(call: CallbackQuery, state: FSMContext) -> None:
    target_id = int(call.data.split(":")[2])
    await state.update_data(target_id=target_id)
    await state.set_state(Flow.cover_reason)
    await call.message.edit_text("اكتب سبب طلب التغطية (أو «-» بدون سبب):")
    await call.answer()


@router.message(Flow.cover_reason)
async def cover_send(message: Message, state: FSMContext, conn: sqlite3.Connection,
                     user: sqlite3.Row) -> None:
    data = await state.get_data()
    await state.clear()
    reason = "" if message.text.strip() == "-" else message.text.strip()
    try:
        _, messages = P.request_cover(conn, user["id"], data["period_id"],
                                      date.fromisoformat(data["date"]), data["target_id"], reason)
    except P.RuleError as exc:
        await message.answer(f"⚠️ {exc.ar}")
        return
    target = db.one(conn, "SELECT name FROM users WHERE id = ?", (data["target_id"],))
    await message.answer(f"أُرسل الطلب إلى {target['name']}.\n"
                         "بعد موافقته يعتمده مدير الفرع، وحتى ذلك الحين الفترة لك.")
    await send_messages(message.bot, conn, messages, action="cover_request")


@router.callback_query(F.data.startswith("cv:"))
async def cover_decide(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                       user: sqlite3.Row) -> None:
    _, answer, raw_id = call.data.split(":")
    request_id = int(raw_id)
    if answer == "no":                                   # the colleague says no, with a reason
        await state.set_state(Flow.cover_decline)
        await state.update_data(request_id=request_id)
        await call.message.answer("اكتب سبب الاعتذار (أو «-»):")
        return await call.answer()
    try:
        if answer == "yes":
            messages = P.colleague_accepts(conn, user["id"], request_id)
            said = "وافقت على التغطية. بانتظار موافقة المدير."
        elif answer == "ok":
            messages = P.manager_approves(conn, user["id"], request_id)
            said = "تمت الموافقة وانتقلت الفترة."
        else:
            messages = P.manager_declines(conn, user["id"], request_id)
            said = "رُفض الطلب."
    except P.RuleError as exc:
        return await call.answer(exc.ar, show_alert=True)
    await call.message.edit_reply_markup(reply_markup=None)
    await call.message.answer(said)
    await send_messages(call.bot, conn, messages, action="cover_decision")
    await call.answer()


@router.message(Flow.cover_decline)
async def cover_declined(message: Message, state: FSMContext, conn: sqlite3.Connection,
                         user: sqlite3.Row) -> None:
    data = await state.get_data()
    await state.clear()
    reason = "" if message.text.strip() == "-" else message.text.strip()
    try:
        messages = P.colleague_declines(conn, user["id"], data["request_id"], reason)
    except P.RuleError as exc:
        await message.answer(f"⚠️ {exc.ar}")
        return
    await message.answer("تم إبلاغ زميلك.")
    await send_messages(message.bot, conn, messages, action="cover_decision")


@router.callback_query(F.data.startswith("pk:"))
async def period_checkin(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                         user: sqlite3.Row) -> None:
    """The answer to the end-of-period check-in."""
    _, result, raw_period, raw_date = call.data.split(":", 3)
    period_id, day = int(raw_period), date.fromisoformat(raw_date)
    period = P.get_period(conn, period_id)
    P.log_period(conn, user["id"], period_id, day, result)
    await call.message.edit_reply_markup(reply_markup=None)

    if result == "done" and period["count_label"]:
        await state.set_state(Flow.period_count)
        await state.update_data(period_id=period_id, date=raw_date)
        await call.message.answer(f"اكتب العدد — {period['count_label']} (أو «-»):")
        return await call.answer()
    if result in ("partly", "not_done"):
        await state.set_state(Flow.period_note)
        await state.update_data(period_id=period_id, date=raw_date, result=result)
        await call.message.answer("اكتب سبباً قصيراً — سيصل المدير:")
        return await call.answer()
    await call.message.answer(f"سُجّلت الفترة: {P.RESULTS[result]}. شكراً.")
    await call.answer()


@router.message(Flow.period_count)
async def period_count(message: Message, state: FSMContext, conn: sqlite3.Connection,
                       user: sqlite3.Row) -> None:
    data = await state.get_data()
    await state.clear()
    raw = message.text.strip()
    count = int(raw) if raw.isdigit() else None
    P.log_period(conn, user["id"], data["period_id"], date.fromisoformat(data["date"]),
                 "done", count=count)
    await message.answer("سُجّلت الفترة: تمت. شكراً." if count is None
                         else f"سُجّلت الفترة: تمت · {count}. شكراً.")


@router.message(Flow.period_note)
async def period_note(message: Message, state: FSMContext, conn: sqlite3.Connection,
                      user: sqlite3.Row) -> None:
    data = await state.get_data()
    await state.clear()
    note = "" if message.text.strip() == "-" else message.text.strip()
    period = P.get_period(conn, data["period_id"])
    day = date.fromisoformat(data["date"])
    P.log_period(conn, user["id"], data["period_id"], day, data["result"], note=note)
    await message.answer("تم التسجيل وأُبلغ المدير.")
    body = (f"⚠️ <b>فترة {P.RESULTS[data['result']]}</b>\n{P.label(period, day)}\n"
            f"{user['name']}" + (f"\nالسبب: {note}" if note else ""))
    await send_messages(message.bot, conn,
                        [P.Message(m["id"], body) for m in P.managers_of(conn, period["location_id"])],
                        action="period_problem")


# ----------------------------------------------------------------- task buttons
SIMPLE = {
    "accept": lambda conn, uid, tid: T.accept(conn, uid, tid),
    "done": lambda conn, uid, tid: T.mark_done(conn, uid, tid),
    "ho_ok": lambda conn, uid, tid: T.approve_handover(conn, uid, tid),
    "ho_no": lambda conn, uid, tid: T.decline_handover(conn, uid, tid),
    "ho_take": lambda conn, uid, tid: T.accept_handover(conn, uid, tid),
    "rev_ok": lambda conn, uid, tid: T.review_approve(conn, uid, tid),
}
ASK = {
    "reject": (Flow.reject_reason, texts.ASK_REASON_REJECT),
    "rev_back": (Flow.review_note, texts.ASK_RETURN_NOTE),
    "comment": (Flow.comment, "اكتب تعليقك:"),
    "cancel": (Flow.cancel_reason, "اكتب سبب الإلغاء:"),
    "ho_drop": (Flow.reject_reason, "اكتب سبب رفض الاستلام:"),
}


@router.callback_query(F.data.startswith("ck:"))
async def checkin_button(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                         user: sqlite3.Row) -> None:
    """Answers to the 10:00 / 12:00 / 2:00 updates and the 4:30 close-out."""
    _, answer, raw_id = call.data.split(":")
    task_id = int(raw_id)
    kind = "closeout" if answer == "carry" else "update"

    if answer in ("block", "carry"):                       # both need a note before anything changes
        prompt = ("ما سبب التوقف؟ سيُبلَّغ المدير." if answer == "block"
                  else "اكتب ملاحظة قصيرة عن سبب الترحيل:")
        await state.set_state(Flow.checkin_note)
        await state.update_data(task_id=task_id, action=f"ck_{answer}", kind=kind)
        await call.message.answer(prompt)
        return await call.answer()

    try:
        if answer == "done":
            event = T.mark_done(conn, user["id"], task_id)
        else:
            event = T.post_update(conn, user["id"], task_id, "working")
    except T.RuleError as exc:
        return await call.answer(exc.ar, show_alert=True)

    schedule.record_checkin(conn, user["id"], task_id, kind,
                            "done" if answer == "done" else "working")
    await call.message.edit_reply_markup(reply_markup=None)
    status = texts.STATUS[T.get_task(conn, task_id)["status"]]
    await call.message.answer(f"تم تسجيل #{task_id}: {status}")
    await send_event(call.bot, conn, event)
    await call.answer()


@router.message(Flow.checkin_note)
async def checkin_note(message: Message, state: FSMContext, conn: sqlite3.Connection,
                       user: sqlite3.Row) -> None:
    data = await state.get_data()
    task_id, action, kind = data.get("task_id"), data.get("action"), data.get("kind", "update")
    text = message.text.strip()
    try:
        if action == "ck_block":
            event = T.post_update(conn, user["id"], task_id, "blocked", text)
            answer = "blocked"
        else:
            event = T.carry_over(conn, user["id"], task_id, text)
            answer = "carried_over"
    except T.RuleError as exc:
        await message.answer(f"⚠️ {exc.ar}")
        return
    schedule.record_checkin(conn, user["id"], task_id, kind, answer, text)
    await state.clear()
    await message.answer("تم التسجيل. شكراً." if answer == "carried_over"
                         else "تم التسجيل وأُبلغ المدير.")
    await send_event(message.bot, conn, event)


@router.callback_query(F.data.startswith("t:"))
async def task_button(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                      user: sqlite3.Row) -> None:
    _, action, raw_id = call.data.split(":")
    task_id = int(raw_id)

    if action == "flow_cancel":
        await state.clear()
        await call.message.edit_text(texts.CANCELLED_FLOW)
        return await call.answer()

    if action in SIMPLE:
        try:
            event = SIMPLE[action](conn, user["id"], task_id)
        except T.RuleError as exc:
            return await call.answer(exc.ar, show_alert=True)
        await call.message.edit_reply_markup(reply_markup=None)
        await call.message.answer(f"تم. المهمة #{task_id}: {texts.STATUS[T.get_task(conn, task_id)['status']]}")
        await send_event(call.bot, conn, event)
        return await call.answer()

    if action in ASK:
        flow_state, prompt = ASK[action]
        await state.set_state(flow_state)
        await state.update_data(task_id=task_id, action=action)
        await call.message.answer(prompt.format(id=task_id))
        return await call.answer()

    if action in ("delegate", "handover", "reassign"):
        if action == "delegate":
            people = db.all_rows(
                conn,
                """SELECT * FROM users WHERE active = 1 AND role = 'employee' AND location_id = ?
                   AND telegram_id IS NOT NULL ORDER BY name""",
                (user["location_id"],),
            )
            prompt, prefix = texts.ASK_DELEGATE_TARGET, "dg"
        elif action == "handover":
            people = db.all_rows(
                conn,
                """SELECT * FROM users WHERE active = 1 AND id != ? AND role = 'employee'
                   AND location_id = ? AND telegram_id IS NOT NULL ORDER BY name""",
                (user["id"], user["location_id"]),
            )
            prompt, prefix = texts.ASK_HANDOVER_TARGET, "ho"
        else:
            people, prompt, prefix = assignable(conn, user), texts.ASK_ASSIGNEE, "ra"
        if not people:                       # an empty picker looks broken — say why
            await call.message.answer(texts.NO_COLLEAGUES if action == "handover"
                                      else "لا يوجد أشخاص مرتبطون بالبوت لاختيارهم.")
            return await call.answer()
        await call.message.answer(prompt, reply_markup=kb.people_picker(people, prefix, task_id))
        return await call.answer()

    if action == "sug_ok":
        people = assignable(conn, user)
        await call.message.answer("لمن تُسند المهمة؟", reply_markup=kb.people_picker(people, "sa", task_id))
        return await call.answer()

    if action == "sug_no":
        await state.set_state(Flow.cancel_reason)
        await state.update_data(task_id=task_id, action="sug_no")
        await call.message.answer("اكتب سبب رفض الاقتراح:")
        return await call.answer()

    await call.answer()


@router.callback_query(F.data.startswith(("dg:", "ho:", "ra:", "sa:")))
async def pick_person(call: CallbackQuery, state: FSMContext, conn: sqlite3.Connection,
                      user: sqlite3.Row) -> None:
    prefix, raw_task, raw_user = call.data.split(":")
    task_id, target_id = int(raw_task), int(raw_user)
    try:
        if prefix == "dg":
            await state.set_state(Flow.delegate_note)
            await state.update_data(task_id=task_id, target_id=target_id, action="delegate")
            await call.message.edit_text(texts.ASK_DELEGATE_NOTE)
            return await call.answer()
        if prefix == "ho":
            await state.set_state(Flow.handover_reason)
            await state.update_data(task_id=task_id, target_id=target_id, action="handover")
            await call.message.edit_text(texts.ASK_REASON_HANDOVER)
            return await call.answer()
        if prefix == "ra":
            event = T.reassign(conn, user["id"], task_id, target_id)
        else:
            event = T.approve_suggestion(conn, user["id"], task_id, assignee_id=target_id)
    except T.RuleError as exc:
        return await call.answer(exc.ar, show_alert=True)
    await call.message.edit_text(f"تم. المهمة #{task_id} أُسندت.")
    await send_event(call.bot, conn, event)
    await call.answer()


@router.message(Flow.reject_reason)
@router.message(Flow.review_note)
@router.message(Flow.comment)
@router.message(Flow.cancel_reason)
@router.message(Flow.handover_reason)
@router.message(Flow.delegate_note)
async def flow_text(message: Message, state: FSMContext, conn: sqlite3.Connection,
                    user: sqlite3.Row) -> None:
    data = await state.get_data()
    action, task_id = data.get("action"), data.get("task_id")
    text = message.text.strip()
    if text == "-":
        text = ""
    try:
        if action == "reject":
            event = T.reject(conn, user["id"], task_id, text)
        elif action == "ho_drop":
            event = T.reject_handover(conn, user["id"], task_id, text)
        elif action == "rev_back":
            event = T.review_return(conn, user["id"], task_id, text)
        elif action == "comment":
            event = T.add_comment(conn, user["id"], task_id, text)
        elif action == "cancel":
            event = T.cancel(conn, user["id"], task_id, text)
        elif action == "sug_no":
            event = T.decline_suggestion(conn, user["id"], task_id, text)
        elif action == "delegate":
            event = T.delegate(conn, user["id"], task_id, data["target_id"], text)
        elif action == "handover":
            _, event = T.request_handover(conn, user["id"], task_id, data["target_id"], text)
        else:
            await state.clear()
            return
    except T.RuleError as exc:
        await message.answer(f"⚠️ {exc.ar}")
        return
    await state.clear()
    if action == "handover":                 # two more yeses to go — spell them out
        target = db.one(conn, "SELECT name FROM users WHERE id = ?", (data["target_id"],))
        await message.answer(texts.HANDOVER_SENT.format(id=task_id, target=target["name"]))
    else:
        await message.answer(f"تم. المهمة #{task_id}: {texts.STATUS[T.get_task(conn, task_id)['status']]}")
    await send_event(message.bot, conn, event)
