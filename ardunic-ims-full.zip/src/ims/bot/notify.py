"""Delivery: the bot drains the outbox that both it and the dashboard write to."""
from __future__ import annotations

import asyncio
import logging
import sqlite3

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError

from .. import db
from ..core import notify as outbox
from ..core import tasks as T
from . import keyboards

log = logging.getLogger(__name__)
POLL_SECONDS = 2


async def send_event(bot: Bot, conn: sqlite3.Connection, event: T.Event) -> int:
    """Queue an event and push it out at once, so bot replies feel instant.

    Returns how many recipients it was queued for — 0 means nobody who should
    hear about this has linked Telegram yet, which the caller may want to say.
    """
    queued = outbox.queue(conn, event)
    await drain(bot, conn)
    return queued


async def drain(bot: Bot, conn: sqlite3.Connection) -> int:
    """Send whatever is waiting. Returns how many messages went out."""
    sent = 0
    for row in outbox.pending(conn):
        task = db.one(conn, "SELECT * FROM tasks WHERE id = ?", (row["task_id"],)) if row["task_id"] else None
        viewer = db.one(conn, "SELECT * FROM users WHERE id = ?", (row["user_id"],))
        handover = db.one(
            conn, "SELECT * FROM handovers WHERE task_id = ? ORDER BY id DESC LIMIT 1", (task["id"],)
        ) if task is not None else None
        kind = row["keyboard"] if "keyboard" in row.keys() else None
        keyboard = keyboards.for_kind(kind, task, viewer, handover)
        try:
            await bot.send_message(row["telegram_id"], row["body"], reply_markup=keyboard)
            outbox.mark_sent(conn, row["id"])
            sent += 1
        except TelegramAPIError as exc:       # blocked the bot, deleted chat, bad token…
            log.warning("delivery failed for user %s: %s", row["user_id"], exc)
            outbox.mark_failed(conn, row["id"], str(exc))
    return sent


async def outbox_worker(bot: Bot, conn: sqlite3.Connection) -> None:
    """Background loop: picks up anything the dashboard queued."""
    log.info("outbox worker started (every %ss)", POLL_SECONDS)
    while True:
        try:
            count = await drain(bot, conn)
            if count:
                log.info("delivered %s queued notification(s)", count)
        except Exception as exc:              # never let the loop die
            log.exception("outbox worker error: %s", exc)
        await asyncio.sleep(POLL_SECONDS)
