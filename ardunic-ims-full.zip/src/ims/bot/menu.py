"""The blue menu button next to the message box, filled per role.

Telegram keeps one command list per chat, so each linked person gets their own:
a manager sees /new, an employee does not — the employee's path to a new task is
/suggest. The list is written when the bot starts and again right after someone
links, which is the only moment their role becomes known.
"""
from __future__ import annotations

import logging
import sqlite3

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError
from aiogram.types import (BotCommand, BotCommandScopeChat, BotCommandScopeDefault,
                           MenuButtonCommands)

from .. import db

log = logging.getLogger(__name__)

_MYTASKS = BotCommand(command="mytasks", description="مهامي المفتوحة")
_TASK = BotCommand(command="task", description="عرض مهمة برقمها")
_HELP = BotCommand(command="help", description="شرح الأوامر")
_START = BotCommand(command="start", description="ربط الحساب")

MANAGER_MENU = [
    _MYTASKS,
    BotCommand(command="new", description="مهمة جديدة لموظف"),
    BotCommand(command="suggest", description="اقتراح مهمة على المدير العام"),
    _TASK,
    _HELP,
]
GM_MENU = [
    _MYTASKS,
    BotCommand(command="new", description="مهمة جديدة"),
    _TASK,
    _HELP,
]
EMPLOYEE_MENU = [
    _MYTASKS,
    BotCommand(command="suggest", description="اقتراح مهمة على مديرك"),
    _TASK,
    _HELP,
]
UNLINKED_MENU = [_START, _HELP]

BY_ROLE = {"gm": GM_MENU, "manager": MANAGER_MENU, "employee": EMPLOYEE_MENU}


def menu_for(role: str | None) -> list[BotCommand]:
    return BY_ROLE.get(role or "", UNLINKED_MENU)


async def apply(bot: Bot, telegram_id: int, role: str | None) -> bool:
    """Write one person's command list. False if Telegram refused."""
    try:
        await bot.set_my_commands(menu_for(role), scope=BotCommandScopeChat(chat_id=telegram_id))
        return True
    except TelegramAPIError as exc:          # never linked this chat, blocked the bot…
        log.warning("menu not set for chat %s: %s", telegram_id, exc)
        return False


async def refresh_all(bot: Bot, conn: sqlite3.Connection) -> int:
    """Default list for anyone new, then the right list for everyone linked."""
    try:
        await bot.set_my_commands(UNLINKED_MENU, scope=BotCommandScopeDefault())
        await bot.set_chat_menu_button(menu_button=MenuButtonCommands())
    except TelegramAPIError as exc:
        log.warning("default menu not set: %s", exc)

    done = 0
    for row in db.all_rows(
        conn,
        "SELECT telegram_id, role FROM users WHERE active = 1 AND telegram_id IS NOT NULL",
    ):
        if await apply(bot, row["telegram_id"], row["role"]):
            done += 1
    log.info("command menu set for %s linked account(s)", done)
    return done
