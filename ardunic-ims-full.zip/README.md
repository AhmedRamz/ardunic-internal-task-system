# Ardunic Internal Management System

Telegram bot + web dashboard for Ardunic's internal tasks, daily routines and their
time periods. Pilot: the Jadriya branch. Interface language: Arabic (RTL).

Spec: *Ardunic Internal Management System — V1 Spec*. UI: *Ardunic Internal Management System — UI/UX Mockups*.

## What is in this repository now (phases 1, 2, 3 and 5)

| Path | What it holds |
| --- | --- |
| `schema.sql` | The whole V1 database: tasks, history, routines, periods, swaps, leave, check-in times |
| `src/ims/core/tasks.py` | **The task rules.** Every status change in the system goes through this module |
| `src/ims/bot/` | The Telegram bot: linking, `/new`, `/suggest`, `/mytasks`, and the action buttons |
| `src/ims/texts.py` | Every Arabic string the bot sends |
| `tests/test_tasks.py` | 29 tests over the rules: permissions, rejection reasons, delegation, handover |
| `scripts/seed.py` | Creates the database, the pilot team, the 7 routines, R1's periods, the check-in times |
| `src/ims/core/schedule.py` | The daily rhythm: who gets the brief, the updates, the close-out and the report |
| `src/ims/bot/scheduler.py` | The minute tick that fires the slots and the reminders |
| `src/ims/core/notify.py` | The outbox both the dashboard and the bot write to |
| `src/ims/web/` | The dashboard: login, board, task detail, today, routines, periods, employees, settings |
| `deploy/` | `install.sh`, `update.sh`, the systemd units, the backup script |

Still to come: routines and periods in the bot, period swaps and leave coverage
(phase 4), and the group `/task` command (phase 6).

### The daily rhythm (phase 3)

The bot process ticks once a minute and reads the times from `checkin_slots`, so
changing them in Settings is enough — no restart, no code change.

| Slot | Who | What |
| --- | --- | --- |
| 09:00 brief | each employee | today's tasks, overdue ones, what is waiting to be accepted |
| 09:00 overview | GM and branch manager | open, unaccepted, overdue, waiting for review, who is on leave |
| 10:00 / 12:00 / 14:00 | each employee with open tasks | one message per task: Done · Working · Blocked |
| 16:30 close-out | each employee | per task: Done, or carried over with a note |
| 17:00 report | GM and branch manager | done today, carried over, rejected, overdue, who stayed silent |

Rules that keep it from becoming noise: nothing is sent on Friday or to someone on
leave; a slot fires once a day and is skipped entirely if the server was down past
its grace window (an update is useless two hours late, a brief is not); a task that
has been unaccepted for 2 hours nudges the employee and after 4 hours the manager,
each once; a task that has just gone overdue is announced once; and anything older
than 48 hours is left to the board instead of being announced.

## Running it on your machine

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # put the BotFather token in BOT_TOKEN
python scripts/seed.py --db ims.db
PYTHONPATH=src python -m ims.bot.app
```

Then open the bot in Telegram and send the link code the seed script printed:
`/start 123456`.

Tests need nothing installed:

```bash
python3 -m unittest discover -s tests -v
```

## Putting it on the server

```bash
# on the server, as root
git clone <your private repo> /root/ardunic-ims && cd /root/ardunic-ims
bash deploy/install.sh          # installs, seeds, creates the service
nano /opt/ardunic-ims/.env      # paste BOT_TOKEN
systemctl start ims-bot
journalctl -u ims-bot -f        # watch it come up
```

Updating later: `git pull`, then `bash deploy/install.sh` again (it keeps `.env` and the database).

## Decisions worth remembering

- **Everything goes through `core/tasks.py`.** The bot, the dashboard and the scheduler
  call the same functions, so the lifecycle cannot drift apart between them.
- **Nothing is deleted.** Tasks are cancelled or closed; every change is a row in `task_events`.
- **A rejection needs a reason**, a handover needs the manager's approval *and* the
  receiving employee's acceptance, and delegation works only when the task allows it.
- **Periods have no backup.** A period with nobody on it is a gap the manager fills
  from the weekly board; an employee who cannot work theirs swaps it at least 2 hours ahead.
- **Dashboard logins are for the GM and the branch manager only.** Employees use the bot.
- SQLite now, PostgreSQL when the second branch joins; the DDL ports with small type changes.

## Security notes

- `.env` holds the bot token: it is in `.gitignore`, keep it out of the repository.
- The bot ignores every Telegram account that is not linked to a person in `users`.
- In groups the bot answers commands only; it does not read or store other messages.
