"""Fill the board with a few realistic tasks so the dashboard can be reviewed before
the bot is live. Safe to skip in production — and `--clear` removes them again.

    python scripts/demo_data.py --db ims.db
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db, texts  # noqa: E402
from ims.core import tasks as T  # noqa: E402

DEMO = [
    ("جرد رف الحساسات S-12", "علي", "high", True, "accept"),
    ("تجهيز طلبية جملة رقم 4521", "مصطفى", "urgent", False, "accept"),
    ("ترتيب شحنة المكثفات الواردة", "زينب", "normal", False, "blocked"),
    ("تحديث أسعار الموديولات على الموقع", "مريم", "high", False, None),
    ("تجهيز ملصقات الرفوف الجديدة", "حسين", "normal", False, "reject"),
    ("تصوير منتجات جديدة للموقع", "علي", "normal", True, "review"),
    ("الرد على رسائل واتساب المعلّقة", "نور", "normal", False, "accept"),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="ims.db")
    parser.add_argument("--clear", action="store_true", help="delete the demo tasks instead")
    args = parser.parse_args()
    conn = db.connect(args.db)

    if args.clear:
        conn.execute("DELETE FROM task_events WHERE task_id IN (SELECT id FROM tasks WHERE source = 'dashboard')")
        conn.execute("DELETE FROM tasks WHERE source = 'dashboard'")
        print("demo tasks removed")
        return

    def uid(name: str) -> int:
        row = db.one(conn, "SELECT id FROM users WHERE name = ?", (name,))
        if row is None:
            raise SystemExit(f"user {name} is missing — run scripts/seed.py first")
        return row["id"]

    gm, manager = uid("أحمد"), uid("حيدر")
    for title, who, priority, review, flow in DEMO:
        task_id, _ = T.create_task(conn, gm, title, uid(who), priority=priority,
                                   needs_review=review, due_at=texts.today_at(17))
        if flow in ("accept", "blocked", "review"):
            T.accept(conn, uid(who), task_id)
        if flow == "blocked":
            T.post_update(conn, uid(who), task_id, "blocked", "بانتظار فاتورة المورد لمطابقة الكميات")
        if flow == "review":
            T.mark_done(conn, uid(who), task_id)
        if flow == "reject":
            T.reject(conn, uid(who), task_id, "مشغول بطلبية الجملة حتى نهاية الدوام")

    # one delegated task and one suggestion, so both flows are visible on the board
    delegated, _ = T.create_task(conn, gm, "متابعة تجهيز طلبيات الجملة هذا الأسبوع", manager,
                                 priority="high", allow_delegation=True, due_at=texts.tomorrow_at(17))
    T.delegate(conn, manager, delegated, uid("علي"), "ابدأ بطلبية 4521")
    T.suggest_task(conn, uid("نور"), "شراء رفوف إضافية لغرفة التخزين")
    print("demo tasks added — open the dashboard to review the board")


if __name__ == "__main__":
    main()
