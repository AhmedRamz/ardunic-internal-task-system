"""Set a dashboard password for the GM or a branch manager.

    python scripts/set_password.py --db ims.db --user ahmed

The password is asked for on the terminal (never passed as an argument, so it
does not end up in the shell history) and is stored as a PBKDF2 hash.
"""
from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import auth  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="ims.db")
    parser.add_argument("--user", required=True, help="telegram username or the person's name")
    args = parser.parse_args()

    conn = db.connect(args.db)
    handle = args.user.strip().lstrip("@")
    user = db.one(
        conn,
        "SELECT * FROM users WHERE telegram_username = ? OR name = ?",
        (handle, args.user.strip()),
    )
    if user is None:
        raise SystemExit(f"no user matches {args.user!r}")
    if user["role"] not in ("gm", "manager"):
        raise SystemExit("dashboard accounts are for the GM and branch managers only")

    password = getpass.getpass(f"new password for {user['name']}: ")
    again = getpass.getpass("repeat: ")
    if password != again:
        raise SystemExit("the two passwords differ")
    if len(password) < 8:
        raise SystemExit("use at least 8 characters")

    auth.set_password(conn, user["id"], password)
    print(f"done — {user['name']} can sign in with: {user['telegram_username'] or user['name']}")


if __name__ == "__main__":
    main()
