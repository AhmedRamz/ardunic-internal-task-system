"""Create the database and the Jadriya pilot team.

    python scripts/seed.py --db ims.db

Names and Telegram usernames are placeholders: edit TEAM below before running,
or add people from the dashboard later. Each person gets a 6-digit link code
that they send to the bot once as `/start <code>`.
"""
from __future__ import annotations

import argparse
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402

TEAM = [
    # name,      role,        telegram username
    ("أحمد",     "gm",        "ahmed"),
    ("حيدر",     "manager",   "haider"),
    ("علي",      "employee",  "ali"),
    ("زينب",     "employee",  "zainab"),
    ("مصطفى",    "employee",  "mustafa"),
    ("مريم",     "employee",  "maryam"),
    ("حسين",     "employee",  "hussein"),
    ("نور",      "employee",  "noor"),
]

ROUTINES = [
    ("R1", "الرد على العملاء في مواقع التواصل وتتبع الطلبات", "المحادثات"),
    ("R2", "تجهيز الطلبات", "الطلبات المجهزة"),
    ("R3", "فحص الطلبات المجهزة والتواصل مع العملاء", "الطلبات المفحوصة"),
    ("R4", "البيع المباشر", None),
    ("R5", "فرز الشحنات", "الصناديق"),
    ("R6", "توليد مواقع للمواد الجديدة", "المواد"),
    ("R7", "تزويد الفرع الآخر", "المواد المُرسلة"),
]

# R1 periods: three on Sat–Thu, four equal ones on Friday.
PERIODS = [
    ("صباحية", "sat,sun,mon,tue,wed,thu", "08:00", "17:00"),
    ("مسائية", "sat,sun,mon,tue,wed,thu", "17:00", "20:00"),
    ("ليلية", "sat,sun,mon,tue,wed,thu", "20:00", "23:59"),
    ("الجمعة ف1", "fri", "08:00", "12:00"),
    ("الجمعة ف2", "fri", "12:00", "16:00"),
    ("الجمعة ف3", "fri", "16:00", "20:00"),
    ("الجمعة ف4", "fri", "20:00", "23:59"),
]

CHECKINS = [("brief", "09:00"), ("update", "10:00"), ("update", "12:00"),
            ("update", "14:00"), ("closeout", "16:30"), ("report", "17:00")]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="ims.db")
    args = parser.parse_args()

    conn = db.connect(args.db)
    db.migrate(conn)

    if db.one(conn, "SELECT 1 FROM users LIMIT 1"):
        print("The database already has users — nothing seeded.")
        return

    jadriya = db.insert(conn, "locations", name="الجادرية")
    db.insert(conn, "locations", name="شارع الصناعة", active=0)   # joins in V2

    expires = (datetime.now(timezone.utc) + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
    gm_id = manager_id = None
    codes: list[tuple[str, str]] = []
    for name, role, username in TEAM:
        code = f"{random.randint(100000, 999999)}"
        user_id = db.insert(conn, "users", name=name, role=role, location_id=jadriya,
                            telegram_username=username, link_code=code, link_code_expires=expires,
                            manager_id=manager_id if role == "employee" else gm_id)
        if role == "gm":
            gm_id = user_id
        elif role == "manager":
            manager_id = user_id
        codes.append((name, code))

    for kind, time in CHECKINS:
        db.insert(conn, "checkin_slots", location_id=jadriya, kind=kind, time=time)

    routine_ids = {}
    for code, name, count_label in ROUTINES:
        days = "sat,sun,mon,tue,wed,thu,fri" if code == "R1" else "sat,sun,mon,tue,wed,thu"
        routine_ids[code] = db.insert(conn, "routines", code=code, name=name,
                                      count_label=count_label, location_id=jadriya, days=days)

    for name, days, start, end in PERIODS:
        db.insert(conn, "routine_periods", routine_id=routine_ids["R1"], name=name,
                  days=days, start_time=start, end_time=end)

    db.insert(conn, "settings", key="swap_deadline_hours", value="2")
    db.insert(conn, "settings", key="workdays", value="sat,sun,mon,tue,wed,thu")

    print("Seeded the Jadriya pilot.\n")
    print("Link codes — each person sends this once to the bot:")
    for name, code in codes:
        print(f"  {name:10s}  /start {code}")
    print("\nThe codes expire in 24 hours; create new ones from the dashboard.")


if __name__ == "__main__":
    main()
