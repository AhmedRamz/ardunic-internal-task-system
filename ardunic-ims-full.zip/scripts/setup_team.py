"""Put the Jadriya team and the social-media rota in, from the command line.

    python scripts/setup_team.py --db /opt/ardunic-ims/ims.db

The same thing the dashboard does under الموظفون ← «إعداد الفريق وجدول الفترات»,
for when a terminal is closer than a browser. Safe to run more than once.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import onboarding  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="ims.db")
    parser.add_argument("--branch", default="", help="branch name; the first one by default")
    args = parser.parse_args()

    conn = db.connect(args.db)
    db.migrate(conn)
    branch = (db.one(conn, "SELECT * FROM locations WHERE name = ?", (args.branch,))
              if args.branch else onboarding.branch_of(conn))
    if branch is None:
        raise SystemExit("no branch in the database — run scripts/seed.py first")

    print(f"الفرع: {branch['name']}")
    for line in onboarding.summary_lines(onboarding.apply(conn, branch["id"])):
        print(line)


if __name__ == "__main__":
    main()
