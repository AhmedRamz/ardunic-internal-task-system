"""Put the real Jadriya team and the social-media rota into the system.

    python scripts/setup_team.py --db /opt/ardunic-ims/ims.db

Safe to run more than once: people are matched by name and created only if
missing, the rota is written to match the sheet exactly, and nothing is ever
deleted. Run it again after editing ROTA and the board follows.

The rota is Ahmed's own sheet — Facebook and Instagram, three periods a day,
with Mahmood covering the whole of Friday.
"""
from __future__ import annotations

import argparse
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from ims import db  # noqa: E402
from ims.core import periods as P  # noqa: E402

# name as it should read in the dashboard -> the spelling on the sheet
TEAM = [
    ("نرجس", "Narjes"),
    ("علي", "Ali"),
    ("طيبة", "Teeba"),
    ("محمد أحمد", "Mohammed Ahmed"),
    ("محمود", "Mahmood"),
    ("أحمد جعفر", "Ahmed Jaffar"),
]

# the three working periods, exactly as the sheet's rows
PERIODS = [
    ("صباحية", "sat,sun,mon,tue,wed,thu", "08:00", "17:00"),
    ("مسائية", "sat,sun,mon,tue,wed,thu", "17:00", "20:00"),
    ("ليلية", "sat,sun,mon,tue,wed,thu", "20:00", "23:59"),
    # Friday is split into four equal stretches; Mahmood covers all of it
    ("الجمعة ف1", "fri", "08:00", "12:00"),
    ("الجمعة ف2", "fri", "12:00", "16:00"),
    ("الجمعة ف3", "fri", "16:00", "20:00"),
    ("الجمعة ف4", "fri", "20:00", "23:59"),
]

# period name -> weekday -> who. None is a gap the manager fills.
ROTA = {
    "صباحية": {"sat": "نرجس", "sun": "علي", "mon": "طيبة", "tue": "محمد أحمد",
               "wed": "أحمد جعفر", "thu": "محمود"},
    "مسائية": {"sat": "محمد أحمد", "sun": "محمود", "mon": "أحمد جعفر", "tue": "طيبة",
               "wed": "علي", "thu": "نرجس"},
    "ليلية": {"sat": "طيبة", "sun": None, "mon": "نرجس", "tue": "علي",
              "wed": "محمود", "thu": "محمد أحمد"},
    "الجمعة ف1": {"fri": "محمود"},
    "الجمعة ف2": {"fri": "محمود"},
    "الجمعة ف3": {"fri": "محمود"},
    "الجمعة ف4": {"fri": "محمود"},
}

R1_NAME = "الرد على العملاء في مواقع التواصل وتتبع الطلبات"


def link_code(conn, user_id: int) -> str:
    code = f"{random.randint(100000, 999999)}"
    expires = (datetime.now(timezone.utc) + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
    db.update(conn, "users", user_id, link_code=code, link_code_expires=expires)
    return code


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", default="ims.db")
    parser.add_argument("--branch", default="", help="branch name; the first one by default")
    args = parser.parse_args()

    conn = db.connect(args.db)
    db.migrate(conn)

    branch = (db.one(conn, "SELECT * FROM locations WHERE name = ?", (args.branch,))
              if args.branch else db.one(conn, "SELECT * FROM locations ORDER BY id LIMIT 1"))
    if branch is None:
        raise SystemExit("no branch in the database — run scripts/seed.py first")
    manager = db.one(conn, "SELECT id FROM users WHERE role = 'manager' AND location_id = ?",
                     (branch["id"],))

    # ---------------------------------------------------------------- people
    people, fresh = {}, []
    for name, english in TEAM:
        row = db.one(conn, "SELECT * FROM users WHERE name = ? AND location_id = ?",
                     (name, branch["id"]))
        if row is None:
            user_id = db.insert(conn, "users", name=name, role="employee",
                                location_id=branch["id"],
                                manager_id=manager["id"] if manager else None)
            fresh.append((name, english, link_code(conn, user_id)))
        else:
            user_id = row["id"]
            if not row["active"]:
                db.update(conn, "users", user_id, active=1)
            if not row["telegram_id"]:
                fresh.append((name, english, link_code(conn, user_id)))
        people[name] = user_id

    # ---------------------------------------------------------------- the routine and its periods
    routine = db.one(conn, "SELECT * FROM routines WHERE code = 'R1' AND location_id = ?",
                     (branch["id"],))
    if routine is None:
        routine_id = db.insert(conn, "routines", code="R1", name=R1_NAME,
                               location_id=branch["id"], count_label="المحادثات",
                               days="sat,sun,mon,tue,wed,thu,fri",
                               instructions="الرد على رسائل فيسبوك وإنستغرام ومتابعة حالة الطلبات.")
    else:
        routine_id = routine["id"]
        db.update(conn, "routines", routine_id, days="sat,sun,mon,tue,wed,thu,fri", active=1)

    period_ids = {}
    for name, days, start, end in PERIODS:
        row = db.one(conn, "SELECT * FROM routine_periods WHERE routine_id = ? AND name = ?",
                     (routine_id, name))
        if row is None:
            period_ids[name] = db.insert(conn, "routine_periods", routine_id=routine_id,
                                         name=name, days=days, start_time=start, end_time=end)
        else:
            period_ids[name] = row["id"]
            db.update(conn, "routine_periods", row["id"], days=days,
                      start_time=start, end_time=end)

    # ---------------------------------------------------------------- the weekly board
    filled = gaps = 0
    for period_name, by_day in ROTA.items():
        period_id = period_ids[period_name]
        for weekday, who in by_day.items():
            user_id = people.get(who) if who else None
            row = db.one(conn, "SELECT id FROM period_schedule WHERE period_id = ? AND weekday = ?",
                         (period_id, weekday))
            if row:
                db.update(conn, "period_schedule", row["id"], user_id=user_id)
            else:
                db.insert(conn, "period_schedule", period_id=period_id, weekday=weekday,
                          user_id=user_id)
            filled += 1 if user_id else 0
            gaps += 0 if user_id else 1

    # ---------------------------------------------------------------- what happened
    print(f"الفرع: {branch['name']}")
    print(f"الفريق: {len(people)} أشخاص · خانات مملوءة: {filled} · فجوات: {gaps}\n")

    print("جدول الفترات كما في الورقة:")
    for period_name, _, start, end in [(p[0], p[1], p[2], p[3]) for p in PERIODS]:
        assigned = ROTA[period_name]
        line = "، ".join(f"{P.WEEKDAY_AR[day]}: {who or '—'}" for day, who in assigned.items())
        print(f"  {period_name} {start}–{end}  {line}")

    if gaps:
        print(f"\n{gaps} فترة بلا مسؤول — تظهر حمراء في لوحة الفترات ويذكّرك البوت بها.")

    if fresh:
        print("\nرموز الربط — يرسل كل شخص رمزه للبوت خلال 24 ساعة:")
        for name, english, code in fresh:
            print(f"  {name:12s} ({english:15s})  /start {code}")
    else:
        print("\nكل الحسابات مرتبطة بالبوت بالفعل.")


if __name__ == "__main__":
    main()
