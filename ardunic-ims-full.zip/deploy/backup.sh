#!/usr/bin/env bash
# Daily database backup, 14 days kept. Put in cron:  0 1 * * * /opt/ardunic-ims/deploy/backup.sh
set -euo pipefail
APP_DIR=/opt/ardunic-ims
DEST="$APP_DIR/backups"
mkdir -p "$DEST"
sqlite3 "$APP_DIR/ims.db" ".backup '$DEST/ims-$(date +%F).db'"
find "$DEST" -name 'ims-*.db' -mtime +14 -delete
