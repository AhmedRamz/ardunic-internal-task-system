#!/usr/bin/env bash
# Update a running installation from a new zip.
#
#   bash /opt/ardunic-ims/deploy/update.sh <url-of-new-zip>
#
# Keeps the database, the .env and the uploads; replaces the code and restarts
# both services. A copy of the previous code is kept in /opt/ardunic-ims-backups.
set -euo pipefail

URL="${1:-}"
APP_DIR=/opt/ardunic-ims
STAMP=$(date +%F-%H%M)
BACKUP_DIR=/opt/ardunic-ims-backups

if [ -z "$URL" ]; then
  echo "usage: bash deploy/update.sh <url-of-new-zip>"
  exit 1
fi

echo "==> backing up database and code"
mkdir -p "$BACKUP_DIR"
sqlite3 "$APP_DIR/ims.db" ".backup '$BACKUP_DIR/ims-$STAMP.db'" 2>/dev/null || true
tar -czf "$BACKUP_DIR/code-$STAMP.tgz" -C "$APP_DIR" src scripts deploy schema.sql requirements.txt 2>/dev/null || true

echo "==> downloading"
TMP=$(mktemp -d)
curl -fsSL -o "$TMP/new.zip" "$URL"
unzip -oq "$TMP/new.zip" -d "$TMP/src"

NEW_DIR="$TMP/src/ardunic-ims"
[ -d "$NEW_DIR" ] || NEW_DIR="$TMP/src"

echo "==> replacing code (database, .env and backups untouched)"
rsync -a --delete \
  --exclude '.env' --exclude '*.db' --exclude '*.db-wal' --exclude '*.db-shm' \
  --exclude '.venv' --exclude 'backups' \
  "$NEW_DIR"/ "$APP_DIR"/

echo "==> dependencies"
"$APP_DIR/.venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"

echo "==> schema migration (new tables and columns only; nothing is dropped)"
PYTHONPATH="$APP_DIR/src" "$APP_DIR/.venv/bin/python" -c "
from ims import db
conn = db.connect('$APP_DIR/ims.db'); db.migrate(conn); print('schema up to date')
"

chown -R ims:ims "$APP_DIR"
install -m 644 "$APP_DIR/deploy/ims-bot.service" /etc/systemd/system/ims-bot.service
install -m 644 "$APP_DIR/deploy/ims-web.service" /etc/systemd/system/ims-web.service
systemctl daemon-reload
systemctl restart ims-web
systemctl is-active --quiet ims-bot && systemctl restart ims-bot || true

echo
systemctl --no-pager --lines=5 status ims-web || true
echo
echo "updated. Backups of this version: $BACKUP_DIR/ims-$STAMP.db and code-$STAMP.tgz"
