#!/usr/bin/env bash
# Ardunic IMS — first install on a fresh Ubuntu 24.04 server.
# Run as root:  bash deploy/install.sh
set -euo pipefail

APP_DIR=/opt/ardunic-ims
SERVICE=ims-bot

echo "==> packages"
apt-get update -qq
apt-get install -y -qq python3 python3-venv python3-pip sqlite3 rsync

echo "==> user and folder"
id -u ims >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin ims
mkdir -p "$APP_DIR"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ "$SRC_DIR" != "$APP_DIR" ]; then
  rsync -a --exclude .git --exclude .venv --exclude '*.db' "$SRC_DIR"/ "$APP_DIR"/
fi

echo "==> python environment"
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install -q --upgrade pip
"$APP_DIR/.venv/bin/pip" install -q -r "$APP_DIR/requirements.txt"

echo "==> configuration"
if [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
  echo "    edit $APP_DIR/.env and put the BOT_TOKEN in it, then run this script again"
fi

echo "==> database"
if [ ! -f "$APP_DIR/ims.db" ]; then
  PYTHONPATH="$APP_DIR/src" "$APP_DIR/.venv/bin/python" "$APP_DIR/scripts/seed.py" --db "$APP_DIR/ims.db"
fi
chown -R ims:ims "$APP_DIR"

echo "==> session secret"
grep -q '^SESSION_SECRET=' "$APP_DIR/.env" || \
  echo "SESSION_SECRET=$(python3 -c 'import secrets;print(secrets.token_hex(32))')" >> "$APP_DIR/.env"
chown ims:ims "$APP_DIR/.env"

echo "==> services"
install -m 644 "$APP_DIR/deploy/$SERVICE.service" "/etc/systemd/system/$SERVICE.service"
install -m 644 "$APP_DIR/deploy/ims-web.service" "/etc/systemd/system/ims-web.service"
systemctl daemon-reload
systemctl enable "$SERVICE" ims-web

# the dashboard needs no Telegram token, so it always starts
systemctl restart ims-web
sleep 2
systemctl --no-pager --lines=6 status ims-web || true

if grep -q "put-the-token" "$APP_DIR/.env"; then
  echo
  echo "The bot is not started: BOT_TOKEN is still a placeholder."
  echo "  nano $APP_DIR/.env      # paste BOT_TOKEN"
  echo "  systemctl start $SERVICE"
else
  systemctl restart "$SERVICE"
  sleep 2
  systemctl --no-pager --lines=8 status "$SERVICE" || true
fi

echo
echo "Dashboard: http://$(curl -s -4 ifconfig.me 2>/dev/null || echo SERVER_IP):8000"
echo "Set the first password:  cd $APP_DIR && PYTHONPATH=src .venv/bin/python scripts/set_password.py --db ims.db --user ahmed"

echo
echo "Backups: add a daily copy of the database to cron, for example"
echo "  0 1 * * * sqlite3 $APP_DIR/ims.db \".backup $APP_DIR/backups/ims-\$(date +\\%F).db\""
