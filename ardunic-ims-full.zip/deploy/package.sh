#!/usr/bin/env bash
# Package a release zip with a VERSION stamp inside it.
#
#   bash deploy/package.sh [output.zip]
#
# The stamp is what the dashboard shows in its sidebar and what update.sh prints
# before and after, so "did the update land?" is a question with an answer.
set -euo pipefail

OUT="${1:-ardunic-ims-full.zip}"
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"

STAMP="$(date -u +%Y-%m-%d) · $(git log -1 --format=%h)"
rm -f "$OUT"
git archive --format=zip -o "$OUT" HEAD

python3 - "$OUT" "$STAMP" <<'PY'
import sys, zipfile
path, stamp = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(path, "a", zipfile.ZIP_DEFLATED) as bundle:
    bundle.writestr("VERSION", stamp + "\n")
PY

echo "packaged $OUT"
echo "version: $STAMP"
